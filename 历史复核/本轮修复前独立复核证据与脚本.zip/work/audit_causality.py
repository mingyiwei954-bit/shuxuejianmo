from pathlib import Path
import sys,json,copy
from datetime import date
from dataclasses import replace
import numpy as np,pandas as pd
ROOT=Path(__file__).resolve().parent.parent; S=ROOT/'work/snapshot/支撑材料';sys.path.insert(0,str(S))
from src.model.config import load_config
from src.model.data import load_data
from src.model.forecast import profile_horizon,history_days,corrected_pv_horizon,residual_scenarios
from src.model.experiments import simulate_day_ahead
from src.model.rolling import simulate,RunSpec,_solve
cfg=load_config(S/'config/final.yaml'); cfg['_source_root']=str(ROOT/'work/rawroot')
raw=ROOT/'work/rawroot';raw.mkdir(exist_ok=True);(raw/'C题').symlink_to(ROOT/'work/problem') if not (raw/'C题').exists() else None
data=load_data(cfg);out={};first=date(2025,1,1)
# Change only future actual load in memory; hold prices, published PV and initial SOC fixed.
mut=data.load_kw.copy();mut[0]+=600
alt=replace(data,load_kw=mut)
for mode in ['q2','q4_2']:
 a=simulate_day_ahead(data,cfg,mode,start_date=first,end_date=first)
 b=simulate_day_ahead(alt,cfg,mode,start_date=first,end_date=first)
 va=np.array([r['plan_00_grid_kwh'] for r in a['dispatch']]);vb=np.array([r['plan_00_grid_kwh'] for r in b['dispatch']])
 out[mode+'_cold_start']=dict(history_indices=history_days(data,first,first),max_plan_change=float(abs(va-vb).max()),total_plan_change=float((vb-va).sum()),changed_intervals=int((abs(va-vb)>1e-7).sum()))
# perturb only observations AFTER noon: same-day completed data must remain usable for 18h residual.
day=date(2025,2,1);issue=12;di=data.date_index[day]
mutpv=data.pv_kw.copy();mutpv[di,issue*6:]+=600
altpv=replace(data,pv_kw=mutpv)
pv0,h=corrected_pv_horizon(data,day,issue,144,cfg);pv1,_=corrected_pv_horizon(altpv,day,issue,144,cfg)
sc0,hs=residual_scenarios(data,day,issue,pv0,cfg,centered=True);sc1,_=residual_scenarios(altpv,day,issue,pv1,cfg,centered=True)
out['intraday_future_perturbation']=dict(max_corrected_forecast_change=float(abs(pv1-pv0).max()),max_scenario_change=float(abs(sc1-sc0).max()),latest_residual_day=str(h[-1]),note='Current date actual after issue is not in previous-day issue+24h residual, expect zero')
# actual dates < day with same issue are fully observed exactly at today's same issue. Test validates absence of this suspected leak.
# warmstart replay of January and record full daily evidence (no project writes)
for mode in ['q2','q4_2','q3','q4_3']:
 if mode in ['q2','q4_2']:
  warm=simulate_day_ahead(data,cfg,mode,start_date=first,end_date=date(2025,1,31),collect_detail=True)
  continuous=simulate_day_ahead(data,cfg,mode,start_date=first,end_date=date(2025,2,1),collect_detail=True)
  jan_end=[r for r in continuous['daily'] if r['date']=='2025-01-31'][0]['end_soc_kwh']
  extra=dict(uninterrupted_jan31_soc=jan_end,split_jan31_soc=warm['summary']['terminal_soc_kwh'])
 else:
  warm=simulate(data,cfg,RunSpec(mode,'S3','all_three'),start_date=first,end_date=date(2025,1,31))
  extra={}
 frozen=pd.read_csv(S/f'outputs/c_final_v1/frozen/{mode}_dispatch.csv');end=warm['summary']['terminal_soc_kwh']
 out[mode+'_january']=dict(summary=warm['summary'],official_start=float(frozen.soc_start_kwh.iloc[0]),link_difference=float(frozen.soc_start_kwh.iloc[0]-end),**extra)
 pd.DataFrame(warm['daily']).to_csv(ROOT/f'outputs/{mode}_一月隔离回放.csv',index=False)
 print(mode,'Jan end',end,'link',out[mode+'_january']['link_difference'],flush=True)
# Explicit initial-SOC injection holds all inputs equal in a short boundary diagnostic.
for initial in [1200.,6000.]:
 r=simulate(data,cfg,RunSpec('q3','S3','all_three'),start_date=day,end_date=day,initial_soc=initial)
 out[f'q3_feb1_initial_{int(initial)}']=r['summary']
(ROOT/'outputs/因果与SOC复验.json').write_text(json.dumps(out,ensure_ascii=False,indent=2));print(json.dumps(out,ensure_ascii=False,indent=2),flush=True)
