from pathlib import Path
from docx import Document
import openpyxl,pandas as pd,numpy as np,re,json,hashlib
ROOT=Path(__file__).resolve().parent.parent;S=ROOT/'work/snapshot';P=S/'支撑材料';O=ROOT/'outputs'
out={};doc=Document(S/'C题论文_v3.docx')
texts=[p.text for p in doc.paragraphs];table_text=['\n'.join('\t'.join(c.text for c in r.cells) for r in t.rows) for t in doc.tables]
(O/'论文表格核验摘录.txt').write_text('\n\n'.join(f'表格序号 {i+1}\n{t}' for i,t in enumerate(table_text[:18])))
for label,txt in [('current_markdown',(S/'paper_outline_and_draft_v3.md').read_text()),('delivered_docx','\n'.join(texts+table_text)),('delivered_pdf',(ROOT/'work/extracted/C题论文_v3.txt').read_text())]:
 # count complete RESULT macro occurrences; separate literal code examples after source appendix.
 out[label]=dict(result_macro_occurrences=len(re.findall(r'\{\{RESULT:[^}]+\}\}',txt)),double_brace_occurrences=len(re.findall(r'\{\{[^}]*\}\}',txt)))
out['docx_tables']=len(doc.tables);out['input_draft_exists']=(P/'work/paper_agent/paper_outline_and_draft.md').exists();out['input_AI_details_exists']=(P/'work/paper_agent/AI工具使用详情_内容稿.md').exists()
out['workbooks']={}
for name,mode in [('result1','q1'),('result2','q2'),('result3','q3'),('result4-2','q4_2'),('result4-3','q4_3')]:
 w=openpyxl.load_workbook(P/f'workbooks/{name}.xlsx',read_only=True,data_only=True);ds={s.title:list(s.values) for s in w};d=pd.read_csv(P/f'frozen/{mode}_dispatch.csv.xz');new=pd.read_csv(P/f'outputs/c_final_v1/frozen/{mode}_dispatch.csv')
 r={'sheets':{k:dict(rows=len(v),cols=max(map(len,v)),first_rows=v[:3]) for k,v in ds.items()}}
 for sheet,col in [('计划购电量','plan_00_grid_kwh'),('调整购电量','final_adjusted_grid_kwh')]:
  if sheet not in ds:continue
  arr=ds[sheet]
  if mode=='q1':vals=np.array([row[1] for row in arr[1:145]],float)
  else:vals=np.array([row[1:145] for row in arr[1:335]],float).reshape(-1)
  r[sheet]={'max_error_vs_delivered':float(abs(vals-d[col].to_numpy()).max()),'max_error_vs_regenerated':float(abs(vals-new[col].to_numpy()).max()),'different_from_regenerated_cells':int((abs(vals-new[col].to_numpy())>0.000051).sum())}
 out['workbooks'][name]=r
manifest=json.loads((S/'SHA256SUMS_v3.json').read_text());out['top_hash_check']={}
for rel,record in manifest['files'].items():
 p=S/rel;out['top_hash_check'][rel]={'matches':hashlib.sha256(p.read_bytes()).hexdigest()==record['sha256'],'actual_bytes':p.stat().st_size,'listed_bytes':record['bytes']}
# Produce diagnostic extracts for each requested day/block in CSV, without modifying paper/results.
selected=['2025-03-20','2025-06-21','2025-09-23','2025-12-21'];rows=[]
for mode in ['q1','q2','q3','q4_2','q4_3']:
 d=pd.read_csv(P/f'outputs/c_final_v1/frozen/{mode}_dispatch.csv')
 for day,z in d.groupby('date'):
  if mode!='q1' and day not in selected:continue
  for h in [10,12,14,16,18,20]:
   x=z[z.position==h*6+1].iloc[0];rows.append(dict(mode=mode,date=day,kind='指定10分钟',physical_interval=x.physical_interval,plan_grid=x.plan_00_grid_kwh,final_grid=x.final_adjusted_grid_kwh))
  for block in range(6):
   x=z[(z.position>block*24)&(z.position<=(block+1)*24)];rows.append(dict(mode=mode,date=day,kind='四小时储能',physical_interval=f'{block*4}:00-{(block+1)*4}:00',charge=x.charge_kwh.sum(),discharge=x.discharge_kwh.sum()))
  rows.append(dict(mode=mode,date=day,kind='全天',plan_grid=z.plan_00_grid_kwh.sum(),final_grid=z.final_adjusted_grid_kwh.sum(),cost=z.final_relative_cost_yuan.sum(),soc_start=z.soc_start_kwh.iloc[0],soc_end=z.soc_end_kwh.iloc[-1]))
pd.DataFrame(rows).to_csv(O/'指定时段独立抽取.csv',index=False)
(O/'交付文件复验.json').write_text(json.dumps(out,ensure_ascii=False,indent=2,default=str));print(json.dumps(out,ensure_ascii=False,indent=2,default=str),flush=True)
