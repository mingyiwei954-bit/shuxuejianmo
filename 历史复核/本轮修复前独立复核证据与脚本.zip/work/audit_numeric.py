from pathlib import Path
import pandas as pd,numpy as np,openpyxl,json,hashlib
from scipy.optimize import linprog
ROOT=Path(__file__).resolve().parent.parent; S=ROOT/'work/snapshot/支撑材料'; O=ROOT/'outputs'; P=ROOT/'work/problem/附件'
# Independent original workbook parsing (no project data loader).
a=np.array(list(openpyxl.load_workbook(P/'附件1.xlsx',read_only=True,data_only=True).active.values)[1:],dtype=object)
price=a[:,1].astype(float); q1load=a[:,2].astype(float)/6;q1pv=a[:,3].astype(float)/6
w=openpyxl.load_workbook(P/'附件2.xlsx',read_only=True,data_only=True)
load=np.array(list(w['小区负载'].values)[1:],dtype=object)[:,1:145].astype(float)/6
pv=np.array(list(w['光伏发电实际功率'].values)[1:],dtype=object)[:,1:145].astype(float)/6
rt=np.array(list(openpyxl.load_workbook(P/'附件4.xlsx',read_only=True,data_only=True).active.values)[1:],dtype=object)[:,1:145].astype(float)
report={}; details={}; mx=lambda x:float(np.max(np.abs(x)))
for version,folder,suffix in [('delivered',S/'frozen','.csv.xz'),('regenerated',S/'outputs/c_final_v1/frozen','.csv')]:
 report[version]={};details[version]={}
 for mode in ['q1','q2','q3','q4_2','q4_3']:
  d=pd.read_csv(folder/(mode+'_dispatch'+suffix));details[version][mode]=d
  if mode=='q1':L,V,p=q1load,q1pv,price
  else:
   ix=(pd.to_datetime(d.date)-pd.Timestamp('2025-01-01')).dt.days.to_numpy();j=d.position.to_numpy()-1
   L,V=load[ix,j],pv[ix,j];p=rt[ix,j] if mode.startswith('q4') else price[j]
  B=d.plan_00_grid_kwh.to_numpy();A=d.final_adjusted_grid_kwh.to_numpy();C=d.charge_kwh.to_numpy();D=d.discharge_kwh.to_numpy();soc0=d.soc_start_kwh.to_numpy();soc1=d.soc_end_kwh.to_numpy()
  Q=np.maximum(L+C-V-D-A,0);unused=np.maximum(A+V+D-L-C,0)
  pc=p*B;ac=p*(1.5*np.maximum(A-B,0)-.5*np.maximum(B-A,0));ec=5*p*Q;total=pc+ac+ec
  r=dict(rows=len(d),days=int(d.date.nunique()),first_soc=float(soc0[0]),last_soc=float(soc1[-1]),soc_min=float(min(soc0.min(),soc1.min())),soc_max=float(max(soc0.max(),soc1.max())),max_charge=float(C.max()),max_discharge=float(D.max()),simultaneous=int(((C>1e-7)&(D>1e-7)).sum()),load_error=mx(L-d.actual_load_kwh),pv_error=mx(V-d.actual_pv_kwh),price_error=mx(p-d.settlement_price),soc_step_error=mx(soc1-soc0-.9*C+D/.9),soc_link_error=mx(soc0[1:]-soc1[:-1]),emergency_error=mx(Q-d.emergency_kwh),cost_row_error=mx(total-d.final_relative_cost_yuan),plan_cost=float(pc.sum()),adjustment_cost=float(ac.sum()),emergency_cost=float(ec.sum()),total_cost=float(total.sum()),emergency_kwh=float(Q.sum()),emergency_intervals=int((Q>0.00005).sum()),emergency_max_kwh=float(Q.max()),unused_kwh=float(unused.sum()))
  if mode in ['q2','q4_2']:
   r['reserve_diagnostics']=[]
   for delta in [10,20,50]:
    cost=float(np.sum(p*(B+delta)+5*p*np.maximum(L+C-V-D-B-delta,0)))
    r['reserve_diagnostics'].append(dict(delta_kwh=delta,total_cost=cost,savings=r['total_cost']-cost,emergency_kwh=float(np.maximum(Q-delta,0).sum())))
  report[version][mode]=r
 # Reconstruct official chain independently by last commitment; verify both fields and delta billing.
 versions=pd.read_csv(folder/('decision_versions'+suffix))
 for mode in ['q3','q4_3']:
  d=details[version][mode].set_index(['date','position']);v=versions[versions['mode']==mode].copy().sort_values(['decision_time','target_date','position'])
  commitments={};sensitivity={};changes={};fee=0.;sfee=0.;old_err=[]
  for row in v.to_dict('records'):
   key=(row['target_date'],row['position'])
   if key not in d.index:continue
   p=float(d.loc[key,'settlement_price'])
   val=row['new_commitment_kwh']
   if pd.notna(val) and not row['is_preview_next_day'] and not row['is_preview_recourse']:
    if key in commitments:
     delta=val-commitments[key];fee+=p*(delta+.5*abs(delta));changes[key]=changes.get(key,0)+int(abs(delta)>1e-7)
     old_err.append(abs(commitments[key]-row['old_commitment_kwh']))
    commitments[key]=val
   sval=row['sensitivity_new_commitment_kwh']
   if pd.notna(sval) and not row['is_preview_next_day']:
    if key in sensitivity:
     delta=sval-sensitivity[key];sfee+=p*(delta+.5*abs(delta))
    sensitivity[key]=sval
  err=np.array([commitments[k]-float(d.loc[k,'final_adjusted_grid_kwh']) for k in d.index]);serr=np.array([sensitivity[k]-float(d.loc[k,'final_adjusted_grid_kwh']) for k in d.index]);r=report[version][mode]
  sequential=r['plan_cost']+fee+r['emergency_cost'];stored=float(d.sequential_cost_yuan.sum())
  r['chain']=dict(rows=len(v),formal_keys=len(commitments),max_previous_commitment_error=max(old_err),max_final_commitment_error=mx(err),max_effective_changes=max(changes.values()),sequential_actual=sequential,sequential_stored=stored,difference=sequential-stored,sensitivity_mismatch_intervals=int((abs(serr)>1e-7).sum()),sensitivity_l1_kwh=float(abs(serr).sum()),sensitivity_fee_plus_actual_emergency=r['plan_cost']+sfee+r['emergency_cost'])
# independent Q1 LP: G,C,D,unused,E; balance and recurrence, no code import.
n=144;obj=np.r_[price,np.zeros(4*n)];M=np.zeros((2*n,5*n));rhs=np.r_[q1load-q1pv,np.zeros(n)];rhs[n]=6000
for t in range(n):
 M[t,t]=1;M[t,n+t]=-1;M[t,2*n+t]=1;M[t,3*n+t]=-1
 M[n+t,n+t]=-.9;M[n+t,2*n+t]=1/.9;M[n+t,4*n+t]=1
 if t:M[n+t,4*n+t-1]=-1
bounds=[(0,None)]*n+[(0,5000/6)]*(2*n)+[(0,x) for x in q1pv]+[(1200,10800)]*n;bounds[-1]=(6000,6000)
r=linprog(obj,A_eq=M,b_eq=rhs,bounds=bounds,method='highs');report['independent_q1_lp']={'success':r.success,'cost':r.fun}
# specified rows at physical intervals, plus matched official labels
q=details['regenerated']['q1'];specified=[]
for h in [10,12,14,16,18,20]:
 label=f'{h:02d}:00-{h:02d}:10';real=q[q.physical_interval==label].iloc[0];wrong=q[q.official_label==label].iloc[0]
 specified.append(dict(interval=label,physical_position=int(real.position),correct_kwh=float(real.plan_00_grid_kwh),export_label_extraction_kwh=float(wrong.plan_00_grid_kwh),difference=float(wrong.plan_00_grid_kwh-real.plan_00_grid_kwh),wrong_physical_interval=wrong.physical_interval))
report['q1_specified']=specified
# original data hash agreement across both available source locations
report['original_data_hashes']=[]
for f in (ROOT/'work/problem').rglob('*'):
 if not f.is_file():continue
 rel=f.relative_to(ROOT/'work/problem');other=Path('/Users/frihed/Desktop/CUMCM2026Problems/C题')/rel
 report['original_data_hashes'].append(dict(path=str(rel),sha256=hashlib.sha256(f.read_bytes()).hexdigest(),matches_config_source=other.exists() and hashlib.sha256(other.read_bytes()).hexdigest()==hashlib.sha256(f.read_bytes()).hexdigest()))
# compare two frozen results at field level
report['regeneration_changes']={}
for mode in details['delivered']:
 a=details['delivered'][mode];b=details['regenerated'][mode];cols=a.select_dtypes('number').columns
 report['regeneration_changes'][mode]={c:dict(changed_rows=int((np.abs(a[c]-b[c])>1e-7).sum()),max_abs=mx(a[c]-b[c])) for c in cols if mx(a[c]-b[c])>1e-7}
# current delivered experiment sums, independent difference arithmetic
exp=pd.read_csv(S/'frozen/experiment_summary.csv.xz');exp=exp[exp.model_arm=='all_three'].drop_duplicates(['mode','scenario'],keep='last')
report['delivered_S3_minus_S0']={}
for mode in ['q3','q4_3']:
 z=exp[exp['mode']==mode].set_index('scenario');report['delivered_S3_minus_S0'][mode]={c:float(z.loc['S3',c]-z.loc['S0',c]) for c in ['initial_soc_kwh','plan_cost_yuan','adjustment_cost_yuan','emergency_cost_yuan','final_relative_cost_yuan','emergency_kwh']}
(O/'独立数值复算.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps(report,ensure_ascii=False,indent=2),flush=True)
