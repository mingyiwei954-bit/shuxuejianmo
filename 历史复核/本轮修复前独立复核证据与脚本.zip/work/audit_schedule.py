from pathlib import Path
import sys,json
from datetime import date
import numpy as np
R=Path(__file__).resolve().parent.parent;P=R/'work/snapshot/支撑材料';sys.path.insert(0,str(P))
from src.model.config import load_config
from src.model.data import load_data
from src.model.rolling import simulate,RunSpec
cfg=load_config(P/'config/final.yaml');cfg['_source_root']=str(R/'work/rawroot');data=load_data(cfg);out={}
for initial in [6000.,1200.]:
 runs={}
 for sc in ['S0','S3']:
  runs[sc]=simulate(data,cfg,RunSpec('q3',sc,'all_three'),start_date=date(2025,2,1),end_date=date(2025,2,1),initial_soc=initial)
 a=runs['S0'];b=runs['S3'];aa=np.array([r['plan_00_grid_kwh'] for r in a['dispatch']]);bb=np.array([r['plan_00_grid_kwh'] for r in b['dispatch']]);out[str(initial)]={'S0':a['summary'],'S3':b['summary'],'midnight_plan_different_slots':int((abs(bb-aa)>1e-7).sum()),'midnight_plan_l1_kwh':float(abs(bb-aa).sum()),'midnight_plan_S3_minus_S0_kwh':float((bb-aa).sum()),'max_midnight_plan_difference':float(abs(bb-aa).max())}
(R/'outputs/S0_S3受控日诊断.json').write_text(json.dumps(out,ensure_ascii=False,indent=2));print(json.dumps(out,ensure_ascii=False,indent=2))
