from pathlib import Path
import openpyxl,pandas as pd,numpy as np,json
R=Path(__file__).resolve().parent.parent;P=R/'work/snapshot/支撑材料';out={}
# Storage and emergency sheets independently aggregate all 334 days.
for name,mode in [('result1','q1'),('result2','q2'),('result3','q3'),('result4-2','q4_2'),('result4-3','q4_3')]:
 w=openpyxl.load_workbook(P/f'workbooks/{name}.xlsx',read_only=True,data_only=True);d=pd.read_csv(P/f'frozen/{mode}_dispatch.csv.xz');storage=list(w['充放电量'].values)[1:];date=None;errors=[];socerr=[]
 for row in storage:
  if mode=='q1':day='2025-01-01';span,c,dis,tm,soc=row[:5]
  else:
   if row[0] is not None:date=str(row[0])[:10]
   day=date;span,c,dis,tm,soc=row[1:6]
  if not span:continue
  h=int(span.split(':')[0]);z=d[(d.date==day)&(d.position>h*6)&(d.position<=(h+4)*6)]
  errors.extend([abs(float(c)-z.charge_kwh.sum()),abs(float(dis)-z.discharge_kwh.sum())])
  if tm is not None:
   x=d[d.date==day];val=x.soc_start_kwh.iloc[0] if str(tm).startswith('0:') else x.soc_end_kwh.iloc[-1];socerr.append(abs(float(soc)-val))
 out[mode]={'storage_rows':len(storage),'max_storage_display_error':max(errors),'max_soc_display_error':max(socerr)}
 if mode!='q1':
  expected=[]
  for day,z in d.groupby('date'):
   active=[]
   for x in z.itertuples():
    if x.emergency_kwh>=0.00005:active.append(x)
    elif active:
     a=(active[0].position-1)*10;b=active[-1].position*10;expected.append((day,f'{a//60}:{a%60:02d}-{b//60}:{b%60:02d}',sum(r.emergency_kwh for r in active)));active=[]
   if active:
    a=(active[0].position-1)*10;b=active[-1].position*10;expected.append((day,f'{a//60}:{a%60:02d}-{b//60}:{b%60:02d}',sum(r.emergency_kwh for r in active)))
  actual=[];day=None
  for row in list(w['紧急购电量'].values)[1:]:
   if row[0] is not None:day=str(row[0])[:10]
   actual.append((day,row[1],row[2]))
  out[mode].update(emergency_rows=len(actual),expected_emergency_rows=len(expected),emergency_keys_match=[x[:2] for x in actual]==[x[:2] for x in expected],max_emergency_display_error=max(abs(x[2]-y[2]) for x,y in zip(actual,expected)))
# Companion Q3 workbook, clearly separate lineage.
w=openpyxl.load_workbook(P/'Q3_指定日期论文表.xlsx',read_only=True,data_only=True);d=pd.read_csv(P/'outputs/c_final_v1/frozen/q3_dispatch.csv');extra=[]
for row in list(w['表1_指定时段购电量'].values)[1:]:
 day=row[0];z=d[d.date==day];item=dict(date=day,companion_daily_grid=row[7],frozen_plan_grid=z.plan_00_grid_kwh.sum(),frozen_final_grid=z.final_adjusted_grid_kwh.sum(),companion_daily_cost=row[8],frozen_plan_cost=z.plan_cost_yuan.sum(),frozen_main_cost=z.final_relative_cost_yuan.sum())
 item['specified_comparison']=[]
 for j,h in enumerate([10,12,14,16,18,20]):
  x=z[z.position==h*6+1].iloc[0];item['specified_comparison'].append(dict(interval=x.physical_interval,companion=row[j+1],plan=x.plan_00_grid_kwh,final=x.final_adjusted_grid_kwh))
 extra.append(item)
out['companion_Q3']=extra
(R/'outputs/表格逐项复验.json').write_text(json.dumps(out,ensure_ascii=False,indent=2));print(json.dumps(out,ensure_ascii=False,indent=2))
