# 冻结结果说明

CSV 以 XZ 保存。`decision_versions.csv.xz` 是完整合并账本；为避免重复占用提交空间，未另收录其两个子集 `q3_decision_versions.csv` 与 `q4_3_decision_versions.csv`。
