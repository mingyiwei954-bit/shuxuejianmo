#!/usr/bin/env bash
set -euo pipefail

PROJECT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$PROJECT_DIR"
TASK_PY_PATH="$PROJECT_DIR"
if [[ -d "$PROJECT_DIR/work/python_deps" ]]; then
  TASK_PY_PATH="$PROJECT_DIR/work/python_deps:$TASK_PY_PATH"
fi
export PYTHONPATH="$TASK_PY_PATH${PYTHONPATH:+:$PYTHONPATH}"

CONFIG_PATH="config/final.yaml"
SKIP_MODEL=0
while [[ $# -gt 0 ]]; do
  case "$1" in
    --config) CONFIG_PATH="$2"; shift 2 ;;
    --skip-model) SKIP_MODEL=1; shift ;;
    *) echo "Unknown argument: $1" >&2; exit 2 ;;
  esac
done

RUNTIME_BASE="${HOME}/.cache/codex-runtimes/codex-primary-runtime/dependencies"
PY_BIN="${CODEX_PYTHON_BIN:-${RUNTIME_BASE}/python/bin/python3}"
NODE_BIN="${CODEX_NODE_BIN:-${RUNTIME_BASE}/node/bin/node}"
NODE_PACKAGES="${CODEX_NODE_MODULES:-${RUNTIME_BASE}/node/node_modules}"
if [[ ! -x "$PY_BIN" ]]; then PY_BIN="python3"; fi
if [[ ! -x "$NODE_BIN" ]]; then NODE_BIN="node"; fi

if [[ ! -e node_modules ]]; then ln -s "$NODE_PACKAGES" node_modules; fi

mkdir -p outputs/c_final_v1/logs outputs/c_final_v1/qa work/paper_build

# The bundled headless LibreOffice uses its own fontconfig.  When this
# workspace-specific configuration is present, expose the system CJK font to
# the converter so Chinese glyphs are embedded in the final PDFs.
if [[ -f "$PROJECT_DIR/work/fontconfig/fonts.conf" ]]; then
  export FONTCONFIG_FILE="$PROJECT_DIR/work/fontconfig/fonts.conf"
fi

if [[ "$SKIP_MODEL" -eq 0 ]]; then
  "$PY_BIN" scripts/run_model.py --config "$CONFIG_PATH" --scope official 2>&1 | tee outputs/c_final_v1/logs/model_official.log
  "$PY_BIN" scripts/run_model.py --config "$CONFIG_PATH" --scope pre-parallel 2>&1 | tee outputs/c_final_v1/logs/model_experiments.log
  "$PY_BIN" scripts/run_model.py --config "$CONFIG_PATH" --scope stability 2>&1 | tee outputs/c_final_v1/logs/model_stability.log
fi

"$PY_BIN" scripts/validate_model_outputs.py --config "$CONFIG_PATH" 2>&1 | tee outputs/c_final_v1/logs/model_validation.log

"$NODE_BIN" scripts/build_workbooks.mjs 2>&1 | tee outputs/c_final_v1/logs/workbook_run.log
"$PY_BIN" src/audit/audit_final.py --config "$CONFIG_PATH" --results-dir outputs/c_final_v1 --output-dir outputs/c_final_v1/audit 2>&1 | tee outputs/c_final_v1/logs/audit_run.log
"$PY_BIN" scripts/freeze_results.py 2>&1 | tee outputs/c_final_v1/logs/freeze_run.log
"$PY_BIN" scripts/make_charts.py 2>&1 | tee outputs/c_final_v1/logs/chart_run.log
"$PY_BIN" scripts/make_evidence.py 2>&1 | tee outputs/c_final_v1/logs/evidence_run.log
"$PY_BIN" scripts/build_documents.py 2>&1 | tee outputs/c_final_v1/logs/document_build.log

DOC_SKILL="${HOME}/.codex/plugins/cache/openai-primary-runtime/documents/26.905.11957/skills/documents"
"$PY_BIN" "$DOC_SKILL/scripts/privacy_scrub.py" outputs/c_final_v1/paper/C题论文.docx --out work/paper_build/C题论文_scrubbed.docx
mv work/paper_build/C题论文_scrubbed.docx outputs/c_final_v1/paper/C题论文.docx
"$PY_BIN" "$DOC_SKILL/scripts/privacy_scrub.py" work/paper_build/AI工具使用详情.docx --out work/paper_build/AI工具使用详情_scrubbed.docx

PAPER_RENDER="$(mktemp -d "${TMPDIR:-/tmp}/cumcm-paper-render.XXXXXX")"
AI_RENDER="$(mktemp -d "${TMPDIR:-/tmp}/cumcm-ai-render.XXXXXX")"
trap 'rm -rf "$PAPER_RENDER" "$AI_RENDER"' EXIT
"$PY_BIN" "$DOC_SKILL/render_docx.py" outputs/c_final_v1/paper/C题论文.docx --output_dir "$PAPER_RENDER" --emit_pdf
"$PY_BIN" "$DOC_SKILL/render_docx.py" work/paper_build/AI工具使用详情_scrubbed.docx --output_dir "$AI_RENDER" --emit_pdf
cp "$PAPER_RENDER/C题论文.pdf" outputs/c_final_v1/paper/C题论文.pdf
cp "$AI_RENDER/AI工具使用详情_scrubbed.pdf" outputs/c_final_v1/paper/AI工具使用详情.pdf
mkdir -p outputs/c_final_v1/qa/paper_render outputs/c_final_v1/qa/ai_render
cp "$PAPER_RENDER"/page-*.png outputs/c_final_v1/qa/paper_render/
cp "$AI_RENDER"/page-*.png outputs/c_final_v1/qa/ai_render/

"$PY_BIN" scripts/package_final.py 2>&1 | tee outputs/c_final_v1/logs/package_run.log
"$PY_BIN" scripts/qa_final.py 2>&1 | tee outputs/c_final_v1/logs/final_qa.log

echo "C题完整竞赛包已生成：outputs/c_final_v1"
