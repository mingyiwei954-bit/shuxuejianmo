#!/usr/bin/env python3
"""Inject frozen results into the paper and create the final DOCX sources."""
from __future__ import annotations

import csv
import json
import re
import shutil
from pathlib import Path

import numpy as np
import pandas as pd
from docx import Document
from docx.enum.section import WD_SECTION
from docx.enum.table import WD_ALIGN_VERTICAL, WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_BREAK, WD_LINE_SPACING
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt, RGBColor


ROOT = Path(__file__).resolve().parents[1]
FINAL = ROOT / "outputs" / "c_final_v1"
FROZEN = FINAL / "frozen"
PAPER = FINAL / "paper"
CHARTS = FINAL / "charts"
WORK = ROOT / "work" / "paper_build"
# Arial Unicode MS is available as a TrueType font to the bundled headless
# converter and contains the complete Simplified Chinese glyph set. macOS TTC
# family names such as Songti SC/Heiti SC are visible to desktop applications
# but are not resolved reliably by this conversion runtime.
BODY_FONT = "Arial Unicode MS"
HEADING_FONT = "Arial Unicode MS"


def csv_rows(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def fmt_value(key: str, value: object) -> str:
    if isinstance(value, str):
        return value
    if any(x in key for x in ("COUNT", "N_DAYS", "ROWS")):
        return f"{int(value):d}"
    x = float(value)
    if "RESIDUAL" in key:
        return f"{x:.3e}"
    if any(xk in key for xk in ("KWH", "SOC_MIN", "SOC_MAX")):
        return f"{x:,.4f}"
    if "PERCENT" in key:
        return f"{x:.2f}"
    return f"{x:,.2f}"


def find(rows: list[dict[str, str]], **terms: str) -> dict[str, str]:
    found = [r for r in rows if all(str(r.get(k)) == str(v) for k, v in terms.items())]
    if not found:
        raise KeyError(terms)
    return found[-1]


def comparison_sentence(mode: str, exp: list[dict[str, str]], arm: str, baseline: str = "raw_baseline") -> str:
    a = find(exp, mode=mode, scenario="S3", model_arm=arm)
    b = find(exp, mode=mode, scenario="S3", model_arm=baseline)
    diff = float(a["final_relative_cost_yuan"]) - float(b["final_relative_cost_yuan"])
    em = float(a["emergency_kwh"]) - float(b["emergency_kwh"])
    verb = "减少" if diff < 0 else "增加"
    emverb = "减少" if em < 0 else "增加"
    return f"{mode.upper().replace('_', '-')} 中，三项组合相对原始因果基线费用{verb}{abs(diff):,.2f}元，紧急购电量{emverb}{abs(em):,.4f}kWh。"


def ablation_table(exp: list[dict[str, str]]) -> str:
    labels = {
        "raw_baseline": "原始预测基线", "crossday_only": "仅跨日终端", "bias_only": "仅偏差校正",
        "bias_crossday": "偏差校正+跨日", "scenario_crossday": "场景+跨日", "all_three": "三项组合",
    }
    lines = ["| 模式 | 实验组 | 总费用 元 | 紧急购电 kWh | 未用能量 kWh |", "|---|---|---:|---:|---:|"]
    seen = set()
    for r in exp:
        key = (r["mode"], r["scenario"], r["model_arm"])
        if r["scenario"] != "S3" or r["model_arm"] not in labels or key in seen:
            continue
        seen.add(key)
        lines.append(f"| {r['mode'].upper().replace('_', '-')} | {labels[r['model_arm']]} | {float(r['final_relative_cost_yuan']):,.2f} | {float(r['emergency_kwh']):,.4f} | {float(r['unused_surplus_kwh']):,.4f} |")
    return "\n".join(lines)


def group_emergency(frame: pd.DataFrame, threshold: float) -> list[tuple[str, str, float]]:
    out = []
    for day, part in frame.groupby("date", sort=True):
        part = part.sort_values("position")
        current = None
        for row in part.itertuples():
            q = float(row.emergency_kwh); pos = int(row.position)
            if q < threshold:
                if current is not None: out.append((str(day), interval(current[0], current[1]), current[2])); current = None
                continue
            if current is None: current = [pos, pos, q]
            elif pos == current[1] + 1: current[1] = pos; current[2] += q
            else: out.append((str(day), interval(current[0], current[1]), current[2])); current = [pos, pos, q]
        if current is not None: out.append((str(day), interval(current[0], current[1]), current[2]))
    return out


def interval(start_pos: int, end_pos: int) -> str:
    def hm(minutes: int) -> str:
        return f"{minutes//60}:{minutes%60:02d}"
    return f"{hm((start_pos-1)*10)}-{hm(end_pos*10)}"


def appendix_tables(cfg: dict) -> str:
    selected = {"2025-03-20", "2025-06-21", "2025-09-23", "2025-12-21"}
    chunks = ["### 指定日期结果表", "", "以下各表由全精度执行明细自动生成；紧急区间按配置的四位显示阈值重建。"]
    q1 = pd.read_csv(FROZEN / "q1_dispatch.csv").sort_values("position")
    wanted = ["10:00-10:10", "12:00-12:10", "14:00-14:10", "16:00-16:10", "18:00-18:10", "20:00-20:10"]
    chunks += ["", "#### Q1 指定时段购电量", "", "| 时间段 | 购电量 kWh |", "|---|---:|"]
    for label in wanted:
        r = q1[q1["official_label"] == label]
        if len(r): chunks.append(f"| {label} | {float(r.iloc[0]['plan_00_grid_kwh']):,.4f} |")
    chunks += ["", "| 全天购电量 kWh | 全天购电费 元 |", "|---:|---:|", f"| {q1['plan_00_grid_kwh'].sum():,.4f} | {q1['plan_cost_yuan'].sum():,.2f} |", "", "#### Q1 四小时充放电量", "", "| 时间段 | 充电量 kWh | 放电量 kWh |", "|---|---:|---:|"]
    for block in range(6):
        p = q1.iloc[block*24:(block+1)*24]
        chunks.append(f"| {block*4}:00-{(block+1)*4}:00 | {p['charge_kwh'].sum():,.4f} | {p['discharge_kwh'].sum():,.4f} |")
    chunks += ["", "0:00 与 24:00 储电量均为 6000.0000 kWh。"]
    for name, title in (("q2_dispatch.csv", "Q2"), ("q3_dispatch.csv", "Q3"), ("q4_2_dispatch.csv", "Q4-2"), ("q4_3_dispatch.csv", "Q4-3")):
        d = pd.read_csv(FROZEN / name)
        d = d[d["date"].isin(selected)]
        chunks += ["", f"#### {title} 指定日期汇总", "", "| 日期 | 0点计划量 kWh | 最终购电量 kWh | 总费用 元 | 紧急购电量 kWh |", "|---|---:|---:|---:|---:|"]
        for day, p in d.groupby("date", sort=True):
            chunks.append(f"| {day} | {p['plan_00_grid_kwh'].sum():,.4f} | {p['final_adjusted_grid_kwh'].sum():,.4f} | {p['final_relative_cost_yuan'].sum():,.2f} | {p['emergency_kwh'].sum():,.4f} |")
        chunks += ["", f"#### {title} 指定日期紧急购电区间", "", "| 日期 | 紧急购电时间段 | 购电量 kWh |", "|---|---|---:|"]
        groups = group_emergency(d, float(cfg["audit"]["emergency_display_omit_threshold_kwh"]))
        if groups:
            for day, span, amount in groups:
                chunks.append(f"| {day} | {span} | {amount:,.4f} |")
        else:
            chunks.append("| 四个指定日期 | 无 | 0.0000 |")
    return "\n".join(chunks)


def source_code_appendix() -> str:
    """Embed the complete runnable delivery source without machine-specific paths."""
    paths = [ROOT / "config" / "final.yaml", ROOT / "requirements.txt", ROOT / "run_pipeline.sh"]
    paths += sorted((ROOT / "src").rglob("*.py"))
    paths += sorted((ROOT / "scripts").glob("*.py"))
    paths += sorted((ROOT / "scripts").glob("*.mjs"))
    paths += sorted((ROOT / "tests").glob("*.py"))
    chunks = ["### 完整可运行源程序", "", "以下代码与支撑材料中的同名文件一致；运行入口为 run_pipeline.sh。"]
    for path in paths:
        rel = path.relative_to(ROOT).as_posix()
        chunks.extend(["", f"#### {rel}", "", "```text", path.read_text(encoding="utf-8"), "```"])
    return "\n".join(chunks)


def expand_paper() -> str:
    registry = json.loads((FROZEN / "frozen_results.json").read_text(encoding="utf-8"))["values"]
    exp = csv_rows(FROZEN / "experiment_summary.csv")
    monthly = csv_rows(FROZEN / "monthly_effects.csv")
    draft = (ROOT / "work" / "paper_agent" / "paper_outline_and_draft.md").read_text(encoding="utf-8")
    for key, value in registry.items():
        token = "{{" + f"RESULT:{key}" + "}}"
        draft = draft.replace(token, fmt_value(key, value))

    q3label = str(registry["Q3.S2_S3.STABILITY_LABEL"]); q43label = str(registry["Q4_3.S2_S3.STABILITY_LABEL"])
    q3diff = float(registry["Q3.S2_S3.DIFF_YUAN"]); q43diff = float(registry["Q4_3.S2_S3.DIFF_YUAN"])
    complex_values = {
        "Q3.ABLATION_NARRATIVE": comparison_sentence("q3", exp, "all_three"),
        "ABLATION.COMBINED_ANALYSIS": comparison_sentence("q3", exp, "all_three") + " " + comparison_sentence("q4_3", exp, "all_three") + "\n\n[[FIGURE:fig1_ablation_cost.png|六组增强消融的总费用比较]]\n\n[[FIGURE:fig2_update_schedule.png|最终组合模型的 S0-S3 更新频率比较]]",
        "Q3.S2_S3.CONCLUSION_SENTENCE": ("S2 与 S3 的差异在多求解器复算中数值不可区分，不据此主张18点更新有稳定收益。" if "不可区分" in q3label else f"在本数据和口径下，S3相对S2的费用差稳定为{q3diff:,.2f}元。"),
        "Q4_3.S2_S3.CONCLUSION_SENTENCE": ("S2 与 S3 的差异在多求解器复算中数值不可区分，不据此主张18点更新有稳定收益。" if "不可区分" in q43label else f"在本数据和口径下，S3相对S2的费用差稳定为{q43diff:,.2f}元。"),
        "MONTHLY_AND_BLOCK_ANALYSIS": "逐月差异未采用跨月平均替代，各月均从逐日配对费用计算。完整点估计和7天移动块区间见冻结比较表；区间跨0时不作显著性表述。\n\n[[FIGURE:fig4_monthly_effects.png|三项组合相对原始因果基线的逐月费用差和移动块区间]]",
        "SETTLEMENT_SENSITIVITY_ANALYSIS": f"Q3 S3 的逐次结算比主口径高{float(registry['Q3.S3.SEQUENTIAL_COST_YUAN'])-float(registry['Q3.S3.TOTAL_COST_YUAN']):,.2f}元；Q4-3 S3 相差{float(registry['Q4_3.S3.SEQUENTIAL_COST_YUAN'])-float(registry['Q4_3.S3.TOTAL_COST_YUAN']):,.2f}元。\n\n[[FIGURE:fig3_cost_components.png|最终组合策略的费用分项]]",
        "PERFECT_INFORMATION_GAP_ANALYSIS": f"Q2 因果策略比完全信息对照高{float(registry['Q2.CAUSAL.TOTAL_COST_YUAN'])-float(registry['Q2.PERFECT_INFO.TOTAL_COST_YUAN']):,.2f}元；Q4-2 的对应差额为{float(registry['Q4_2.CAUSAL.TOTAL_COST_YUAN'])-float(registry['Q4_2.PERFECT_INFO.TOTAL_COST_YUAN']):,.2f}元。",
        "SOLVER_STABILITY_TABLE": "frozen/stability_summary.csv",
        "FINAL_CONCLUSIONS_NUMBERED": "1. 确定性 LP 能在题设边界内完成日内削峰填谷。\n2. 因果日前结果与完全信息结果存在明确的信息差距，正式结果不使用未来实际量。\n3. 24小时跨日窗口、偏差校正和历史残差场景的作用由同口径消融确定，不能由单次费用差单独归因。\n4. S2-S3 结论严格服从多求解器和分币稳定性门。",
        "REPRODUCIBILITY_APPENDIX": "model_run_summary.json、resolved_config.json、frozen_manifest.json 和 SHA256SUMS.json",
        "PROVENANCE_TABLE": "evidence/result_provenance.csv",
    }
    for key, value in complex_values.items():
        token = "{{" + f"RESULT:{key}" + "}}"
        draft = draft.replace(token, value)
    draft = draft.replace("六组消融的完整表由 `Q3.ABLATION_TABLE` 注入。", "六组消融结果如下。\n\n" + ablation_table(exp))
    draft = draft.replace("论文最终版还应自动插入题面表 1 和表 2 的指定时段结果，数据键分别为 `Q1.SPECIFIED_PURCHASE_ROWS` 和 `Q1.FOUR_HOUR_STORAGE_ROWS`。", "题面指定时段和四小时储能汇总列入附录指定日期结果表。")
    draft = draft.replace("各次求解均保存全精度目标和可行性残差。", "各次求解均保存全精度目标和可行性残差。\n\n[[FIGURE:fig6_stability.png|S2与S3的多求解器和并列破除系数复算]]")
    draft = draft.replace("统一流水线按以下顺序运行", "[[FIGURE:fig5_representative_day.png|代表日的计划购电、最终执行、紧急购电与SOC轨迹]]\n\n统一流水线按以下顺序运行")
    cfg = json.loads((FROZEN / "resolved_config.json").read_text(encoding="utf-8"))
    draft += "\n\n" + appendix_tables(cfg) + "\n\n" + source_code_appendix() + "\n"
    unresolved = sorted(set(re.findall(r"\{\{RESULT:[^}]+\}\}", draft)))
    if unresolved:
        raise RuntimeError("Unresolved paper placeholders: " + ", ".join(unresolved))
    return draft


def clean_inline(text: str) -> str:
    text = re.sub(r"\[([^\]]+)\]\((https?://[^)]+)\)", r"\1（\2）", text)
    return text.replace("`", "")


def set_cell_shading(cell, fill: str) -> None:
    tc_pr = cell._tc.get_or_add_tcPr(); shd = tc_pr.find(qn("w:shd"))
    if shd is None: shd = OxmlElement("w:shd"); tc_pr.append(shd)
    shd.set(qn("w:fill"), fill)


def set_cell_borders(cell, color: str = "D9D9D9") -> None:
    tc_pr = cell._tc.get_or_add_tcPr(); borders = tc_pr.first_child_found_in("w:tcBorders")
    if borders is None: borders = OxmlElement("w:tcBorders"); tc_pr.append(borders)
    for edge in ("top", "left", "bottom", "right", "insideH", "insideV"):
        node = borders.find(qn(f"w:{edge}"))
        if node is None: node = OxmlElement(f"w:{edge}"); borders.append(node)
        node.set(qn("w:val"), "single"); node.set(qn("w:sz"), "4"); node.set(qn("w:color"), color)


def repeat_header(row) -> None:
    tr_pr = row._tr.get_or_add_trPr(); tbl_header = OxmlElement("w:tblHeader"); tbl_header.set(qn("w:val"), "true"); tr_pr.append(tbl_header)


def add_page_number(paragraph) -> None:
    paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = paragraph.add_run(); begin = OxmlElement("w:fldChar"); begin.set(qn("w:fldCharType"), "begin")
    instr = OxmlElement("w:instrText"); instr.set(qn("xml:space"), "preserve"); instr.text = " PAGE "
    separate = OxmlElement("w:fldChar"); separate.set(qn("w:fldCharType"), "separate")
    end = OxmlElement("w:fldChar"); end.set(qn("w:fldCharType"), "end")
    run._r.extend([begin, instr, separate, end])


def configure(doc: Document) -> None:
    section = doc.sections[0]; section.page_width = Cm(21); section.page_height = Cm(29.7)
    section.top_margin = Cm(2.5); section.bottom_margin = Cm(2.5); section.left_margin = Cm(2.5); section.right_margin = Cm(2.5)
    styles = doc.styles
    normal = styles["Normal"]; normal.font.name = BODY_FONT; normal.font.size = Pt(10.5)
    normal._element.rPr.rFonts.set(qn("w:eastAsia"), BODY_FONT)
    normal.paragraph_format.line_spacing = 1.25; normal.paragraph_format.space_after = Pt(3)
    for style_name, size, font in (("Title", 18, HEADING_FONT), ("Heading 1", 14, HEADING_FONT), ("Heading 2", 12, HEADING_FONT), ("Heading 3", 11, HEADING_FONT)):
        st = styles[style_name]; st.font.name = font; st.font.size = Pt(size); st.font.color.rgb = RGBColor(0, 0, 0); st.font.bold = True
        st._element.rPr.rFonts.set(qn("w:eastAsia"), font); st.paragraph_format.keep_with_next = True
    styles["Title"].paragraph_format.space_after = Pt(12)
    add_page_number(section.footer.paragraphs[0])


def add_table(doc: Document, lines: list[str]) -> None:
    data = [[clean_inline(x.strip()) for x in line.strip().strip("|").split("|")] for line in lines if not re.match(r"^\s*\|?\s*:?-+", line)]
    if not data: return
    cols = max(map(len, data)); table = doc.add_table(rows=len(data), cols=cols); table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = True
    for i, row in enumerate(data):
        for j in range(cols):
            cell = table.cell(i, j); cell.text = row[j] if j < len(row) else ""; cell.vertical_alignment = WD_ALIGN_VERTICAL.CENTER; set_cell_borders(cell)
            for p in cell.paragraphs:
                p.paragraph_format.space_after = Pt(0); p.alignment = WD_ALIGN_PARAGRAPH.CENTER if j == 0 or i == 0 else WD_ALIGN_PARAGRAPH.LEFT
                for run in p.runs:
                    run.font.name = BODY_FONT; run.font.size = Pt(8.5); run._element.rPr.rFonts.set(qn("w:eastAsia"), BODY_FONT)
                    if i == 0: run.font.bold = True; run.font.color.rgb = RGBColor(255,255,255)
            if i == 0: set_cell_shading(cell, "1F4E78")
            elif i % 2 == 0: set_cell_shading(cell, "F4F7FA")
    repeat_header(table.rows[0])
    doc.add_paragraph().paragraph_format.space_after = Pt(1)


def markdown_to_docx(text: str, output: Path) -> None:
    doc = Document(); configure(doc)
    lines = text.splitlines(); i = 0; in_code = False
    while i < len(lines):
        line = lines[i]
        if line.startswith("``` ") or line.startswith("```"):
            in_code = not in_code; i += 1; continue
        if in_code:
            p = doc.add_paragraph()
            p.paragraph_format.space_after = Pt(0)
            p.paragraph_format.line_spacing = 1.0
            run = p.add_run(line if line else " ")
            run.font.name = "Consolas"; run.font.size = Pt(6.5)
            run._element.rPr.rFonts.set(qn("w:eastAsia"), BODY_FONT)
            i += 1; continue
        if line.startswith("|") and i + 1 < len(lines) and lines[i + 1].startswith("|"):
            block = []
            while i < len(lines) and lines[i].startswith("|"):
                block.append(lines[i]); i += 1
            add_table(doc, block); continue
        fig = re.fullmatch(r"\[\[FIGURE:([^|]+)\|(.+)\]\]", line.strip())
        if fig:
            p = doc.add_paragraph(); p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            p.add_run().add_picture(str(CHARTS / fig.group(1)), width=Cm(15.2))
            cap = doc.add_paragraph(f"图  {fig.group(2)}"); cap.alignment = WD_ALIGN_PARAGRAPH.CENTER
            for run in cap.runs: run.font.size = Pt(9); run.font.name = BODY_FONT; run._element.rPr.rFonts.set(qn("w:eastAsia"), BODY_FONT)
            i += 1; continue
        if line.startswith("# "):
            p = doc.add_paragraph(clean_inline(line[2:]), style="Title"); p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        elif line.startswith("## "):
            heading = clean_inline(line[3:])
            if heading.strip() == "附录":
                doc.add_page_break()
            doc.add_paragraph(heading, style="Heading 1")
        elif line.startswith("### "):
            doc.add_paragraph(clean_inline(line[4:]), style="Heading 2")
        elif line.startswith("#### "):
            doc.add_paragraph(clean_inline(line[5:]), style="Heading 3")
        elif re.match(r"^\d+\.\s+", line):
            doc.add_paragraph(clean_inline(re.sub(r"^\d+\.\s+", "", line)), style="List Number")
        elif line.startswith("- "):
            doc.add_paragraph(clean_inline(line[2:]), style="List Bullet")
        elif not line.strip():
            pass
        else:
            p = doc.add_paragraph(); p.paragraph_format.first_line_indent = Pt(21)
            p.paragraph_format.keep_together = False
            run = p.add_run(clean_inline(line));
        i += 1
    output.parent.mkdir(parents=True, exist_ok=True); doc.save(output)


def expand_ai() -> str:
    text = (ROOT / "work" / "paper_agent" / "AI工具使用详情_内容稿.md").read_text(encoding="utf-8")
    text = text.replace("状态：内容模板", "状态：机器核验完成；提交前仍须团队人工签核")
    text = text.replace(
        "核心建模选择、题意解释、参数冻结、结果取舍和最终提交由参赛队审核后决定。参赛队对拟提交的模型、程序、数值、引文和文字逐项进行人工审查与核实。",
        "核心建模选择、题意解释、参数冻结、结果取舍和最终提交须由参赛队审核决定；提交前还须对模型、程序、数值、引文和文字逐项人工审查与核实。",
    )
    text = text.replace("GPT-5 系列；最终以任务界面显示名称补录", "GPT-5（Codex 任务运行环境）")
    text = text.replace(
        "下表必须根据实际会话界面、导出日志或账户记录补齐。未知型号不能猜填；应写“平台未显示具体型号”，并保留可核验的截图或导出记录。",
        "下表根据现有会话环境和留存文件如实登记；无法从旧文件验证的型号明确标注，不作猜测。",
    )
    text = text.replace(
        "| A2 | 先前参与本题的其他AI工具 | `{{AI_VENDOR:A2}}` | `{{AI_MODEL:A2}}` | `{{AI_DATE:A2}}` | `{{AI_LOG:A2}}` | `{{AI_USED:A2}}` |",
        "| A2 | 先前参与本题的AI智能体 | 无法由现有文件验证 | 无法由现有文件验证 | 旧成果生成阶段 | outputs/c_audit_v1 与原结果文件 | 是，作为旧成果与审计对象 |",
    )
    text = text.replace("{{AI_LOG:A1}}", "model_run_summary.json、audit_run.log 与 SHA-256 清单")
    text = "\n".join(line for line in text.splitlines() if not any(tag in line for tag in ("{{AI_MODEL:A3}}", "{{AI_DATE:A3}}", "{{AI_USED:A3}}")))
    replacements = {
        "{{EVIDENCE:TIME_MAPPING}}": "frozen/time_index.csv", "{{EVIDENCE:CAUSAL_AUDIT}}": "audit/audit_report.md与frozen/decision_versions.csv",
        "{{EVIDENCE:SETTLEMENT}}": "audit/settlement_recalculation.csv", "{{EVIDENCE:ROLLING}}": "frozen/q3_decision_versions.csv与q4_3_decision_versions.csv",
        "{{EVIDENCE:PAPER_QA}}": "evidence/result_provenance.csv与SHA256SUMS.json",
    }
    for k, v in replacements.items(): text = text.replace(k, v)
    text = text.split("## 发布前必须删除或替换的标记", 1)[0].rstrip() + "\n"
    result_example = "`" + "{{" + "RESULT:...}}" + "`"
    text = text.replace(result_example, "冻结结果键")
    leftovers = re.findall(r"\{\{[^}]+\}\}", text)
    if leftovers: raise RuntimeError(f"Unresolved AI detail placeholders: {leftovers}")
    return text


def main() -> None:
    PAPER.mkdir(parents=True, exist_ok=True); WORK.mkdir(parents=True, exist_ok=True)
    expanded = expand_paper(); source = FINAL / "evidence" / "paper_source_frozen.md"; source.parent.mkdir(parents=True, exist_ok=True); source.write_text(expanded, encoding="utf-8")
    markdown_to_docx(expanded, PAPER / "C题论文.docx")
    ai = expand_ai(); (FINAL / "evidence" / "AI工具使用详情_冻结稿.md").write_text(ai, encoding="utf-8")
    markdown_to_docx(ai, WORK / "AI工具使用详情.docx")
    print(json.dumps({"paper_docx": str(PAPER / 'C题论文.docx'), "ai_docx": str(WORK / 'AI工具使用详情.docx')}, ensure_ascii=False))


if __name__ == "__main__":
    main()
