#!/usr/bin/env python3
"""Build the single scalar registry consumed by the paper and final checks."""
from __future__ import annotations

import csv
import hashlib
import json
from collections import Counter
from datetime import date
from pathlib import Path

import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
FINAL = ROOT / "outputs" / "c_final_v1"
FROZEN = FINAL / "frozen"


def csv_rows(name: str) -> list[dict[str, str]]:
    with (FROZEN / name).open(encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def find(rows: list[dict[str, str]], **terms: str) -> dict[str, str]:
    found = [r for r in rows if all(str(r.get(k)) == str(v) for k, v in terms.items())]
    if not found:
        raise KeyError(f"No result row for {terms}")
    return found[-1]


def stable_label(rows: list[dict[str, str]], mode: str) -> tuple[str, list[float]]:
    group = [r for r in rows if r["mode"] == mode and r["model_arm"] == "all_three"]
    by = {(r["solver_method"], r["tiebreak"], r["scenario"]): r for r in group}
    diffs = []
    for method in sorted({r["solver_method"] for r in group}):
        for tb in sorted({r["tiebreak"] for r in group}, key=float):
            if (method, tb, "S2") in by and (method, tb, "S3") in by:
                diffs.append(float(by[(method, tb, "S3")]["final_relative_cost_yuan"]) - float(by[(method, tb, "S2")]["final_relative_cost_yuan"]))
    cents = {round(v, 2) for v in diffs}
    signs = {int(np.sign(v)) for v in diffs if abs(v) >= 0.005}
    stable = len(diffs) == 9 and len(cents) == 1 and len(signs) == 1 and 0.0 not in cents
    label = f"稳定到分币（S3-S2={diffs[0]:.2f}元）" if stable else "数值不可区分"
    return label, diffs


def audit_metrics() -> dict[str, float | int]:
    max_balance = 0.0; max_soc = 0.0; soc_min = float("inf"); soc_max = -float("inf"); simultaneous = 0
    eta = 0.9
    for name in ("q1_dispatch.csv", "q2_dispatch.csv", "q3_dispatch.csv", "q4_2_dispatch.csv", "q4_3_dispatch.csv"):
        d = pd.read_csv(FROZEN / name)
        balance = (d["final_adjusted_grid_kwh"] + d["emergency_kwh"] + d["actual_pv_kwh"] + d["discharge_kwh"]
                   - d["actual_load_kwh"] - d["charge_kwh"] - d["unused_surplus_kwh"])
        soc = d["soc_end_kwh"] - d["soc_start_kwh"] - eta*d["charge_kwh"] + d["discharge_kwh"]/eta
        max_balance = max(max_balance, float(balance.abs().max()))
        max_soc = max(max_soc, float(soc.abs().max()))
        soc_min = min(soc_min, float(d[["soc_start_kwh", "soc_end_kwh"]].min().min()))
        soc_max = max(soc_max, float(d[["soc_start_kwh", "soc_end_kwh"]].max().max()))
        simultaneous += int(((d["charge_kwh"] > 1e-7) & (d["discharge_kwh"] > 1e-7)).sum())
    return {"max_balance": max_balance, "max_soc": max_soc, "soc_min": soc_min, "soc_max": soc_max, "simultaneous": simultaneous}


def audit_actual(audit: dict, check_id: str) -> dict:
    matches = [item.get("actual", {}) for item in audit.get("checks", []) if item.get("id") == check_id]
    if not matches:
        raise KeyError(f"Audit check not found: {check_id}")
    return matches[-1]


def main() -> None:
    exp = csv_rows("experiment_summary.csv")
    official = csv_rows("official_summary.csv") if (FROZEN / "official_summary.csv").exists() else exp
    stability = csv_rows("stability_summary.csv")
    comparison = csv_rows("comparison_stats.csv") if (FROZEN / "comparison_stats.csv").exists() else []
    perfect = csv_rows("perfect_information_summary.csv") if (FROZEN / "perfect_information_summary.csv").exists() else []
    audit = json.loads((FINAL / "audit" / "audit_summary.json").read_text(encoding="utf-8"))
    legacy = json.loads((FINAL / "audit" / "legacy_audit_snapshot.json").read_text(encoding="utf-8"))
    q1 = pd.read_csv(FROZEN / "q1_dispatch.csv")
    q1_grid = float(q1["plan_00_grid_kwh"].sum()); q1_cost = float(q1["plan_cost_yuan"].sum())
    no_storage = float((np.maximum(q1["actual_load_kwh"] - q1["actual_pv_kwh"], 0) * q1["settlement_price"]).sum())
    phys = audit_metrics()
    cfg = json.loads((FROZEN / "resolved_config.json").read_text(encoding="utf-8")) if (FROZEN / "resolved_config.json").exists() else json.loads((ROOT / "config" / "final.yaml").read_text(encoding="utf-8"))

    reg: dict[str, object] = {
        "META.N_DAYS": 334,
        "Q1.TOTAL_GRID_KWH": q1_grid,
        "Q1.TOTAL_COST_YUAN": q1_cost,
        "Q1.COST_WITHOUT_STORAGE_YUAN": no_storage,
        "Q1.COST_SAVING_PERCENT": 100 * (no_storage - q1_cost) / no_storage,
        "Q3.SELECTED_ARM": cfg["experiments"]["official_arm"],
        "Q4_3.SELECTED_ARM": cfg["experiments"]["official_arm"],
        "Q3.SELECTED_TERMINAL_RULE": cfg["rolling"]["selected_terminal_rule"],
    }
    for mode, prefix in (("q2", "Q2.CAUSAL"), ("q4_2", "Q4_2.CAUSAL")):
        r = find(official, mode=mode)
        reg[f"{prefix}.TOTAL_COST_YUAN"] = float(r["final_relative_cost_yuan"])
        reg[f"{prefix}.EMERGENCY_KWH"] = float(r["emergency_kwh"])
    for mode, prefix in (("q2", "Q2.PERFECT_INFO"), ("q4_2", "Q4_2.PERFECT_INFO")):
        r = find(perfect, mode=mode)
        reg[f"{prefix}.TOTAL_COST_YUAN"] = float(r["purchase_cost_yuan"])
        reg[f"{prefix}.EMERGENCY_KWH"] = float(r.get("emergency_kwh", 0) or 0)
    for mode, prefix in (("q3", "Q3"), ("q4_3", "Q4_3")):
        s0 = find(exp, mode=mode, scenario="S0", model_arm="all_three")
        for scen in ("S0", "S1", "S2", "S3"):
            r = find(exp, mode=mode, scenario=scen, model_arm="all_three")
            reg[f"{prefix}.{scen}.TOTAL_COST_YUAN"] = float(r["final_relative_cost_yuan"])
            reg[f"{prefix}.{scen}.SEQUENTIAL_COST_YUAN"] = float(r["sequential_cost_yuan"])
            reg[f"{prefix}.{scen}.EMERGENCY_KWH"] = float(r["emergency_kwh"])
            reg[f"{prefix}.{scen}.DIFF_VS_S0_YUAN"] = float(r["final_relative_cost_yuan"]) - float(s0["final_relative_cost_yuan"])
        label, diffs = stable_label(stability, mode)
        reg[f"{prefix}.S2_S3.STABILITY_LABEL"] = label
        reg[f"{prefix}.S2_S3.DIFF_YUAN"] = float(find(exp, mode=mode, scenario="S3", model_arm="all_three")["final_relative_cost_yuan"]) - float(find(exp, mode=mode, scenario="S2", model_arm="all_three")["final_relative_cost_yuan"])
        if comparison:
            c = find(comparison, mode=mode, comparison="S3_minus_S2_final_relative")
            reg[f"{prefix}.S2_S3.BLOCK_CI95_LOW_YUAN"] = float(c["block_ci_low_yuan"])
            reg[f"{prefix}.S2_S3.BLOCK_CI95_HIGH_YUAN"] = float(c["block_ci_high_yuan"])

    counts = audit.get("status_counts", {})
    legacy_counts = legacy.get("status_counts", {})
    reg.update({
        "AUDIT.PASS_COUNT_NEW": int(counts.get("PASS", 0)),
        "AUDIT.WARN_COUNT_NEW": int(counts.get("WARN", 0)),
        "AUDIT.FAIL_COUNT_NEW": int(counts.get("FAIL", 0)),
        "AUDIT.LEGACY_FAIL_COUNT": int(legacy_counts.get("FAIL", 0)),
        "AUDIT.LEGACY_NOT_VERIFIABLE_COUNT": int(legacy_counts.get("NOT_VERIFIABLE", 0)),
        "AUDIT.MAX_BALANCE_RESIDUAL_KWH": phys["max_balance"],
        "AUDIT.MAX_SOC_RESIDUAL_KWH": phys["max_soc"],
        "AUDIT.SOC_MIN_KWH": phys["soc_min"],
        "AUDIT.SOC_MAX_KWH": phys["soc_max"],
        "AUDIT.SIMULTANEOUS_COUNT": phys["simultaneous"],
    })
    versions = pd.read_csv(FROZEN / "decision_versions.csv")
    reg["AUDIT.DECISION_VERSION_ROWS"] = int(len(versions))
    future_history = release_violations = past_rewrites = commitment_mismatches = 0
    for workbook in ("result3.xlsx", "result4-3.xlsx"):
        seq = audit_actual(audit, f"FINAL-{workbook}-SETTLEMENT-SEQUENTIAL")
        rel = audit_actual(audit, f"FINAL-{workbook}-FORECAST-RELEASE")
        future_history += int(seq.get("future_history_references", 0))
        release_violations += int(rel.get("violations", 0))
        for chain_name in ("formal_chain", "sensitivity_chain"):
            chain = seq.get(chain_name, {})
            past_rewrites += int(chain.get("past_interval_rewrites", 0))
            commitment_mismatches += int(chain.get("commitment_chain_errors", 0))
        commitment_mismatches += int(seq.get("formal_chain", {}).get("final_dispatch_mismatches", 0))
    reg["AUDIT.FUTURE_HISTORY_REFERENCE_COUNT"] = future_history
    reg["AUDIT.FORECAST_RELEASE_VIOLATION_COUNT"] = release_violations
    reg["AUDIT.PAST_REWRITE_COUNT"] = past_rewrites
    reg["AUDIT.COMMITMENT_MISMATCH_COUNT"] = commitment_mismatches

    out = {"schema_version": "1.0", "values": reg}
    result_path = FROZEN / "frozen_results.json"
    result_path.write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")
    files = sorted(p for p in FROZEN.iterdir() if p.is_file() and p.name != "frozen_manifest.json")
    manifest = {
        "schema_version": "1.0",
        "command": "bash run_pipeline.sh --config config/final.yaml",
        "files": [{"path": p.name, "bytes": p.stat().st_size, "sha256": sha256(p)} for p in files],
    }
    (FROZEN / "frozen_manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({"values": len(reg), "manifest_files": len(files)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
