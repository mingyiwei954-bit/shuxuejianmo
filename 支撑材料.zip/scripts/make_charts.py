#!/usr/bin/env python3
"""Generate the paper figures exclusively from the frozen result files."""
from __future__ import annotations

import csv
from collections import defaultdict
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
FINAL = ROOT / "outputs" / "c_final_v1"
FROZEN = FINAL / "frozen"
CHARTS = FINAL / "charts"

COLORS = {"q3": "#1F4E78", "q4_3": "#C55A11"}


def save(fig: plt.Figure, stem: str) -> None:
    fig.tight_layout()
    fig.savefig(CHARTS / f"{stem}.png", dpi=220, bbox_inches="tight", facecolor="white")
    fig.savefig(CHARTS / f"{stem}.svg", bbox_inches="tight", facecolor="white")
    plt.close(fig)


def main() -> None:
    CHARTS.mkdir(parents=True, exist_ok=True)
    plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 9, "axes.spines.top": False, "axes.spines.right": False})
    exp = pd.read_csv(FROZEN / "experiment_summary.csv").drop_duplicates(
        subset=["mode", "scenario", "model_arm"], keep="last"
    )
    monthly = pd.read_csv(FROZEN / "monthly_effects.csv")
    stab = pd.read_csv(FROZEN / "stability_summary.csv")

    # 1. Pre-registered ablation at S3.
    arms = ["raw_baseline", "crossday_only", "bias_only", "bias_crossday", "scenario_crossday", "all_three"]
    labels = ["Raw", "Cross-day", "Bias", "Bias + cross-day", "Scenarios + cross-day", "All three"]
    fig, ax = plt.subplots(figsize=(9.0, 4.6))
    x = np.arange(len(arms)); width = 0.36
    for offset, mode in [(-width/2, "q3"), (width/2, "q4_3")]:
        d = exp[(exp["mode"] == mode) & (exp["scenario"] == "S3")].set_index("model_arm")
        vals = [float(d.loc[a, "final_relative_cost_yuan"]) / 1e6 if a in d.index else np.nan for a in arms]
        ax.bar(x + offset, vals, width, label=mode.upper().replace("_", "-"), color=COLORS[mode])
    ax.set_xticks(x, labels, rotation=18, ha="right")
    ax.set_ylabel("Settled cost (million yuan)")
    ax.set_title("Ablation under the same causal information boundary")
    ax.legend(frameon=False, ncol=2)
    ax.grid(axis="y", color="#D9D9D9", linewidth=.6)
    save(fig, "fig1_ablation_cost")

    # 2. S0-S3 schedule comparison for the selected model.
    fig, ax = plt.subplots(figsize=(7.4, 4.2))
    schedules = ["S0", "S1", "S2", "S3"]
    for mode in ["q3", "q4_3"]:
        d = exp[(exp["mode"] == mode) & (exp["model_arm"] == "all_three")].set_index("scenario")
        vals = [float(d.loc[s, "final_relative_cost_yuan"]) / 1e6 if s in d.index else np.nan for s in schedules]
        ax.plot(schedules, vals, marker="o", linewidth=2, label=mode.upper().replace("_", "-"), color=COLORS[mode])
    ax.set_ylabel("Settled cost (million yuan)")
    ax.set_xlabel("Forecast update schedule")
    ax.set_title("Value of intraday forecast updates")
    ax.grid(color="#D9D9D9", linewidth=.6)
    ax.legend(frameon=False)
    save(fig, "fig2_update_schedule")

    # 3. Cost composition for the selected S3 strategy.
    d = exp[(exp["scenario"] == "S3") & (exp["model_arm"] == "all_three")].set_index("mode")
    fig, ax = plt.subplots(figsize=(6.7, 4.3))
    modes = [m for m in ["q3", "q4_3"] if m in d.index]
    bottom = np.zeros(len(modes))
    for col, label, color in [
        ("plan_cost_yuan", "00:00 plan", "#5B9BD5"),
        ("adjustment_cost_yuan", "Net adjustment", "#ED7D31"),
        ("emergency_cost_yuan", "Emergency", "#A5A5A5"),
    ]:
        vals = d.loc[modes, col].astype(float).to_numpy() / 1e6
        ax.bar([m.upper().replace("_", "-") for m in modes], vals, bottom=bottom, label=label, color=color)
        bottom += vals
    ax.set_ylabel("Cost component (million yuan)")
    ax.set_title("Cost composition of the selected causal strategy")
    ax.legend(frameon=False)
    ax.grid(axis="y", color="#D9D9D9", linewidth=.6)
    save(fig, "fig3_cost_components")

    # 4. Month-level paired effects and uncertainty intervals.
    fig, axes = plt.subplots(2, 1, figsize=(8.0, 6.5), sharex=True)
    for ax, mode in zip(axes, ["q3", "q4_3"]):
        d = monthly[monthly["mode"] == mode].sort_values("month")
        y = d["difference_yuan"].astype(float).to_numpy() / 1000
        lo = d["block_bootstrap_95_low_yuan"].astype(float).to_numpy() / 1000
        hi = d["block_bootstrap_95_high_yuan"].astype(float).to_numpy() / 1000
        ax.errorbar(d["month"].astype(str), y, yerr=np.vstack([y-lo, hi-y]), marker="o", capsize=3, color=COLORS[mode])
        ax.axhline(0, color="#444444", linewidth=.8)
        ax.set_ylabel("Difference (thousand yuan)")
        ax.set_title(mode.upper().replace("_", "-"))
        ax.grid(axis="y", color="#D9D9D9", linewidth=.6)
    axes[-1].set_xlabel("Month")
    fig.suptitle("All-three strategy minus raw causal baseline")
    save(fig, "fig4_monthly_effects")

    # 5. Representative summer-day operation from the selected Q3 dispatch.
    q3 = pd.read_csv(FROZEN / "q3_dispatch.csv")
    sample_date = "2025-06-21" if (q3["date"] == "2025-06-21").any() else str(q3.iloc[len(q3)//2]["date"])
    day = q3[q3["date"] == sample_date].sort_values("position")
    hours = (day["position"].astype(float).to_numpy() - .5) / 6
    fig, ax1 = plt.subplots(figsize=(9.0, 4.5))
    ax1.plot(hours, day["plan_00_grid_kwh"], label="00:00 plan", color="#7F7F7F", linewidth=1.2)
    ax1.plot(hours, day["final_adjusted_grid_kwh"], label="Executed grid purchase", color="#1F4E78", linewidth=1.6)
    ax1.plot(hours, day["emergency_kwh"], label="Emergency", color="#C00000", linewidth=1.0)
    ax1.set_xlabel("Hour")
    ax1.set_ylabel("Energy per 10 min (kWh)")
    ax2 = ax1.twinx()
    ax2.plot(hours, day["soc_end_kwh"], label="SOC", color="#70AD47", linewidth=1.5)
    ax2.set_ylabel("Stored energy (kWh)")
    lines, labels1 = ax1.get_legend_handles_labels(); lines2, labels2 = ax2.get_legend_handles_labels()
    ax1.legend(lines + lines2, labels1 + labels2, frameon=False, ncol=2, loc="upper center")
    ax1.set_title(f"Representative rolling operation on {sample_date}")
    ax1.grid(color="#D9D9D9", linewidth=.6)
    save(fig, "fig5_representative_day")

    # 6. Pair each S2 run with the exactly matching S3 solver/tie-break run.
    fig, ax = plt.subplots(figsize=(9.0, 4.6))
    stable = stab[(stab["model_arm"] == "all_three") & (stab["scenario"].isin(["S2", "S3"]))].copy()
    methods = ["highs", "highs-ds", "highs-ipm"]
    tiebreaks = sorted(stable["tiebreak"].astype(float).unique())
    pairs = [(m, tb) for m in methods for tb in tiebreaks]
    labels6 = [f"{m}\n{tb:.0e}" for m, tb in pairs]
    x6 = np.arange(len(pairs))
    for mode in ["q3", "q4_3"]:
        dm = stable[stable["mode"] == mode]
        vals = []
        for method, tb in pairs:
            same_tb = (dm["tiebreak"].astype(float) - tb).abs() < 1e-15
            s2 = dm[(dm["scenario"] == "S2") & (dm["solver_method"] == method) & same_tb]
            s3 = dm[(dm["scenario"] == "S3") & (dm["solver_method"] == method) & same_tb]
            vals.append(float(s3.iloc[0]["final_relative_cost_yuan"] - s2.iloc[0]["final_relative_cost_yuan"]) if len(s2) and len(s3) else np.nan)
        ax.plot(x6, vals, marker="o", linewidth=1.6, label=mode.upper().replace("_", "-"), color=COLORS[mode])
    ax.set_xticks(x6, labels6)
    ax.set_ylabel("S3 minus S2 settled cost (yuan)")
    ax.set_title("S2/S3 sensitivity to solver and tie-break coefficient")
    ax.axhline(0, color="#444444", linewidth=.8)
    ax.grid(axis="y", color="#D9D9D9", linewidth=.6)
    ax.legend(frameon=False)
    save(fig, "fig6_stability")

    (CHARTS / "figure_notes.md").write_text(
        "# 图表说明\n\n所有图由 `scripts/make_charts.py` 直接读取 `frozen/` 冻结结果生成。"
        "图1为预注册消融，图2为S0-S3更新次数比较，图3为费用分项，图4为逐月配对差及7天移动块区间，"
        f"图5为{sample_date}代表日，图6为S2/S3多求解器与并列破除系数复算。\n",
        encoding="utf-8",
    )


if __name__ == "__main__":
    main()
