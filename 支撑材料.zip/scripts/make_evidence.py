#!/usr/bin/env python3
"""Create human-readable evidence tables from the frozen result registry."""
from __future__ import annotations

import csv
import hashlib
import json
import shutil
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
FINAL = ROOT / "outputs" / "c_final_v1"
FROZEN = FINAL / "frozen"
EVIDENCE = FINAL / "evidence"


def digest(path: Path) -> str:
    h = hashlib.sha256(path.read_bytes()).hexdigest()
    return h


def rows(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def money(value: str | float) -> str:
    return f"{float(value):,.2f}"


def main() -> None:
    EVIDENCE.mkdir(parents=True, exist_ok=True)
    for name in ("literature_evidence.md", "experiment_plan.md", "format_anonymity_checklist.md"):
        source = ROOT / "work" / "paper_agent" / name
        if source.exists():
            shutil.copy2(source, EVIDENCE / name)

    exp = rows(FROZEN / "experiment_summary.csv")
    official = rows(FROZEN / "official_summary.csv")
    summary_lines = [
        "# 冻结实验结果摘要", "",
        "正式口径为因果策略、2025-02-01 至 2025-12-31、SOC 6000→6000 kWh、最终调整量相对 0:00 计划结算。", "",
        "| 问题 | 计划费 | 调整净费用 | 紧急购电费 | 总费用 | 逐次结算 | 紧急购电量 | 未用能量 |",
        "|---|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for r in official:
        summary_lines.append(
            f"| {r['mode'].upper().replace('_', '-')} | {money(r['plan_cost_yuan'])} | {money(r['adjustment_cost_yuan'])} | "
            f"{money(r['emergency_cost_yuan'])} | {money(r['final_relative_cost_yuan'])} | {money(r['sequential_cost_yuan'])} | "
            f"{float(r['emergency_kwh']):,.4f} | {float(r['unused_surplus_kwh']):,.4f} |"
        )
    (EVIDENCE / "experiment_results.md").write_text("\n".join(summary_lines) + "\n", encoding="utf-8")

    cfg = json.loads((ROOT / "config" / "final.yaml").read_text(encoding="utf-8"))
    contract = f"""# C题最终模型合同

## 时间与信息边界

- 内部十分钟时段按右端点解释附件时间戳；官方结果表标签保持原样，映射保存在 `frozen/time_index.csv`。
- 正式评估区间为 {cfg['study']['official_start']} 至 {cfg['study']['official_end']}；1月只用于训练、偏差估计、场景抽取和终端参数选择。
- 负载与波动电价预测只使用决策日前最近 {cfg['forecast']['same_weekday_profiles']} 个同星期日；实际量只在相应时段执行后用于结算。
- Q3/Q4-3 在 0、6、12、18 时求解未来 {cfg['rolling']['horizon_hours']} 小时并只执行下一个 {cfg['rolling']['execute_hours']} 小时。午夜前的下一日量为预览，不形成正式承诺。

## 电池与费用

- SOC：{cfg['storage']['soc_min_kwh']:.0f}–{cfg['storage']['soc_max_kwh']:.0f} kWh；额定容量 {cfg['storage']['capacity_kwh']:.0f} kWh；功率上限 {cfg['storage']['power_kw']:.0f} kW；充放电效率均为 {cfg['storage']['charge_efficiency']:.2f}。
- 正式端点统一为 {cfg['study']['initial_soc_kwh']:.0f}→{cfg['study']['terminal_soc_kwh']:.0f} kWh。
- 主结算为最终调整量相对 0:00 计划，下调、上调与紧急购电倍率分别为 {cfg['cost']['down_adjustment_multiplier']:.1f}、{cfg['cost']['up_adjustment_multiplier']:.1f}、{cfg['cost']['emergency_multiplier']:.1f}；逐次承诺变化另作敏感性。
- 紧急购电区间从全精度明细重建，仅省略绝对量小于 {cfg['audit']['emergency_display_omit_threshold_kwh']:.5f} kWh、即四位小数显示为 0 的十分钟记录。

## 三项增强

- 光伏偏差校正：按发布时间×提前小时取过去 {cfg['forecast']['bias_window_days']} 天残差均值，截为非负，并用过去 {cfg['forecast']['cap_window_days']} 天相应小时 {cfg['forecast']['cap_quantile']:.3%} 分位数约束异常值。
- 场景滚动：最近最多 {cfg['forecast']['scenario_count']} 条同发布时间完整残差轨迹；首个六小时块非预见，后续允许场景递补；最小化等概率期望费用。
- 终端软目标参数只由1月滚动验证选择；2–12月不再调参。最后一个正式时段强制回到 {cfg['study']['terminal_soc_kwh']:.0f} kWh。

## 可复现与结论门

正式表、图和论文只读取 `frozen/frozen_manifest.json` 登记的数据。S2/S3 使用三种 HiGHS 方法和三种并列破除系数复算；方向或分币不稳定时只能报告“数值不可区分”。完全信息模型仅在证据包中作事后对照。
"""
    (EVIDENCE / "model_contract.md").write_text(contract, encoding="utf-8")

    coverage = """# 要求覆盖表

| 题目或交付要求 | 正式证据 | 验收方式 |
|---|---|---|
| Q1确定性日计划 | `workbooks/result1.xlsx`、`frozen/q1_dispatch.csv` | 144时段、能量平衡、6000→6000 |
| Q2因果日前策略 | `workbooks/result2.xlsx`、`frozen/q2_dispatch.csv` | 历史截止日早于决策、334×144 |
| Q3日内调整 | `workbooks/result3.xlsx`、`frozen/q3_dispatch.csv`、`decision_versions.csv` | 承诺链、过去冻结、两种结算 |
| Q4波动价格 | `workbooks/result4-2.xlsx`、`workbooks/result4-3.xlsx` | 因果价格预测、实际价格事后结算 |
| 24h跨日滚动 | `decision_versions.csv`、SOC列 | 下一日预览、执行块、跨日连续 |
| 三项增强与消融 | `experiment_summary.csv`、`monthly_effects.csv` | 同信息边界、同端点、同结算 |
| 数值稳定性 | `stability_summary.csv` | 3方法×3并列破除系数、分币判断 |
| 工作簿 | 五份result文件、`qa/workbook_build.json` | 重开、重算、错误扫描、逐表渲染 |
| 论文与匿名 | `paper/C题论文.pdf`、`paper/C题论文.docx` | 无目录、正文≤30页、无身份信息 |
| AI披露 | 论文参考文献前声明、`paper/AI工具使用详情.pdf` | 团队人工核对并补录未知模型信息 |
| 支撑材料 | `支撑材料.zip`、`SHA256SUMS.json` | 两文件均小于20MB、哈希冻结 |
"""
    (EVIDENCE / "requirements_coverage.md").write_text(coverage, encoding="utf-8")

    provenance_path = EVIDENCE / "result_provenance.csv"
    with provenance_path.open("w", encoding="utf-8-sig", newline="") as f:
        w = csv.writer(f)
        w.writerow(["artifact", "metric_or_region", "frozen_source", "field", "generation_rule", "source_sha256"])
        mapping = [
            ("result1.xlsx", "全部", "q1_dispatch.csv"), ("result2.xlsx", "全部", "q2_dispatch.csv"),
            ("result3.xlsx", "全部", "q3_dispatch.csv"), ("result4-2.xlsx", "全部", "q4_2_dispatch.csv"),
            ("result4-3.xlsx", "全部", "q4_3_dispatch.csv"),
        ]
        for artifact, region, name in mapping:
            p = FROZEN / name
            w.writerow([artifact, region, f"frozen/{name}", "统一dispatch schema", "scripts/build_workbooks.mjs；四位小数仅在展示层", digest(p)])
        w.writerow(["论文与图", "实验数字", "experiment_summary.csv", "各费用/能量/求解指标", "scripts/make_charts.py与scripts/build_documents.py直接读取", digest(FROZEN / "experiment_summary.csv")])

    legacy = ROOT / "outputs" / "c_audit_v1" / "audit_summary.json"
    if legacy.exists():
        # Preserve every legacy finding/status while removing workstation-specific
        # absolute paths from the anonymous submission copy.
        legacy_text = legacy.read_text(encoding="utf-8")
        legacy_data = json.loads(legacy_text)

        def anonymize(value):
            if isinstance(value, str):
                return value.replace(str(Path.home()), "<LOCAL_HOME>")
            if isinstance(value, list):
                return [anonymize(item) for item in value]
            if isinstance(value, dict):
                return {key: anonymize(item) for key, item in value.items()}
            return value

        (EVIDENCE / "legacy_audit_summary.json").write_text(
            json.dumps(anonymize(legacy_data), ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )


if __name__ == "__main__":
    main()
