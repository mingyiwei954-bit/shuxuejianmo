#!/usr/bin/env python3
"""Build the under-20 MB C-problem support archive and SHA-256 manifest."""
from __future__ import annotations

import hashlib
import json
import lzma
import shutil
import tempfile
import zipfile
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
FINAL = ROOT / "outputs" / "c_final_v1"
MAX_BYTES = 20 * 1024 * 1024


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def copy_if_exists(src: Path, dst: Path) -> None:
    if not src.exists():
        return
    dst.parent.mkdir(parents=True, exist_ok=True)
    if src.is_dir():
        shutil.copytree(
            src,
            dst,
            dirs_exist_ok=True,
            ignore=shutil.ignore_patterns("__pycache__", "*.pyc", ".DS_Store"),
        )
    else:
        shutil.copy2(src, dst)


def main() -> None:
    required = [
        FINAL / "paper" / "C题论文.pdf",
        FINAL / "paper" / "C题论文.docx",
        FINAL / "paper" / "AI工具使用详情.pdf",
        *[FINAL / "workbooks" / n for n in ("result1.xlsx", "result2.xlsx", "result3.xlsx", "result4-2.xlsx", "result4-3.xlsx")],
        FINAL / "audit" / "audit_summary.json",
        FINAL / "frozen" / "frozen_manifest.json",
    ]
    missing = [str(p) for p in required if not p.exists()]
    if missing:
        raise FileNotFoundError("Cannot package; missing:\n" + "\n".join(missing))

    out_zip = FINAL / "支撑材料.zip"
    with tempfile.TemporaryDirectory(prefix="cumcm-support-") as td:
        stage = Path(td) / "支撑材料"
        stage.mkdir(parents=True)
        copy_if_exists(ROOT / "config", stage / "config")
        copy_if_exists(ROOT / "src", stage / "src")
        copy_if_exists(ROOT / "scripts", stage / "scripts")
        copy_if_exists(ROOT / "run_pipeline.sh", stage / "run_pipeline.sh")
        copy_if_exists(ROOT / "requirements.txt", stage / "requirements.txt")
        copy_if_exists(FINAL / "paper" / "AI工具使用详情.pdf", stage / "AI工具使用详情.pdf")
        copy_if_exists(FINAL / "audit", stage / "audit")
        copy_if_exists(FINAL / "evidence", stage / "evidence")
        copy_if_exists(FINAL / "charts", stage / "charts")
        copy_if_exists(FINAL / "workbooks", stage / "workbooks")

        frozen_dst = stage / "frozen"
        frozen_dst.mkdir()
        # The combined ledger is the canonical interface.  The two per-question
        # ledgers are byte-for-byte subsets and are intentionally omitted from
        # the submission archive to avoid packaging large duplicate CSV data.
        duplicate_csv = {"q3_decision_versions.csv", "q4_3_decision_versions.csv"}
        for p in sorted((FINAL / "frozen").glob("*")):
            if p.name in duplicate_csv:
                continue
            if p.suffix == ".csv":
                with p.open("rb") as src, lzma.open(frozen_dst / f"{p.name}.xz", "wb", preset=9) as dst:
                    shutil.copyfileobj(src, dst)
            elif p.suffix in {".json", ".md"}:
                shutil.copy2(p, frozen_dst / p.name)
        (frozen_dst / "README.md").write_text(
            "# 冻结结果说明\n\n"
            "CSV 以 XZ 保存。`decision_versions.csv.xz` 是完整合并账本；"
            "为避免重复占用提交空间，未另收录其两个子集 "
            "`q3_decision_versions.csv` 与 `q4_3_decision_versions.csv`。\n",
            encoding="utf-8",
        )

        internal_manifest = []
        for p in sorted(x for x in stage.rglob("*") if x.is_file()):
            internal_manifest.append({
                "path": p.relative_to(stage).as_posix(),
                "bytes": p.stat().st_size,
                "sha256": sha256(p),
            })
        (stage / "SHA256SUMS.json").write_text(
            json.dumps({"generated_at": datetime.now(timezone.utc).isoformat(), "files": internal_manifest}, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )

        out_zip.parent.mkdir(parents=True, exist_ok=True)
        with zipfile.ZipFile(out_zip, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
            for p in sorted(x for x in stage.rglob("*") if x.is_file()):
                zf.write(p, p.relative_to(stage).as_posix())

    if out_zip.stat().st_size > MAX_BYTES:
        raise RuntimeError(f"Support ZIP is {out_zip.stat().st_size / 1024 / 1024:.2f} MB; limit is 20 MB")

    manifest_entries = []
    for p in sorted(x for x in FINAL.rglob("*") if x.is_file() and x.name != "SHA256SUMS.json"):
        if "qa" in p.relative_to(FINAL).parts:
            continue
        manifest_entries.append({"path": p.relative_to(FINAL).as_posix(), "bytes": p.stat().st_size, "sha256": sha256(p)})
    manifest = {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "support_zip_bytes": out_zip.stat().st_size,
        "support_zip_under_20mb": out_zip.stat().st_size <= MAX_BYTES,
        "paper_pdf_bytes": (FINAL / "paper" / "C题论文.pdf").stat().st_size,
        "paper_pdf_under_20mb": (FINAL / "paper" / "C题论文.pdf").stat().st_size <= MAX_BYTES,
        "files": manifest_entries,
    }
    (FINAL / "SHA256SUMS.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({"support_zip": str(out_zip), "bytes": out_zip.stat().st_size, "files": len(internal_manifest)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
