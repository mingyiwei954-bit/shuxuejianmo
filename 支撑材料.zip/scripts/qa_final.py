#!/usr/bin/env python3
"""Final cross-artifact checks for placeholders, anonymity, size and package integrity."""
from __future__ import annotations

import json
import re
import zipfile
from pathlib import Path

from docx import Document
from pypdf import PdfReader


ROOT = Path(__file__).resolve().parents[1]
FINAL = ROOT / "outputs" / "c_final_v1"
LIMIT = 20 * 1024 * 1024


def docx_text(path: Path) -> str:
    doc = Document(path)
    parts = [p.text for p in doc.paragraphs]
    for table in doc.tables:
        parts.extend(cell.text for row in table.rows for cell in row.cells)
    return "\n".join(parts)


def pdf_text(path: Path) -> str:
    return "\n".join((p.extract_text() or "") for p in PdfReader(path).pages)


def main() -> None:
    paper_docx = FINAL / "paper" / "C题论文.docx"
    paper_pdf = FINAL / "paper" / "C题论文.pdf"
    ai_pdf = FINAL / "paper" / "AI工具使用详情.pdf"
    support = FINAL / "支撑材料.zip"
    texts = {
        str(paper_docx): docx_text(paper_docx),
        str(paper_pdf): pdf_text(paper_pdf),
        str(ai_pdf): pdf_text(ai_pdf),
    }
    paper_reader = PdfReader(paper_pdf)
    page_texts = [(page.extract_text() or "") for page in paper_reader.pages]
    appendix_pages = [i + 1 for i, text in enumerate(page_texts) if re.search(r"(^|\n)附录(?:\s|$)", text)]
    body_pages = (appendix_pages[0] - 1) if appendix_pages else len(page_texts)
    paper_body_text = "\n".join(page_texts[:body_pages])
    frozen_source = (FINAL / "evidence" / "paper_source_frozen.md").read_text(encoding="utf-8")
    frozen_body = re.split(r"(?m)^#{1,6}\s*附录\s*$", frozen_source, maxsplit=1)[0]
    local_home = str(Path.home())
    local_user = Path.home().name
    prohibited = [re.escape(local_home), re.escape(local_user), r"\{\{(?:RESULT|AI_|EVIDENCE):", r"待补录"]
    # The appendix intentionally contains complete runnable source code, including
    # the QA regular expressions themselves.  Scan the prose/body and AI detail,
    # not those literal test patterns embedded as code.
    findings = []
    compliance_texts = {
        f"{paper_pdf} (body)": paper_body_text,
        str(FINAL / "evidence" / "paper_source_frozen.md") + " (body)": frozen_body,
        str(ai_pdf): texts[str(ai_pdf)],
    }
    for path, text in compliance_texts.items():
        for pattern in prohibited:
            if re.search(pattern, text, re.I): findings.append({"path": path, "pattern": pattern})
    paper_text = texts[str(paper_pdf)]
    compact_paper_text = re.sub(r"\s+", "", paper_text)
    ai_pos = compact_paper_text.find("AI工具使用声明"); ref_pos = compact_paper_text.find("参考文献")
    assertions = {
        "paper_pdf_under_20mb": paper_pdf.stat().st_size <= LIMIT,
        "support_zip_under_20mb": support.stat().st_size <= LIMIT,
        "paper_docx_exists": paper_docx.is_file(),
        "five_workbooks": len(list((FINAL / "workbooks").glob("result*.xlsx"))) == 5,
        "ai_statement_before_references": 0 <= ai_pos < ref_pos,
        "no_table_of_contents_heading": "目录" not in paper_text[:2000],
        "paper_body_at_most_30_pages": body_pages <= 30,
        "no_prohibited_text": not findings,
    }
    with zipfile.ZipFile(support) as zf:
        names = zf.namelist()
        assertions["ai_detail_in_support"] = "AI工具使用详情.pdf" in names
        assertions["pipeline_in_support"] = "run_pipeline.sh" in names
        assertions["support_paths_relative"] = all(not n.startswith(("/", "../")) and ":\\" not in n for n in names)
        assertions["support_test_ok"] = zf.testzip() is None
        support_identity_hits = []
        for name in names:
            if Path(name).suffix.lower() not in {".py", ".md", ".json", ".csv", ".yaml", ".sh", ".txt"}:
                continue
            try:
                text = zf.read(name).decode("utf-8", errors="ignore")
            except KeyError:
                continue
            if local_home in text or re.search(rf"(?<![\w-]){re.escape(local_user)}(?![\w-])", text, re.I):
                support_identity_hits.append(name)
        assertions["support_content_anonymous"] = not support_identity_hits
        findings.extend({"path": f"support:{name}", "pattern": "local identity path"} for name in support_identity_hits)
    audit = json.loads((FINAL / "audit" / "audit_summary.json").read_text(encoding="utf-8"))
    assertions["formal_audit_pass"] = audit.get("formal_delivery_gate") == "PASS"
    result = {"status": "PASS" if all(assertions.values()) else "FAIL", "assertions": assertions, "findings": findings,
              "paper_pages": len(paper_reader.pages), "paper_body_pages": body_pages,
              "appendix_start_page": appendix_pages[0] if appendix_pages else None,
              "paper_pdf_bytes": paper_pdf.stat().st_size,
              "support_zip_bytes": support.stat().st_size}
    out = FINAL / "qa" / "final_verification.json"; out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(result, ensure_ascii=False))
    if result["status"] != "PASS": raise SystemExit(1)


if __name__ == "__main__":
    main()
