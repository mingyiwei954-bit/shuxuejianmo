#!/usr/bin/env python3
from datetime import date

from src.model import load_config, load_data
from src.model.experiments import solve_q1
from src.model.rolling import RunSpec, simulate
from src.model.forecast import corrected_pv_horizon, pv_cap_horizon, residual_scenarios


def main() -> int:
    cfg=load_config("config/final.yaml")
    data=load_data(cfg)
    assert len(data.dates)==365 and data.load_kw.shape==(365,144)
    q1=solve_q1(data,cfg)
    assert len(q1)==144 and abs(q1[-1]["soc_end_kwh"]-6000)<1e-7
    cfg["forecast"]["scenario_count"]=3
    cfg["forecast"]["scenario_history_days"]=3
    result=simulate(data,cfg,RunSpec("q3","S3","all_three",start_date=date(2025,2,1),end_date=date(2025,2,1)))
    assert len(result["dispatch"])==144
    assert result["summary"]["max_balance_residual_kwh"]<1e-7
    assert result["summary"]["max_soc_residual_kwh"]<1e-7
    assert all(v["new_commitment_kwh"]=="" for v in result["decision_versions"] if v["is_preview_recourse"])
    assert all(date.fromisoformat(h)<date.fromisoformat(v["date"])
               for v in result["decision_versions"] for field in
               ("load_history_dates","price_history_dates","pv_bias_history_dates","residual_scenario_dates")
               for h in str(v[field]).split("|") if h)
    test_day=date(2025,2,1); base,_=corrected_pv_horizon(data,test_day,0,144,cfg)
    scenarios,_=residual_scenarios(data,test_day,0,base,cfg,centered=True); caps=pv_cap_horizon(data,test_day,0,144,cfg)
    assert (scenarios<=caps[None,:]+1e-10).all()
    chain={}
    versions=[v for v in result["decision_versions"] if not v["is_preview_next_day"]]
    previews=[v for v in result["decision_versions"] if v["is_preview_next_day"]]
    assert len(previews)==216 and all(v["preview_grid_kwh"]!="" and v["new_commitment_kwh"]=="" for v in previews)
    for hour,expected in ((0,144),(6,108),(12,72),(18,36)):
        block=[v for v in versions if v["decision_time"].endswith(f" {hour:02d}:00")]
        assert sum(v["sensitivity_new_commitment_kwh"]!="" for v in block)==expected
        for v in block:
            pos=int(v["position"])
            if hour==0:
                assert v["sensitivity_old_commitment_kwh"]==""
            else:
                assert abs(float(v["sensitivity_old_commitment_kwh"])-chain[pos])<1e-8
            chain[pos]=float(v["sensitivity_new_commitment_kwh"])
    print("smoke_model: PASS")
    return 0


if __name__=="__main__": raise SystemExit(main())
