#!/usr/bin/env python3
from concurrent.futures import ProcessPoolExecutor
from datetime import date

from src.model import load_config, load_data
from src.model.rolling import RunSpec, simulate


def worker(data,cfg,mode):
    cfg["forecast"]["scenario_count"]=3; cfg["forecast"]["scenario_history_days"]=3
    return simulate(data,cfg,RunSpec(mode,"S2","all_three",start_date=date(2025,2,1),end_date=date(2025,2,2),collect_detail=False))["summary"]


def main()->int:
    cfg=load_config("config/final.yaml"); data=load_data(cfg)
    with ProcessPoolExecutor(max_workers=2) as pool:
        rows=[f.result() for f in (pool.submit(worker,data,cfg,"q3"),pool.submit(worker,data,cfg,"q4_3"))]
    assert all(r["days"]==2 and r["constraint_violation_count"]==0 for r in rows)
    print("smoke_parallel_model: PASS")
    return 0


if __name__=="__main__": raise SystemExit(main())
