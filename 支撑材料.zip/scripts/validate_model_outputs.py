#!/usr/bin/env python3
from __future__ import annotations

import csv
import argparse
import hashlib
import json
from pathlib import Path

from src.model import load_config


NUMERIC = (
    "plan_00_grid_kwh","final_adjusted_grid_kwh","charge_kwh","discharge_kwh",
    "soc_start_kwh","soc_end_kwh","planned_unused_nonpv_kwh","actual_load_kwh","actual_pv_kwh",
    "settlement_price","emergency_kwh","unused_surplus_kwh","plan_cost_yuan",
    "adjustment_cost_yuan","emergency_cost_yuan","final_relative_cost_yuan","sequential_cost_yuan",
)


def sha256(path:Path)->str:
    h=hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda:f.read(1<<20),b""): h.update(block)
    return h.hexdigest()


def main()->int:
    ap=argparse.ArgumentParser(description="Validate frozen causal-model outputs and stability evidence")
    ap.add_argument("--config",default="config/final.yaml")
    args=ap.parse_args()
    cfg=load_config(args.config); frozen=Path(cfg["_output_root"])/"frozen"; evidence=Path(cfg["_output_root"])/"evidence"
    tol=1e-7; checks=[]
    def add(name:str,ok:bool,actual): checks.append({"check":name,"status":"PASS" if ok else "FAIL","actual":actual})
    for name,expected in (("q1",144),("q2",48096),("q3",48096),("q4_2",48096),("q4_3",48096)):
        path=frozen/f"{name}_dispatch.csv"; rows=[]
        with path.open(encoding="utf-8-sig",newline="") as f:
            for row in csv.DictReader(f):
                for col in NUMERIC:
                    if row[col]=="": raise AssertionError(f"{name}: blank numeric {col}")
                    float(row[col])
                rows.append(row)
        add(f"{name}.row_count",len(rows)==expected,len(rows))
        by={}
        for r in rows: by.setdefault(r["date"],[]).append(r)
        add(f"{name}.daily_144_unique",all(len(x)==144 and {int(r['position']) for r in x}==set(range(1,145)) for x in by.values()),len(by))
        max_soc=max(abs(float(r["soc_end_kwh"])-float(r["soc_start_kwh"])-float(cfg["storage"]["charge_efficiency"])*float(r["charge_kwh"])+float(r["discharge_kwh"])/float(cfg["storage"]["discharge_efficiency"])) for r in rows)
        max_bal=max(abs(float(r["final_adjusted_grid_kwh"])+float(r["actual_pv_kwh"])+float(r["discharge_kwh"])+float(r["emergency_kwh"])-float(r["actual_load_kwh"])-float(r["charge_kwh"])-float(r["unused_surplus_kwh"])) for r in rows)
        max_cost=max(abs(float(r["plan_cost_yuan"])+float(r["adjustment_cost_yuan"])+float(r["emergency_cost_yuan"])-float(r["final_relative_cost_yuan"])) for r in rows)
        continuity=max((abs(float(rows[i]["soc_start_kwh"])-float(rows[i-1]["soc_end_kwh"])) for i in range(1,len(rows))),default=0.0)
        simultaneous=sum(float(r["charge_kwh"])>tol and float(r["discharge_kwh"])>tol for r in rows)
        soc_bounds=sum(float(r["soc_end_kwh"])<float(cfg["storage"]["soc_min_kwh"])-tol or float(r["soc_end_kwh"])>float(cfg["storage"]["soc_max_kwh"])+tol for r in rows)
        curtail_bounds=sum(float(r["curtail_pv_kwh"])>float(r["forecast_pv_kwh"])+tol for r in rows)
        add(f"{name}.soc_recursion",max_soc<tol,max_soc); add(f"{name}.actual_balance",max_bal<tol,max_bal)
        add(f"{name}.cost_reconcile",max_cost<tol,max_cost); add(f"{name}.soc_continuity",continuity<tol,continuity)
        add(f"{name}.no_simultaneous_charge_discharge",simultaneous==0,simultaneous); add(f"{name}.soc_bounds",soc_bounds==0,soc_bounds)
        add(f"{name}.curtail_within_forecast_pv",curtail_bounds==0,curtail_bounds)
        add(f"{name}.endpoints",abs(float(rows[0]["soc_start_kwh"])-6000)<tol and abs(float(rows[-1]["soc_end_kwh"])-6000)<tol,[rows[0]["soc_start_kwh"],rows[-1]["soc_end_kwh"]])
        if name in {"q3","q4_3"}:
            delta=sum(float(r["sequential_cost_yuan"])-float(r["final_relative_cost_yuan"]) for r in rows)
            add(f"{name}.settlement_sensitivity_distinct",abs(delta)>.01,delta)
    for name in ("q3","q4_3"):
        plans={}
        with (frozen/f"{name}_dispatch.csv").open(encoding="utf-8-sig",newline="") as f:
            for r in csv.DictReader(f): plans[(r["date"],int(r["position"]))]=float(r["plan_00_grid_kwh"])
        path=frozen/f"{name}_decision_versions.csv"; bad_history=0; bad_preview=0; bad_chain=0; count=0; chain={}; per_day={}; previews={}
        with path.open(encoding="utf-8-sig",newline="") as f:
            for r in csv.DictReader(f):
                count+=1
                for col in ("load_history_dates","price_history_dates","pv_bias_history_dates","residual_scenario_dates"):
                    bad_history+=sum(h>=r["date"] for h in r[col].split("|") if h)
                if r["is_preview_recourse"]=="1" and (r["old_commitment_kwh"]!="" or r["new_commitment_kwh"]!=""): bad_preview+=1
                day=r["date"]; hour=int(r["decision_time"][11:13]); pos=int(r["position"])
                per_day.setdefault(day,{0:0,6:0,12:0,18:0})
                if r["is_preview_next_day"]=="1":
                    previews.setdefault(day,{0:0,6:0,12:0,18:0})[hour]+=1
                    if (r["sensitivity_old_commitment_kwh"]!="" or r["sensitivity_new_commitment_kwh"]!=""
                        or r.get("preview_grid_kwh","")=="" or r.get("target_date","")<=day): bad_chain+=1
                    continue
                if r.get("target_date",day)!=day: bad_chain+=1
                per_day[day][hour]+=int(r["sensitivity_new_commitment_kwh"]!="")
                key=(day,pos); new=float(r["sensitivity_new_commitment_kwh"])
                if hour==0:
                    if r["sensitivity_old_commitment_kwh"]!="" or abs(new-plans[key])>tol: bad_chain+=1
                else:
                    if key not in chain or abs(float(r["sensitivity_old_commitment_kwh"])-chain[key])>tol: bad_chain+=1
                chain[key]=new
        add(f"{name}.causal_history",bad_history==0,bad_history); add(f"{name}.recourse_not_committed",bad_preview==0,bad_preview); add(f"{name}.version_rows",count>0,count)
        bad_counts=sum(v!={0:144,6:108,12:72,18:36} for v in per_day.values())
        bad_preview_counts=sum(v!={0:0,6:36,12:72,18:108} for d,v in previews.items() if d!="2025-12-31")
        bad_preview_counts+=sum(d!="2025-12-31" and d not in previews for d in per_day)
        add(f"{name}.sensitivity_chain",bad_chain==0,bad_chain); add(f"{name}.sensitivity_counts",bad_counts==0,bad_counts)
        add(f"{name}.full_next_day_preview",bad_preview_counts==0,bad_preview_counts)
    stability_path=frozen/"stability_summary.csv"; stability=[]
    with stability_path.open(encoding="utf-8-sig",newline="") as f: stability=list(csv.DictReader(f))
    expected={(m,s,method,float(tb)) for m in ("q3","q4_3") for s in ("S2","S3")
              for method in cfg["experiments"]["solver_methods"] for tb in cfg["experiments"]["tiebreak_coefficients"]}
    actual={(r["mode"],r["scenario"],r["solver_method"],float(r["tiebreak"])) for r in stability}
    add("stability.full_factorial",len(stability)==36 and actual==expected,{"rows":len(stability),"unique":len(actual)})
    stability_bad=sum(int(r["days"])!=334 or abs(float(r["initial_soc_kwh"])-6000)>tol
                      or abs(float(r["terminal_soc_kwh"])-6000)>tol or int(r["constraint_violation_count"])!=0
                      for r in stability)
    add("stability.annual_feasible",stability_bad==0,stability_bad)
    with (frozen/"stability_assessment.csv").open(encoding="utf-8-sig",newline="") as f: assessment=list(csv.DictReader(f))
    assessment_keys={(r["mode"],r["settlement"],r["comparison"]) for r in assessment}
    expected_assessment={(m,s,"S3_minus_S2") for m in ("q3","q4_3")
                         for s in ("final_relative_to_00_plan","sequential_sensitivity")}
    add("stability.two_settlements",len(assessment)==4 and assessment_keys==expected_assessment,
        {"rows":len(assessment),"keys":sorted(assessment_keys)})
    manifest=json.loads((frozen/"frozen_manifest.json").read_text(encoding="utf-8")); mismatch=[]
    for item in manifest["files"]:
        p=frozen/item["path"]
        if not p.is_file() or sha256(p)!=item["sha256"]: mismatch.append(item["path"])
    add("manifest.hashes",not mismatch,mismatch)
    leaks=[]
    home_marker=str(Path.home())
    for p in frozen.glob("*.json"):
        if home_marker in p.read_text(encoding="utf-8"): leaks.append(p.name)
    add("portable_metadata",not leaks,leaks)
    result={"status":"PASS" if all(x["status"]=="PASS" for x in checks) else "FAIL","checks":checks}
    evidence.mkdir(parents=True,exist_ok=True); (evidence/"model_integrity_check.json").write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding="utf-8")
    print(json.dumps({"status":result["status"],"checks":len(checks)},ensure_ascii=False))
    return 0 if result["status"]=="PASS" else 1


if __name__=="__main__": raise SystemExit(main())
