#!/usr/bin/env python3
"""Strict, non-mutating audit for C-problem inputs, templates and results.

The reader never coerces blanks, error cells, non-finite values or text to zero.
Official workbook tables are checked against the supplied templates.  Full-
precision dispatch CSV files are preferred for physical, settlement and
emergency-interval reconstruction; a workbook detail sheet is a documented
fallback for legacy evidence only.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import os
import re
import shutil
import sys
from collections import Counter, defaultdict
from dataclasses import asdict, dataclass
from datetime import date, datetime, time, timedelta
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence

import numpy as np
from openpyxl import load_workbook


RESULT_NAMES = ("result1.xlsx", "result2.xlsx", "result3.xlsx", "result4-2.xlsx", "result4-3.xlsx")
MAIN_START = date(2025, 2, 1)
MAIN_END = date(2025, 12, 31)
FULL_START = date(2025, 1, 1)
FULL_END = date(2025, 12, 31)
ERROR_TOKENS = {"#REF!", "#DIV/0!", "#VALUE!", "#NAME?", "#N/A", "#NUM!", "#NULL!", "#SPILL!", "#CALC!"}
FOUR_HOUR_LABELS = tuple(f"{h}:00-{h + 4}:00" for h in range(0, 24, 4))


@dataclass(frozen=True)
class AuditConfig:
    display_decimals: int = 4
    emergency_display_threshold_kwh: float = 0.00005
    efficiency: float = 0.9
    interval_hours: float = 1 / 6
    storage_min_kwh: float = 1200.0
    storage_max_kwh: float = 10800.0
    storage_power_kw: float = 5000.0
    initial_soc_kwh: float = 6000.0
    terminal_soc_kwh: float = 6000.0
    numeric_tolerance: float = 1e-7
    displayed_tolerance: float = 2.1e-4

    @property
    def step_power_limit_kwh(self) -> float:
        return self.storage_power_kw * self.interval_hours


@dataclass
class Check:
    id: str
    status: str
    severity: str
    scope: str
    actual: Any
    expected: Any
    evidence: str
    impact: str


@dataclass(frozen=True)
class Detail:
    source: Path
    source_kind: str
    rows: tuple[dict[str, Any], ...]


class Audit:
    def __init__(self) -> None:
        self.checks: list[Check] = []

    def add(self, check_id: str, status: str, severity: str, scope: str,
            actual: Any, expected: Any, evidence: str, impact: str) -> None:
        self.checks.append(Check(check_id, status, severity, scope, actual,
                                 expected, evidence, impact))


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def sanitize_output(value: Any, project_root: Path, source_root: Path) -> Any:
    """Remove machine/user-specific absolute roots from deliverable evidence."""
    replacements = sorted(
        ((str(project_root.resolve()), "<project_root>"), (str(source_root.resolve()), "<source_root>")),
        key=lambda pair: len(pair[0]), reverse=True,
    )
    if isinstance(value, str):
        for original, placeholder in replacements:
            value = value.replace(original, placeholder)
        return value
    if isinstance(value, dict):
        return {str(key): sanitize_output(child, project_root, source_root) for key, child in value.items()}
    if isinstance(value, list):
        return [sanitize_output(child, project_root, source_root) for child in value]
    if isinstance(value, tuple):
        return tuple(sanitize_output(child, project_root, source_root) for child in value)
    return value


def _flatten_mapping(value: Any, output: dict[str, str]) -> None:
    if not isinstance(value, dict):
        return
    for key, child in value.items():
        normalized = str(key).lower().replace("-", "_")
        if isinstance(child, dict):
            _flatten_mapping(child, output)
        elif isinstance(child, (str, int, float, bool)) or child is None:
            output[normalized] = "" if child is None else str(child)


def flat_yaml_scalars(path: Path) -> tuple[dict[str, str], str]:
    """Read scalar values without requiring a YAML dependency.

    Nested keys are deliberately flattened because the audit accepts several
    documented aliases.  This parser does not attempt to interpret arbitrary
    YAML and therefore cannot silently invent values.
    """
    if not path.is_file():
        return {}, "missing_defaults"
    text = path.read_text(encoding="utf-8")
    try:
        document = json.loads(text)
    except json.JSONDecodeError:
        document = None
    if isinstance(document, dict):
        values: dict[str, str] = {}
        _flatten_mapping(document, values)
        return values, "json"
    values: dict[str, str] = {}
    for raw in text.splitlines():
        line = raw.split("#", 1)[0].rstrip()
        match = re.match(r'^\s*["\']?([A-Za-z_][\w-]*)["\']?\s*:\s*([^\s].*?)\s*$', line)
        if match:
            values[match.group(1).lower().replace("-", "_")] = match.group(2).strip(" '\"")
    return values, "flat_yaml_fallback"


def _pick_number(values: Mapping[str, str], aliases: Sequence[str], default: float) -> float:
    for name in aliases:
        if name in values:
            try:
                parsed = float(values[name])
            except ValueError as exc:
                raise ValueError(f"配置项 {name} 不是数值: {values[name]!r}") from exc
            if not math.isfinite(parsed):
                raise ValueError(f"配置项 {name} 不是有限数值: {values[name]!r}")
            return parsed
    return default


def load_config(path: Path) -> tuple[AuditConfig, dict[str, str], str]:
    values, parser_source = flat_yaml_scalars(path)
    decimals = int(_pick_number(values, ("display_decimals", "output_decimals", "decimals"), 4))
    default_threshold = 0.5 * 10 ** (-decimals)
    interval_hours = _pick_number(values, ("interval_hours", "dt_hours", "dt"), math.nan)
    if math.isnan(interval_hours):
        interval_hours = _pick_number(values, ("interval_minutes",), 10.0) / 60.0
    cfg = AuditConfig(
        display_decimals=decimals,
        emergency_display_threshold_kwh=_pick_number(
            values,
            ("emergency_display_omit_threshold_kwh", "emergency_display_threshold_kwh", "emergency_display_threshold", "display_zero_threshold_kwh"),
            default_threshold,
        ),
        efficiency=_pick_number(values, ("efficiency", "eta", "storage_efficiency", "charge_efficiency"), 0.9),
        interval_hours=interval_hours,
        storage_min_kwh=_pick_number(values, ("storage_min_kwh", "soc_min_kwh", "e_min"), 1200.0),
        storage_max_kwh=_pick_number(values, ("storage_max_kwh", "soc_max_kwh", "e_max"), 10800.0),
        storage_power_kw=_pick_number(values, ("storage_power_kw", "power_kw", "power_limit_kw", "p_max"), 5000.0),
        initial_soc_kwh=_pick_number(values, ("initial_soc_kwh", "initial_soc"), 6000.0),
        terminal_soc_kwh=_pick_number(values, ("terminal_soc_kwh", "terminal_soc"), 6000.0),
        numeric_tolerance=_pick_number(values, ("numeric_tolerance", "audit_tolerance"), 1e-7),
        displayed_tolerance=_pick_number(values, ("displayed_tolerance", "display_tolerance"), 2.1e-4),
    )
    if cfg.display_decimals < 0 or cfg.display_decimals > 12:
        raise ValueError("display_decimals 必须在 0..12")
    if cfg.emergency_display_threshold_kwh < 0:
        raise ValueError("emergency_display_threshold_kwh 不能为负")
    return cfg, values, parser_source


def norm_date(value: Any) -> date:
    if isinstance(value, datetime):
        return value.date()
    if isinstance(value, date):
        return value
    if value is None or (isinstance(value, str) and not value.strip()):
        raise ValueError("日期为空")
    text = str(value).strip().replace(".", "-").replace("/", "-")
    return datetime.strptime(text[:10], "%Y-%m-%d").date()


def date_range(start: date, end: date) -> list[date]:
    return [start + timedelta(days=i) for i in range((end - start).days + 1)]


def norm_clock(value: Any) -> str:
    if isinstance(value, datetime):
        value = value.time()
    if isinstance(value, time):
        return f"{value.hour:02d}:{value.minute:02d}"
    text = str(value).strip()
    if text in {"0:00+1", "00:00+1", "24:00", "24:00:00"}:
        return "24:00"
    match = re.match(r"^(\d{1,2}):(\d{2})(?::\d{2})?$", text)
    if not match:
        return text
    return f"{int(match.group(1)):02d}:{int(match.group(2)):02d}"


def physical_labels() -> tuple[str, ...]:
    labels = []
    for pos in range(144):
        start = pos * 10
        end = (pos + 1) * 10
        a = f"{start // 60:02d}:{start % 60:02d}"
        b = "24:00" if end == 1440 else f"{end // 60:02d}:{end % 60:02d}"
        labels.append(f"{a}-{b}")
    return tuple(labels)


def required_number(value: Any, location: str) -> float:
    """Return a finite float, rejecting missing/error/text values explicitly."""
    if value is None or (isinstance(value, str) and not value.strip()):
        raise ValueError(f"{location}: 空值")
    if isinstance(value, str) and value.strip().upper() in ERROR_TOKENS:
        raise ValueError(f"{location}: 公式错误 {value.strip()}")
    if isinstance(value, bool):
        raise ValueError(f"{location}: 布尔值不是数值")
    try:
        number = float(value)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"{location}: 非数值 {value!r}") from exc
    if not math.isfinite(number):
        raise ValueError(f"{location}: 非有限数值 {value!r}")
    return number


def scan_required_numbers(values: Iterable[tuple[str, Any]], sample_limit: int = 20) -> tuple[list[float], dict[str, Any]]:
    numbers: list[float] = []
    errors: list[str] = []
    count = 0
    for location, value in values:
        count += 1
        try:
            numbers.append(required_number(value, location))
        except ValueError as exc:
            if len(errors) < sample_limit:
                errors.append(str(exc))
    return numbers, {"required_cells": count, "valid_numeric_cells": len(numbers), "error_count": count - len(numbers), "samples": errors}


def workbook_formula_errors(path: Path) -> dict[str, Any]:
    errors: list[str] = []
    for data_only in (False, True):
        wb = load_workbook(path, data_only=data_only, read_only=True)
        for ws in wb.worksheets:
            for row in ws.iter_rows():
                for cell in row:
                    value = cell.value
                    if cell.data_type == "e" or (isinstance(value, str) and value.strip().upper() in ERROR_TOKENS):
                        if len(errors) < 50:
                            errors.append(f"{ws.title}!{cell.coordinate}={value}")
        wb.close()
    return {"error_count": len(errors), "samples": errors}


def workbook_headers(path: Path) -> dict[str, list[Any]]:
    wb = load_workbook(path, data_only=False, read_only=True)
    result = {ws.title: list(next(ws.iter_rows(values_only=True))) for ws in wb.worksheets}
    wb.close()
    return result


def audit_schema(audit: Audit, path: Path, expected_path: Path, prefix: str) -> bool:
    expected = workbook_headers(expected_path)
    actual = workbook_headers(path)
    missing = [sheet for sheet in expected if sheet not in actual]
    header_diffs = {
        sheet: {"actual": actual.get(sheet), "expected": header}
        for sheet, header in expected.items() if actual.get(sheet) != header
    }
    ok = not missing and not header_diffs
    audit.add(f"{prefix}-SCHEMA", "PASS" if ok else "FAIL", "critical", path.name,
              {"missing_official_sheets": missing, "header_differences": header_diffs,
               "extra_sheets": sorted(set(actual) - set(expected))},
              "All official sheets and their complete header rows exactly match the supplied template; evidence sheets may be additional.",
              f"{path} vs {expected_path}", "Schema drift can make the submission ungradable.")
    return ok


def audit_attachment_inputs(audit: Audit, input_dir: Path) -> tuple[tuple[Any, ...], tuple[str, ...]]:
    expected_headers = {
        "附件1.xlsx": {"Sheet1": ("时间", "电价", "小区负载", "光伏发电预测功率")},
        "附件2.xlsx": {"小区负载": None, "光伏发电实际功率": None},
        "附件3.xlsx": {"Sheet1": tuple(["日期", "预报时刻"] + [f"预报{i}小时" for i in range(1, 25)])},
        "附件4.xlsx": {"Sheet1": None},
    }
    paths = {name: input_dir / name for name in expected_headers}
    missing = [name for name, path in paths.items() if not path.is_file()]
    audit.add("INPUT-FILES", "PASS" if not missing else "FAIL", "critical", "附件1-4",
              {"missing": missing}, "All four attachments exist.", str(input_dir), "Missing inputs prevent reconstruction.")
    if missing:
        return (), ()

    # Attachment 1: exact schema, 144 unique ordered source timestamps, all numeric.
    wb1 = load_workbook(paths["附件1.xlsx"], data_only=True, read_only=True)
    ws1 = wb1["Sheet1"]
    rows1 = list(ws1.iter_rows(values_only=True))
    header1 = tuple(rows1[0])
    clocks = tuple(norm_clock(row[0]) for row in rows1[1:])
    expected_clocks = tuple([f"{m // 60:02d}:{m % 60:02d}" for m in range(10, 1440, 10)] + ["24:00"])
    _, numeric1 = scan_required_numbers(
        (f"附件1.xlsx!{r}:{c}", value)
        for r, row in enumerate(rows1[1:], 2) for c, value in enumerate(row[1:4], 2)
    )
    input1_ok = header1 == expected_headers["附件1.xlsx"]["Sheet1"] and clocks == expected_clocks and len(set(clocks)) == 144 and numeric1["error_count"] == 0
    audit.add("INPUT-ATTACHMENT1", "PASS" if input1_ok else "FAIL", "critical", "附件1 Sheet1",
              {"header": header1, "rows": len(rows1) - 1, "unique_times": len(set(clocks)),
               "ordered_times": clocks == expected_clocks, "numeric_scan": numeric1},
              "Exact 4 fields, ordered 00:10..24:00, 144 unique timestamps, and 432 finite numeric cells.",
              str(paths["附件1.xlsx"]), "Defines Q1 and the fixed tariff.")
    wb1.close()

    shared_headers: tuple[Any, ...] = ()
    shared_dates: list[date] | None = None
    for filename, sheets in (("附件2.xlsx", ("小区负载", "光伏发电实际功率")), ("附件4.xlsx", ("Sheet1",))):
        wb = load_workbook(paths[filename], data_only=True, read_only=True)
        for sheet in sheets:
            ws = wb[sheet]
            rows = list(ws.iter_rows(values_only=True))
            header = tuple(rows[0])
            dates: list[date] = []
            date_errors: list[str] = []
            for idx, row in enumerate(rows[1:], 2):
                try:
                    dates.append(norm_date(row[0]))
                except ValueError as exc:
                    date_errors.append(f"row {idx}: {exc}")
            _, numeric = scan_required_numbers(
                (f"{filename}:{sheet}!R{r}C{c}", value)
                for r, row in enumerate(rows[1:], 2) for c, value in enumerate(row[1:145], 2)
            )
            time_headers = tuple(norm_clock(v) for v in header[1:145])
            ok = (header[0] == "日期\\时间" and len(header) == 145 and time_headers == expected_clocks
                  and len(set(time_headers)) == 144 and not date_errors
                  and dates == date_range(FULL_START, FULL_END) and len(set(dates)) == 365
                  and numeric["error_count"] == 0)
            audit.add(f"INPUT-{filename}-{sheet}", "PASS" if ok else "FAIL", "critical", f"{filename}/{sheet}",
                      {"rows": len(rows) - 1, "dates": len(dates), "unique_dates": len(set(dates)),
                       "date_start": str(dates[0]) if dates else None, "date_end": str(dates[-1]) if dates else None,
                       "date_errors": date_errors[:20], "intervals": len(time_headers),
                       "unique_times": len(set(time_headers)), "ordered_times": time_headers == expected_clocks,
                       "numeric_scan": numeric},
                      "365 ordered unique dates and 144 ordered unique timestamps; every data cell finite numeric.",
                      str(paths[filename]), "A gap, duplicate or reordered interval contaminates all annual results.")
            if shared_headers and time_headers != tuple(norm_clock(v) for v in shared_headers[1:145]):
                audit.add(f"INPUT-{filename}-{sheet}-ALIGN", "FAIL", "critical", "input time-axis alignment",
                          {"same_headers": False}, "Attachment 2/4 time headers exactly agree.", str(paths[filename]),
                          "Position-based joins would be invalid.")
            if shared_dates is not None and dates != shared_dates:
                audit.add(f"INPUT-{filename}-{sheet}-DATE-ALIGN", "FAIL", "critical", "input date-axis alignment",
                          {"same_dates": False}, "Attachment 2/4 dates exactly agree.", str(paths[filename]),
                          "Date joins would be invalid.")
            if not shared_headers:
                shared_headers = header
            if shared_dates is None:
                shared_dates = dates
        wb.close()

    # Attachment 3: exactly four ordered releases per date and 24 finite forecast values per release.
    wb3 = load_workbook(paths["附件3.xlsx"], data_only=True, read_only=True)
    ws3 = wb3["Sheet1"]
    rows3 = list(ws3.iter_rows(values_only=True))
    header3 = tuple(rows3[0])
    current: date | None = None
    records: list[tuple[date, str]] = []
    bad_dates: list[str] = []
    numeric_pairs: list[tuple[str, Any]] = []
    for row_num, row in enumerate(rows3[1:], 2):
        if row[0] not in (None, ""):
            try:
                current = norm_date(row[0])
            except ValueError as exc:
                bad_dates.append(f"row {row_num}: {exc}")
                current = None
        if current is None:
            bad_dates.append(f"row {row_num}: missing carried date")
            continue
        issue = norm_clock(row[1])
        records.append((current, issue))
        numeric_pairs.extend((f"附件3.xlsx!R{row_num}C{col}", value) for col, value in enumerate(row[2:26], 3))
    _, numeric3 = scan_required_numbers(numeric_pairs)
    by_date: dict[date, list[str]] = defaultdict(list)
    for day, issue in records:
        by_date[day].append(issue)
    expected_issues = ["00:00", "06:00", "12:00", "18:00"]
    issue_bad = {str(day): issues for day, issues in by_date.items() if issues != expected_issues}
    expected_records = [(day, issue) for day in date_range(FULL_START, FULL_END) for issue in expected_issues]
    forecast_ok = (header3 == expected_headers["附件3.xlsx"]["Sheet1"] and not bad_dates
                   and records == expected_records and not issue_bad and numeric3["error_count"] == 0)
    audit.add("INPUT-ATTACHMENT3", "PASS" if forecast_ok else "FAIL", "critical", "附件3",
              {"header_ok": header3 == expected_headers["附件3.xlsx"]["Sheet1"], "records": len(records),
               "dates": len(by_date), "bad_dates": bad_dates[:20], "issue_sequence_errors": dict(list(issue_bad.items())[:20]),
               "numeric_scan": numeric3},
              "365 dates x 4 releases (00/06/12/18) x 24 finite forecasts, in exact order.",
              str(paths["附件3.xlsx"]), "Forecast gaps or release-time shifts create information leakage or missing decisions.")
    wb3.close()
    return shared_headers, expected_clocks


def audit_official_templates(audit: Audit, template_dir: Path) -> None:
    for name in RESULT_NAMES:
        path = template_dir / name
        if not path.is_file():
            audit.add(f"TEMPLATE-{name}", "FAIL", "critical", name, {"exists": False}, "Official template exists.", str(path), "Cannot verify submission layout.")
            continue
        errors = workbook_formula_errors(path)
        wb = load_workbook(path, data_only=True, read_only=True)
        plan_sheet = wb["计划购电量"]
        header = tuple(next(plan_sheet.iter_rows(values_only=True)))
        interval_headers = header[1:145] if name != "result1.xlsx" else ()
        if name == "result1.xlsx":
            labels = tuple(row[0] for row in plan_sheet.iter_rows(min_row=2, values_only=True))
            ok = len(labels) == 144 and len(set(labels)) == 144
            actual = {"sheets": wb.sheetnames, "plan_rows": len(labels), "unique_interval_labels": len(set(labels)), "formula_errors": errors}
        else:
            dates = [norm_date(row[0]) for row in plan_sheet.iter_rows(min_row=2, values_only=True)]
            ok = (dates == date_range(MAIN_START, MAIN_END) and len(set(dates)) == 334
                  and len(interval_headers) == 144 and len(set(interval_headers)) == 144)
            actual = {"sheets": wb.sheetnames, "plan_days": len(dates), "unique_dates": len(set(dates)),
                      "date_start": str(dates[0]), "date_end": str(dates[-1]),
                      "interval_headers": len(interval_headers), "unique_interval_headers": len(set(interval_headers)),
                      "formula_errors": errors}
        wb.close()
        ok = ok and errors["error_count"] == 0
        audit.add(f"TEMPLATE-{name}", "PASS" if ok else "FAIL", "critical", name, actual,
                  "Official template has exact date population and 144 unique ordered interval labels with no formula-error literals.",
                  str(path), "The template is the schema authority for the result workbook.")


CSV_ALIASES: dict[str, tuple[str, ...]] = {
    "date": ("date", "日期"),
    "position": ("position", "时段序号"),
    "label": ("physical_interval", "official_label", "时段", "时间段"),
    "plan": ("plan_00_grid_kwh", "plan_grid_kwh", "planned_grid_kwh", "计划购电量(kwh)"),
    "adjusted": ("final_adjusted_grid_kwh", "adjusted_grid_kwh", "调整购电量(kwh)"),
    "emergency": ("emergency_kwh", "紧急购电量(kwh)"),
    "charge": ("charge_kwh", "充电量(kwh)"),
    "discharge": ("discharge_kwh", "放电量(kwh)"),
    "soc_start": ("soc_start_kwh", "期初储电量(kwh)"),
    "soc_end": ("soc_end_kwh", "期末储电量(kwh)"),
    "unused": ("unused_surplus_kwh", "curtail_pv_kwh", "curtailment_kwh", "弃光弃电量(kwh)"),
    "price": ("settlement_price", "price", "电价(元/kwh)"),
    "load": ("actual_load_kwh", "load_kwh", "小区负载(kwh)"),
    "pv": ("actual_pv_kwh", "pv_kwh", "光伏发电(kwh)"),
    "final_cost": ("final_relative_cost_yuan", "分时购电成本(元)"),
    "sequential_cost": ("sequential_cost_yuan",),
    "plan_cost": ("plan_cost_yuan",),
    "adjustment_cost": ("adjustment_cost_yuan",),
    "emergency_cost": ("emergency_cost_yuan",),
}


def normalized_header_map(header: Sequence[Any]) -> dict[str, str]:
    original = {str(value).strip().lower(): str(value) for value in header if value is not None}
    result: dict[str, str] = {}
    for canonical, aliases in CSV_ALIASES.items():
        for alias in aliases:
            if alias.lower() in original:
                result[canonical] = original[alias.lower()]
                break
    return result


def _candidate_csvs(results_dir: Path, stem: str) -> list[Path]:
    aliases = {stem.replace("-", "_"), stem.replace("result", "q").replace("-", "_")}
    candidates = []
    for path in results_dir.rglob("*.csv") if results_dir.exists() else []:
        lower = path.name.lower().replace("-", "_")
        if any(alias in lower for alias in aliases) and ("detail" in lower or "dispatch" in lower or "full_precision" in lower):
            candidates.append(path)
    return sorted(candidates, key=lambda p: ("full_precision" not in p.name.lower(), len(str(p))))


def load_csv_detail(path: Path, adjusted_required: bool) -> Detail | None:
    with path.open(newline="", encoding="utf-8-sig") as handle:
        reader = csv.DictReader(handle)
        if reader.fieldnames is None:
            return None
        mapping = normalized_header_map(reader.fieldnames)
        required = {"date", "position", "plan", "emergency", "charge", "discharge", "soc_start", "soc_end", "unused", "price", "load", "pv"}
        if adjusted_required:
            required.add("adjusted")
        if not required.issubset(mapping):
            return None
        rows: list[dict[str, Any]] = []
        for row_num, row in enumerate(reader, 2):
            item: dict[str, Any] = {"_row": row_num}
            for canonical, source_name in mapping.items():
                item[canonical] = row[source_name]
            for field in ("history_cutoff_date", "model_arm", "scenario", "decision_hour"):
                if field in row:
                    item[field] = row[field]
            rows.append(item)
    return Detail(path, "full_precision_csv", tuple(rows))


def load_xlsx_detail(path: Path, adjusted_required: bool) -> Detail | None:
    wb = load_workbook(path, data_only=True, read_only=True)
    if "核验明细" not in wb.sheetnames:
        wb.close()
        return None
    ws = wb["核验明细"]
    iterator = ws.iter_rows(values_only=True)
    header = list(next(iterator))
    mapping = normalized_header_map(header)
    required = {"date", "label", "plan", "emergency", "charge", "discharge", "soc_start", "soc_end", "unused", "price", "load", "pv"}
    if adjusted_required:
        required.add("adjusted")
    if not required.issubset(mapping):
        wb.close()
        return None
    index = {str(value): i for i, value in enumerate(header)}
    rows: list[dict[str, Any]] = []
    for row_num, row in enumerate(iterator, 2):
        item = {canonical: row[index[source_name]] for canonical, source_name in mapping.items()}
        item["position"] = ((row_num - 2) % 144) + 1
        item["_row"] = row_num
        rows.append(item)
    wb.close()
    return Detail(path, "rounded_workbook_detail", tuple(rows))


def locate_detail(results_dir: Path, workbook_path: Path, adjusted_required: bool) -> Detail | None:
    stem = workbook_path.stem
    for path in _candidate_csvs(results_dir, stem):
        detail = load_csv_detail(path, adjusted_required)
        if detail is not None:
            return detail
    return load_xlsx_detail(workbook_path, adjusted_required)


def parse_detail(detail: Detail, adjusted_required: bool) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    required_numeric = ["position", "plan", "emergency", "charge", "discharge", "soc_start", "soc_end", "unused", "price", "load", "pv"]
    if adjusted_required:
        required_numeric.append("adjusted")
    parsed: list[dict[str, Any]] = []
    errors: list[str] = []
    for source in detail.rows:
        row_num = source["_row"]
        item: dict[str, Any] = {"_row": row_num}
        for field in ("history_cutoff_date", "model_arm", "scenario", "decision_hour"):
            if field in source:
                item[field] = source[field]
        try:
            item["date"] = norm_date(source["date"])
        except (ValueError, TypeError) as exc:
            errors.append(f"row {row_num} date: {exc}")
            continue
        if "label" in source:
            item["label"] = str(source["label"]).strip()
        try:
            for field in required_numeric:
                item[field] = required_number(source.get(field), f"row {row_num} {field}")
            for field in ("final_cost", "sequential_cost", "plan_cost", "adjustment_cost", "emergency_cost"):
                if field in source:
                    item[field] = required_number(source[field], f"row {row_num} {field}")
        except ValueError as exc:
            errors.append(str(exc))
            continue
        parsed.append(item)
    return parsed, {"rows": len(detail.rows), "valid_rows": len(parsed), "error_count": len(errors), "samples": errors[:30]}


def audit_dispatch_causality(audit: Audit, name: str, rows: Sequence[dict[str, Any]]) -> None:
    missing = 0
    future = 0
    examples: list[str] = []
    for row in rows:
        raw = row.get("history_cutoff_date")
        if raw in (None, ""):
            missing += 1
            continue
        try:
            cutoff = norm_date(raw)
        except ValueError:
            future += 1
            if len(examples) < 20:
                examples.append(f"row {row['_row']}: invalid cutoff {raw!r}")
            continue
        if cutoff >= row["date"]:
            future += 1
            if len(examples) < 20:
                examples.append(f"row {row['_row']}: cutoff {cutoff} >= decision day {row['date']}")
    ok = missing == 0 and future == 0
    audit.add(f"FINAL-{name}-DISPATCH-CAUSALITY", "PASS" if ok else "FAIL", "critical", name,
              {"rows": len(rows), "missing_history_cutoff": missing, "noncausal_or_invalid": future, "samples": examples},
              "Every dispatch row records a history cutoff strictly earlier than its decision date.",
              "full-precision dispatch detail", "A physical backtest does not prove an executable information set.")


def audit_detail_coverage(audit: Audit, name: str, rows: Sequence[dict[str, Any]], scan: dict[str, Any], detail: Detail,
                          official_labels: Sequence[str]) -> bool:
    expected_dates = date_range(MAIN_START, MAIN_END)
    by_date: dict[date, list[dict[str, Any]]] = defaultdict(list)
    for row in rows:
        by_date[row["date"]].append(row)
    expected_physical = physical_labels()
    bad_days: dict[str, Any] = {}
    for day in sorted(set(by_date) | set(expected_dates)):
        day_rows = by_date.get(day, [])
        positions = [int(r["position"]) for r in day_rows]
        pos_ok = positions == list(range(1, 145))
        label_ok = True
        if day_rows and "label" in day_rows[0]:
            labels = [r["label"] for r in day_rows]
            # Evidence must use one complete declared convention, never a merely unique permutation.
            label_ok = labels == list(expected_physical) or labels == list(official_labels)
        if len(day_rows) != 144 or len(set(positions)) != 144 or not pos_ok or not label_ok:
            if len(bad_days) < 30:
                bad_days[str(day)] = {"rows": len(day_rows), "unique_positions": len(set(positions)),
                                      "ordered_positions": pos_ok, "unique_labels": len(set(r.get("label", "") for r in day_rows)),
                                      "label_ok": label_ok}
    dates = sorted(by_date)
    ok = (scan["error_count"] == 0 and len(rows) == 334 * 144 and dates == expected_dates
          and not bad_days)
    audit.add(f"FINAL-{name}-DETAIL-COVERAGE", "PASS" if ok else "FAIL", "critical", name,
              {"source": str(detail.source), "source_kind": detail.source_kind, "numeric_scan": scan,
               "rows": len(rows), "days": len(dates), "date_start": str(dates[0]) if dates else None,
               "date_end": str(dates[-1]) if dates else None, "bad_days": bad_days},
              "48096 valid rows; exact 2025-02-01..12-31 sequence; each date has ordered unique positions 1..144 and labels exactly follow the physical or official convention.",
              str(detail.source), "Missing or duplicated intervals invalidate costs and SOC continuity.")
    return ok


def audit_physics(audit: Audit, name: str, rows: Sequence[dict[str, Any]], cfg: AuditConfig, adjusted: bool) -> None:
    if not rows:
        return
    maximum = defaultdict(float)
    minimum_soc = math.inf
    maximum_soc = -math.inf
    simultaneous = negative = 0
    prior_end: float | None = None
    for idx, row in enumerate(rows):
        purchase = row["adjusted"] if adjusted else row["plan"]
        balance = purchase + row["emergency"] + row["pv"] + row["discharge"] - row["load"] - row["charge"] - row["unused"]
        dynamic = row["soc_end"] - row["soc_start"] - cfg.efficiency * row["charge"] + row["discharge"] / cfg.efficiency
        maximum["balance"] = max(maximum["balance"], abs(balance))
        maximum["soc_dynamic"] = max(maximum["soc_dynamic"], abs(dynamic))
        maximum["step_power"] = max(maximum["step_power"], row["charge"], row["discharge"])
        if prior_end is not None:
            maximum["continuity"] = max(maximum["continuity"], abs(row["soc_start"] - prior_end))
        prior_end = row["soc_end"]
        minimum_soc = min(minimum_soc, row["soc_start"], row["soc_end"])
        maximum_soc = max(maximum_soc, row["soc_start"], row["soc_end"])
        simultaneous += row["charge"] > cfg.numeric_tolerance and row["discharge"] > cfg.numeric_tolerance
        negative += sum(row[field] < -cfg.numeric_tolerance for field in ("plan", "emergency", "charge", "discharge", "unused") + (("adjusted",) if adjusted else ()))
    endpoints = {"initial": rows[0]["soc_start"], "terminal": rows[-1]["soc_end"]}
    actual = {"balance_max_kwh": maximum["balance"], "soc_dynamic_max_kwh": maximum["soc_dynamic"],
              "continuity_max_kwh": maximum["continuity"], "soc_min_kwh": minimum_soc, "soc_max_kwh": maximum_soc,
              "step_power_max_kwh": maximum["step_power"], "simultaneous_count": int(simultaneous),
              "negative_count": int(negative), "endpoints": endpoints}
    tol = cfg.numeric_tolerance if all(isinstance(r.get("plan"), float) for r in rows) else cfg.displayed_tolerance
    if name == "result1.xlsx" or len(rows) == 334 * 144:
        endpoints_ok = abs(endpoints["initial"] - cfg.initial_soc_kwh) <= cfg.displayed_tolerance and abs(endpoints["terminal"] - cfg.terminal_soc_kwh) <= cfg.displayed_tolerance
    else:
        endpoints_ok = False
    ok = (maximum["balance"] <= cfg.displayed_tolerance and maximum["soc_dynamic"] <= cfg.displayed_tolerance
          and maximum["continuity"] <= cfg.displayed_tolerance and minimum_soc >= cfg.storage_min_kwh - cfg.displayed_tolerance
          and maximum_soc <= cfg.storage_max_kwh + cfg.displayed_tolerance
          and maximum["step_power"] <= cfg.step_power_limit_kwh + cfg.displayed_tolerance
          and simultaneous == 0 and negative == 0 and endpoints_ok)
    audit.add(f"FINAL-{name}-PHYSICS", "PASS" if ok else "FAIL", "critical", name, actual,
              f"Balance/SOC residual <= {cfg.displayed_tolerance}; continuous SOC; bounds; no simultaneous charge/discharge; endpoints {cfg.initial_soc_kwh}->{cfg.terminal_soc_kwh}.",
              "independent recomputation from dispatch detail", "Physical infeasibility invalidates the strategy.")


def audit_source_mapping(audit: Audit, name: str, rows: Sequence[dict[str, Any]], input_dir: Path, cfg: AuditConfig) -> None:
    """Match every realized load, PV and settlement price to the raw attachments."""
    maxima = {"load_kwh": 0.0, "pv_kwh": 0.0, "price": 0.0}
    errors: list[str] = []
    if name == "result1.xlsx":
        wb = load_workbook(input_dir / "附件1.xlsx", data_only=True, read_only=True)
        raw = list(wb.active.iter_rows(min_row=2, values_only=True))
        wb.close()
        if len(rows) != 144:
            errors.append(f"detail rows={len(rows)}")
        else:
            for row, source in zip(rows, raw):
                maxima["price"] = max(maxima["price"], abs(row["price"] - required_number(source[1], "附件1 price")))
                maxima["load_kwh"] = max(maxima["load_kwh"], abs(row["load"] - required_number(source[2], "附件1 load") * cfg.interval_hours))
                maxima["pv_kwh"] = max(maxima["pv_kwh"], abs(row["pv"] - required_number(source[3], "附件1 pv") * cfg.interval_hours))
    else:
        wb2 = load_workbook(input_dir / "附件2.xlsx", data_only=True, read_only=True)
        wb4 = load_workbook(input_dir / "附件4.xlsx", data_only=True, read_only=True)
        load_rows = {norm_date(r[0]): r[1:145] for r in wb2["小区负载"].iter_rows(min_row=2, values_only=True)}
        pv_rows = {norm_date(r[0]): r[1:145] for r in wb2["光伏发电实际功率"].iter_rows(min_row=2, values_only=True)}
        price_rows = {norm_date(r[0]): r[1:145] for r in wb4.active.iter_rows(min_row=2, values_only=True)}
        wb2.close(); wb4.close()
        wb1 = load_workbook(input_dir / "附件1.xlsx", data_only=True, read_only=True)
        fixed_price = [required_number(r[1], "附件1 price") for r in wb1.active.iter_rows(min_row=2, values_only=True)]
        wb1.close()
        for row in rows:
            day, pos = row["date"], int(row["position"]) - 1
            if day not in load_rows or not 0 <= pos < 144:
                errors.append(f"missing raw key {day} position {pos + 1}")
                continue
            maxima["load_kwh"] = max(maxima["load_kwh"], abs(row["load"] - required_number(load_rows[day][pos], "附件2 load") * cfg.interval_hours))
            maxima["pv_kwh"] = max(maxima["pv_kwh"], abs(row["pv"] - required_number(pv_rows[day][pos], "附件2 pv") * cfg.interval_hours))
            expected_price = required_number(price_rows[day][pos], "附件4 price") if name.startswith("result4") else fixed_price[pos]
            maxima["price"] = max(maxima["price"], abs(row["price"] - expected_price))
    ok = not errors and max(maxima.values()) <= cfg.numeric_tolerance
    audit.add(f"FINAL-{name}-SOURCE-MAPPING", "PASS" if ok else "FAIL", "critical", name,
              {"maximum_errors": maxima, "errors": errors[:30]},
              f"Every realized load/PV energy and settlement price equals the same date/position in attachments within {cfg.numeric_tolerance}.",
              "dispatch detail vs 附件1/2/4", "An off-by-one interval or wrong date invalidates all costs and balances.")


def display_round(value: float, decimals: int) -> Decimal:
    quantum = Decimal(1).scaleb(-decimals)
    return Decimal(str(value)).quantize(quantum, rounding=ROUND_HALF_UP)


def decimal_sum(values: Iterable[float]) -> Decimal:
    """Sum serialized full-precision values deterministically in base 10."""
    return sum((Decimal(str(value)) for value in values), Decimal("0"))


def emergency_segments(rows: Sequence[dict[str, Any]], cfg: AuditConfig) -> list[dict[str, Any]]:
    """Filter display-zero records, then group adjacent retained positions by day."""
    result: list[dict[str, Any]] = []
    for day in date_range(MAIN_START, MAIN_END):
        day_rows = [row for row in rows if row["date"] == day]
        visible = [
            row for row in day_rows
            if row["emergency"] >= cfg.emergency_display_threshold_kwh
            and display_round(row["emergency"], cfg.display_decimals) != 0
        ]
        group: list[dict[str, Any]] = []
        for row in visible:
            if group and int(row["position"]) != int(group[-1]["position"]) + 1:
                result.append(segment_record(day, group, cfg))
                group = []
            group.append(row)
        if group:
            result.append(segment_record(day, group, cfg))
    return result


def segment_record(day: date, group: Sequence[dict[str, Any]], cfg: AuditConfig) -> dict[str, Any]:
    start_pos = int(group[0]["position"])
    end_pos = int(group[-1]["position"])
    start = (start_pos - 1) * 10
    end = end_pos * 10
    label = f"{start // 60:02d}:{start % 60:02d}-" + ("24:00" if end == 1440 else f"{end // 60:02d}:{end % 60:02d}")
    full_decimal = decimal_sum(row["emergency"] for row in group)
    full = float(full_decimal)
    return {"date": day, "start_position": start_pos, "end_position": end_pos, "interval": label,
            "full_precision_kwh": full, "display_kwh": float(full_decimal.quantize(
                Decimal(1).scaleb(-cfg.display_decimals), rounding=ROUND_HALF_UP))}


def time_range_key(label: Any) -> tuple[int, int] | None:
    text = str(label).strip().replace("：", ":")
    match = re.match(r"^(\d{1,2}):(\d{2})-(\d{1,2}):(\d{2})$", text)
    if not match:
        return None
    sh, sm, eh, em = map(int, match.groups())
    return sh * 60 + sm, eh * 60 + em


def read_emergency_sheet(path: Path) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    wb = load_workbook(path, data_only=True, read_only=True)
    if "紧急购电量" not in wb.sheetnames:
        wb.close()
        return [], {"error_count": 1, "samples": ["缺少紧急购电量工作表"]}
    ws = wb["紧急购电量"]
    rows: list[dict[str, Any]] = []
    errors: list[str] = []
    current: date | None = None
    for row_num, raw in enumerate(ws.iter_rows(min_row=2, values_only=True), 2):
        if all(value in (None, "") for value in raw[:3]):
            continue
        if raw[0] not in (None, ""):
            try:
                current = norm_date(raw[0])
            except ValueError as exc:
                errors.append(f"row {row_num}: {exc}")
                current = None
        if current is None:
            errors.append(f"row {row_num}: 日期为空且无可继承日期")
            continue
        key = time_range_key(raw[1])
        if key is None:
            errors.append(f"row {row_num}: 无效连续区间 {raw[1]!r}")
            continue
        try:
            amount = required_number(raw[2], f"紧急购电量!C{row_num}")
        except ValueError as exc:
            errors.append(str(exc))
            continue
        rows.append({"date": current, "time_key": key, "interval": str(raw[1]).strip(), "amount": amount, "row": row_num})
    wb.close()
    return rows, {"error_count": len(errors), "samples": errors[:30]}


def audit_emergency(audit: Audit, name: str, workbook_path: Path, rows: Sequence[dict[str, Any]], cfg: AuditConfig, out_dir: Path) -> None:
    expected = emergency_segments(rows, cfg)
    actual, scan = read_emergency_sheet(workbook_path)
    missing: list[dict[str, Any]] = []
    extra: list[dict[str, Any]] = []
    amount_errors: list[dict[str, Any]] = []
    actual_map = {(row["date"], row["time_key"]): row for row in actual}
    expected_map = {(row["date"], time_range_key(row["interval"])): row for row in expected}
    for key, exp in expected_map.items():
        got = actual_map.get(key)
        if got is None:
            missing.append({"date": str(exp["date"]), "interval": exp["interval"], "display_kwh": exp["display_kwh"]})
        elif abs(got["amount"] - exp["display_kwh"]) > 0.5 * 10 ** (-cfg.display_decimals) + 1e-12:
            amount_errors.append({"date": str(exp["date"]), "interval": exp["interval"],
                                  "actual": got["amount"], "expected_display": exp["display_kwh"],
                                  "full_precision": exp["full_precision_kwh"]})
    for key, got in actual_map.items():
        if key not in expected_map:
            extra.append({"date": str(got["date"]), "interval": got["interval"], "amount": got["amount"]})
    order_expected = [(row["date"], time_range_key(row["interval"])) for row in expected]
    order_actual = [(row["date"], row["time_key"]) for row in actual]
    ok = scan["error_count"] == 0 and not missing and not extra and not amount_errors and order_actual == order_expected
    audit.add(f"FINAL-{name}-EMERGENCY-SEGMENTS", "PASS" if ok else "FAIL", "critical", name,
              {"threshold_kwh": cfg.emergency_display_threshold_kwh, "rounding_rule": f"ROUND_HALF_UP to {cfg.display_decimals} decimals",
               "detail_source": str(rows[0].get("_source", "dispatch detail")) if rows else "dispatch detail",
               "expected_segments": len(expected), "actual_segments": len(actual), "sheet_scan": scan,
               "missing_count": len(missing), "missing_samples": missing[:30], "extra_count": len(extra),
               "extra_samples": extra[:30], "amount_error_count": len(amount_errors),
               "amount_error_samples": amount_errors[:30], "order_exact": order_actual == order_expected},
              "Every displayed segment exactly equals the contiguous non-display-zero full-precision records, in chronological order.",
              f"{workbook_path}:紧急购电量", "A total-only comparison can hide omitted or incorrectly split intervals.")
    csv_path = out_dir / f"{Path(name).stem}_emergency_rebuilt.csv"
    with csv_path.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=["date", "start_position", "end_position", "interval", "full_precision_kwh", "display_kwh"])
        writer.writeheader()
        for row in expected:
            writer.writerow({**row, "date": row["date"].isoformat()})


def attachment3_release_keys(input_dir: Path) -> set[tuple[date, str]]:
    """Return the release date/clock pairs physically present in Attachment 3."""
    path = input_dir / "附件3.xlsx"
    if not path.is_file():
        return set()
    wb = load_workbook(path, data_only=True, read_only=True)
    try:
        ws = wb["Sheet1"]
        current: date | None = None
        releases: set[tuple[date, str]] = set()
        for row in ws.iter_rows(min_row=2, values_only=True):
            if row[0] not in (None, ""):
                current = norm_date(row[0])
            if current is not None:
                releases.add((current, norm_clock(row[1])))
        return releases
    finally:
        wb.close()


def load_versions(results_dir: Path, name: str,
                  forecast_release_keys: set[tuple[date, str]] | None = None
                  ) -> tuple[dict[str, list[dict[str, Any]]], Path | None, dict[str, Any]]:
    stem = Path(name).stem
    aliases = {stem.replace("-", "_"), stem.replace("result", "q").replace("-", "_")}
    mode = "q3" if name == "result3.xlsx" else "q4_3"
    candidates = [
        p for p in results_dir.rglob("*.csv")
        if "version" in p.name.lower()
        and (p.name.lower() == "decision_versions.csv" or any(a in p.name.lower().replace("-", "_") for a in aliases))
    ] if results_dir.exists() else []
    for path in sorted(candidates):
        with path.open(newline="", encoding="utf-8-sig") as handle:
            reader = csv.DictReader(handle)
            fields = set(reader.fieldnames or [])
            old_field = "previous_commitment_kwh" if "previous_commitment_kwh" in fields else "old_commitment_kwh"
            if not {"date", "position", old_field, "new_commitment_kwh"}.issubset(fields):
                continue
            formal_rows: list[dict[str, Any]] = []
            sensitivity_rows: list[dict[str, Any]] = []
            errors = []
            preview_next_day_rows = 0
            preview_recourse_rows = 0
            preview_commitment_violations = 0
            preview_target_date_violations = 0
            preview_grid_violations = 0
            preview_records: list[tuple[date, int, date, int]] = []
            preview_samples: list[str] = []
            filtered_other_runs = 0
            future_history_references = 0
            basis_counts: Counter[str] = Counter()
            forecast_release_checked = 0
            forecast_release_missing = 0
            forecast_release_parse_errors = 0
            forecast_release_time_mismatches = 0
            forecast_release_attachment_missing = 0
            forecast_release_samples: list[str] = []
            selected_version_rows = 0
            for row_num, row in enumerate(reader, 2):
                if row.get("mode") not in (None, "", mode):
                    continue
                if row.get("scenario") not in (None, "", "S3") or row.get("model_arm") not in (None, "", "all_three"):
                    filtered_other_runs += 1
                    continue
                selected_version_rows += 1
                try:
                    day = norm_date(row["date"])
                    if row.get("decision_hour") not in (None, ""):
                        decision_hour = int(required_number(row["decision_hour"], f"row {row_num} decision_hour"))
                    else:
                        match = re.search(r"\b(\d{2}):00$", str(row.get("decision_time", "")))
                        if not match:
                            raise ValueError(f"row {row_num}: cannot derive decision hour")
                        decision_hour = int(match.group(1))
                    decision_text = str(row.get("decision_time", "")).strip()
                    forecast_text = str(row.get("forecast_issue_time", "")).strip()
                    if not forecast_text:
                        forecast_release_missing += 1
                        if len(forecast_release_samples) < 30:
                            forecast_release_samples.append(f"row {row_num}: missing forecast_issue_time")
                    else:
                        try:
                            decision_dt = datetime.fromisoformat(decision_text)
                            forecast_dt = datetime.fromisoformat(forecast_text)
                        except ValueError:
                            forecast_release_parse_errors += 1
                            if len(forecast_release_samples) < 30:
                                forecast_release_samples.append(
                                    f"row {row_num}: invalid decision/forecast time {decision_text!r}/{forecast_text!r}")
                        else:
                            forecast_release_checked += 1
                            valid_decision = (decision_dt.date() == day and decision_dt.hour in {0, 6, 12, 18}
                                              and decision_dt.minute == 0 and decision_dt.second == 0
                                              and decision_dt.microsecond == 0 and decision_dt.hour == decision_hour)
                            if not valid_decision or forecast_dt != decision_dt:
                                forecast_release_time_mismatches += 1
                                if len(forecast_release_samples) < 30:
                                    forecast_release_samples.append(
                                        f"row {row_num}: decision={decision_text!r}, forecast={forecast_text!r}, date={day}")
                            release_key = (forecast_dt.date(), forecast_dt.strftime("%H:%M"))
                            if forecast_release_keys is not None and release_key not in forecast_release_keys:
                                forecast_release_attachment_missing += 1
                                if len(forecast_release_samples) < 30:
                                    forecast_release_samples.append(
                                        f"row {row_num}: Attachment 3 has no release {release_key[0]} {release_key[1]}")
                    position = int(required_number(row["position"], f"row {row_num} position"))
                    preview_next = str(row.get("is_preview_next_day", "0")).strip() in {"1", "true", "True"}
                    preview_recourse = str(row.get("is_preview_recourse", "0")).strip() in {"1", "true", "True"}
                    preview_next_day_rows += int(preview_next)
                    preview_recourse_rows += int(preview_recourse)
                    for field in ("load_history_dates", "price_history_dates", "pv_bias_history_dates", "residual_scenario_dates"):
                        for token in filter(None, str(row.get(field, "")).split("|")):
                            if norm_date(token) >= day:
                                future_history_references += 1
                    formal_old_raw = row.get(old_field)
                    formal_new_raw = row.get("new_commitment_kwh")
                    sensitivity_old_raw = row.get("sensitivity_old_commitment_kwh")
                    sensitivity_new_raw = row.get("sensitivity_new_commitment_kwh")
                    decision_basis = str(row.get("decision_basis", "")).strip()
                    basis_counts[decision_basis or "<missing>"] += 1
                    allowed_basis = {"next_block_stochastic", "deterministic_day_ahead_backup",
                                     "deterministic_point_forecast_sensitivity", "next_day_preview"}
                    if decision_basis not in allowed_basis:
                        errors.append(f"row {row_num}: invalid decision_basis {decision_basis!r}")
                    if preview_next:
                        if any(value not in (None, "") for value in (formal_old_raw, formal_new_raw, sensitivity_old_raw, sensitivity_new_raw)):
                            errors.append(f"row {row_num}: next-day preview contains a commitment")
                            preview_commitment_violations += 1
                            if len(preview_samples) < 30:
                                preview_samples.append(f"row {row_num}: preview contains formal/sensitivity commitment")
                        target_day: date | None = None
                        try:
                            target_day = norm_date(row.get("target_date"))
                        except ValueError as exc:
                            preview_target_date_violations += 1
                            if len(preview_samples) < 30:
                                preview_samples.append(f"row {row_num}: invalid target_date: {exc}")
                        else:
                            if target_day <= day or target_day != day + timedelta(days=1):
                                preview_target_date_violations += 1
                                if len(preview_samples) < 30:
                                    preview_samples.append(
                                        f"row {row_num}: target_date {target_day} is not the next day after {day}")
                        try:
                            preview_grid = required_number(row.get("preview_grid_kwh"), f"row {row_num} preview_grid_kwh")
                        except ValueError as exc:
                            preview_grid_violations += 1
                            if len(preview_samples) < 30:
                                preview_samples.append(str(exc))
                        else:
                            if preview_grid < 0:
                                preview_grid_violations += 1
                                if len(preview_samples) < 30:
                                    preview_samples.append(f"row {row_num}: negative preview_grid_kwh {preview_grid}")
                        if target_day is not None:
                            preview_records.append((day, decision_hour, target_day, position))
                        continue
                    common = {"date": day, "decision_hour": decision_hour, "position": position,
                              "decision_basis": decision_basis}
                    if formal_new_raw not in (None, ""):
                        formal_rows.append({**common,
                                            "previous": None if decision_hour == 0 and formal_old_raw in (None, "") else required_number(formal_old_raw, f"row {row_num} formal previous"),
                                            "new": required_number(formal_new_raw, f"row {row_num} formal new")})
                    elif formal_old_raw not in (None, ""):
                        errors.append(f"row {row_num}: formal old exists without formal new")
                    if sensitivity_new_raw not in (None, ""):
                        sensitivity_rows.append({**common,
                                                 "previous": None if decision_hour == 0 and sensitivity_old_raw in (None, "") else required_number(sensitivity_old_raw, f"row {row_num} sensitivity previous"),
                                                 "new": required_number(sensitivity_new_raw, f"row {row_num} sensitivity new")})
                    elif sensitivity_old_raw not in (None, ""):
                        errors.append(f"row {row_num}: sensitivity old exists without sensitivity new")
                except (ValueError, TypeError) as exc:
                    errors.append(str(exc))
            preview_counts = Counter((day, hour) for day, hour, _, _ in preview_records)
            expected_preview_per_decision = {0: 0, 6: 36, 12: 72, 18: 108}
            preview_count_errors = sum(
                preview_counts[(day, hour)] != count
                for day in date_range(MAIN_START, MAIN_END)
                for hour, count in expected_preview_per_decision.items()
                if not (day == MAIN_END and count > 0)
            )
            preview_count_errors += sum(preview_counts[(MAIN_END, hour)] != 0 for hour in expected_preview_per_decision)
            expected_preview_records = [
                (day, hour, day + timedelta(days=1), position)
                for day in date_range(MAIN_START, MAIN_END - timedelta(days=1))
                for hour, count in expected_preview_per_decision.items()
                for position in range(1, count + 1)
            ]
            preview_sequence_exact = preview_records == expected_preview_records
            preview_sequence_sample: dict[str, Any] | None = None
            if not preview_sequence_exact:
                for index in range(min(len(preview_records), len(expected_preview_records))):
                    if preview_records[index] != expected_preview_records[index]:
                        preview_sequence_sample = {"index": index, "actual": preview_records[index],
                                                   "expected": expected_preview_records[index]}
                        break
                if preview_sequence_sample is None:
                    preview_sequence_sample = {"actual_rows": len(preview_records),
                                               "expected_rows": len(expected_preview_records)}
            return {"formal": formal_rows, "sensitivity": sensitivity_rows}, path, {
                                "error_count": len(errors), "samples": errors[:30],
                                "preview_next_day_rows": preview_next_day_rows,
                                "preview_recourse_rows": preview_recourse_rows,
                                "preview_next_day_integrity": {
                                    "rows": preview_next_day_rows,
                                    "parsed_records": len(preview_records),
                                    "expected_rows": 71928,
                                    "expected_per_decision": expected_preview_per_decision,
                                    "decision_count_errors": preview_count_errors,
                                    "sequence_exact": preview_sequence_exact,
                                    "sequence_mismatch_sample": preview_sequence_sample,
                                    "commitment_violations": preview_commitment_violations,
                                    "target_date_violations": preview_target_date_violations,
                                    "preview_grid_violations": preview_grid_violations,
                                    "samples": preview_samples,
                                },
                                "filtered_other_runs": filtered_other_runs,
                                "future_history_references": future_history_references,
                                "decision_basis_counts": dict(basis_counts),
                                "forecast_release": {
                                    "selected_rows": selected_version_rows,
                                    "checked_rows": forecast_release_checked,
                                    "missing_field": forecast_release_missing,
                                    "parse_errors": forecast_release_parse_errors,
                                    "decision_time_mismatches": forecast_release_time_mismatches,
                                    "attachment_release_missing": forecast_release_attachment_missing,
                                    "samples": forecast_release_samples,
                                }}
    return {"formal": [], "sensitivity": []}, None, {"error_count": 1, "samples": ["未找到逐次承诺版本CSV"]}


def audit_settlement(audit: Audit, name: str, rows: Sequence[dict[str, Any]], results_dir: Path,
                     input_dir: Path, cfg: AuditConfig) -> None:
    if not rows:
        return
    final_components = defaultdict(float)
    final_row_error = 0.0
    component_row_errors = defaultdict(float)
    for row in rows:
        baseline, adjusted, price, emergency = row["plan"], row["adjusted"], row["price"], row["emergency"]
        down = max(baseline - adjusted, 0.0)
        up = max(adjusted - baseline, 0.0)
        components = {
            "normal_yuan": price * min(baseline, adjusted),
            "down_yuan": 0.5 * price * down,
            "up_yuan": 1.5 * price * up,
            "emergency_yuan": 5.0 * price * emergency,
        }
        for key, value in components.items():
            final_components[key] += value
        expected = sum(components.values())
        signed_adjustment = -components["down_yuan"] + components["up_yuan"]
        stored_expectations = {
            "plan_cost": price * baseline,
            "adjustment_cost": signed_adjustment,
            "emergency_cost": components["emergency_yuan"],
            "final_cost": expected,
        }
        for field, value in stored_expectations.items():
            if field in row:
                component_row_errors[field] = max(component_row_errors[field], abs(row[field] - value))
        if "final_cost" in row:
            final_row_error = max(final_row_error, abs(row["final_cost"] - expected))
    final_components["total_yuan"] = sum(final_components[key] for key in ("normal_yuan", "down_yuan", "up_yuan", "emergency_yuan"))
    required_stored = ("plan_cost", "adjustment_cost", "emergency_cost", "final_cost")
    stored_complete = all(all(field in row for field in required_stored) for row in rows)
    final_ok = stored_complete and max(component_row_errors.values(), default=0.0) <= cfg.numeric_tolerance
    audit.add(f"FINAL-{name}-SETTLEMENT-FINAL", "PASS" if final_ok else "FAIL", "critical", name,
              {"components": dict(final_components), "stored_components_complete": stored_complete,
               "component_row_max_errors_yuan": dict(component_row_errors), "row_max_error_yuan": final_row_error},
              "p*min(B,A)+0.5p(B-A)^+ +1.5p(A-B)^+ +5pQ on every row, full precision.",
              "dispatch detail", "The main reported cost uses this convention.")

    release_keys = attachment3_release_keys(input_dir)
    ledgers, path, scan = load_versions(results_dir, name, release_keys)
    release_scan = scan.get("forecast_release", {})
    release_violations = sum(int(release_scan.get(field, 0)) for field in
                             ("missing_field", "parse_errors", "decision_time_mismatches", "attachment_release_missing"))
    release_unexamined = max(0, int(release_scan.get("selected_rows", 0))
                             - int(release_scan.get("checked_rows", 0))
                             - int(release_scan.get("missing_field", 0))
                             - int(release_scan.get("parse_errors", 0)))
    release_ok = path is not None and bool(release_keys) and release_violations == 0 and release_unexamined == 0
    audit.add(f"FINAL-{name}-FORECAST-RELEASE", "PASS" if release_ok else "FAIL", "critical", name,
              {"version_source": str(path) if path is not None else None,
               "attachment_release_count": len(release_keys),
               "violations": release_violations, "unexamined_rows": release_unexamined, **release_scan},
              "Every selected decision version has forecast_issue_time exactly equal to its same-day 00/06/12/18 decision_time, and Attachment 3 contains that release.",
              str(path or results_dir), "A missing or shifted release timestamp can conceal future-information leakage.")
    preview_scan = scan.get("preview_next_day_integrity", {})
    preview_ok = (path is not None and int(preview_scan.get("rows", -1)) == 71928
                  and int(preview_scan.get("parsed_records", -1)) == 71928
                  and int(preview_scan.get("decision_count_errors", -1)) == 0
                  and bool(preview_scan.get("sequence_exact", False))
                  and all(int(preview_scan.get(field, -1)) == 0 for field in
                          ("commitment_violations", "target_date_violations", "preview_grid_violations")))
    audit.add(f"FINAL-{name}-NEXT-DAY-PREVIEW", "PASS" if preview_ok else "FAIL", "critical", name,
              {"version_source": str(path) if path is not None else None, **preview_scan},
              "Per mode: 333 days x (36+72+108) = 71,928 ordered next-day preview rows; target_date is the following day, positions are 1..36/72/108 at 06/12/18, all four commitment fields are blank, and preview_grid_kwh is finite non-negative.",
              str(path or results_dir), "Missing, duplicated or executable preview rows invalidate the cross-day rolling contract.")
    if path is None:
        audit.add(f"FINAL-{name}-SETTLEMENT-SEQUENTIAL", "FAIL", "critical", name, scan,
                  "Timestamped commitment versions exist and independently reproduce sequential settlement.",
                  str(results_dir), "Sequential sensitivity cannot be authenticated without every revision.")
        return
    detail_by_key = {(row["date"], int(row["position"])): row for row in rows}
    formal = ledgers["formal"]
    sensitivity = ledgers["sensitivity"]
    formal_by_key: dict[tuple[date, int], list[dict[str, Any]]] = defaultdict(list)
    sensitivity_by_key: dict[tuple[date, int], list[dict[str, Any]]] = defaultdict(list)
    formal_past = sensitivity_past = 0
    for version in formal:
        formal_by_key[(version["date"], version["position"])].append(version)
        formal_past += version["position"] < version["decision_hour"] * 6 + 1
    for version in sensitivity:
        sensitivity_by_key[(version["date"], version["position"])].append(version)
        sensitivity_past += version["position"] < version["decision_hour"] * 6 + 1

    # Formal execution ledger: exactly one 36-interval block per decision,
    # chained from the 00:00 baseline and ending at executed dispatch.
    formal_chain_errors = 0
    formal_final_mismatches = 0
    for key, row in detail_by_key.items():
        current = row["plan"]
        for version in sorted(formal_by_key.get(key, []), key=lambda x: x["decision_hour"]):
            if version["decision_hour"] == 0:
                if abs(version["new"] - row["plan"]) > cfg.numeric_tolerance:
                    formal_chain_errors += 1
            elif version["previous"] is None or abs(version["previous"] - current) > cfg.numeric_tolerance:
                formal_chain_errors += 1
            current = version["new"]
        if abs(current - row["adjusted"]) > cfg.numeric_tolerance:
            formal_final_mismatches += 1
    formal_counts = Counter((row["date"], row["decision_hour"]) for row in formal)
    expected_formal_by_hour = {0: 144, 6: 36, 12: 36, 18: 36}
    formal_decision_count_errors = sum(formal_counts[(day, hour)] != count for day in date_range(MAIN_START, MAIN_END) for hour, count in expected_formal_by_hour.items())
    formal_ok = (len(formal) == 334 * 252 and formal_decision_count_errors == 0 and formal_past == 0
                 and formal_chain_errors == 0 and formal_final_mismatches == 0)

    # Sequential sensitivity ledger: 00:00 baseline, followed by every
    # remaining same-day deterministic proposal at 06/12/18.
    total = 0.0
    row_errors = 0.0
    sensitivity_chain_errors = 0
    for key, row in detail_by_key.items():
        base = row["plan"]
        cost = row["price"] * base + 5 * row["price"] * row["emergency"]
        current = base
        for version in sorted(sensitivity_by_key.get(key, []), key=lambda x: x["decision_hour"]):
            if version["decision_hour"] == 0:
                if abs(version["new"] - base) > cfg.numeric_tolerance:
                    sensitivity_chain_errors += 1
                current = version["new"]
                continue
            if version["previous"] is None or abs(version["previous"] - current) > cfg.numeric_tolerance:
                sensitivity_chain_errors += 1
            cost += -0.5 * row["price"] * max(current - version["new"], 0.0)
            cost += 1.5 * row["price"] * max(version["new"] - current, 0.0)
            current = version["new"]
        total += cost
        if "sequential_cost" in row:
            row_errors = max(row_errors, abs(row["sequential_cost"] - cost))
    expected_sensitivity_count = 334 * 360
    sensitivity_counts = Counter((row["date"], row["decision_hour"]) for row in sensitivity)
    expected_by_hour = {0: 144, 6: 108, 12: 72, 18: 36}
    sensitivity_decision_count_errors = sum(sensitivity_counts[(day, hour)] != count for day in date_range(MAIN_START, MAIN_END) for hour, count in expected_by_hour.items())
    ok = (scan["error_count"] == 0 and scan.get("future_history_references", 0) == 0
          and formal_ok and len(sensitivity) == expected_sensitivity_count
          and sensitivity_decision_count_errors == 0 and sensitivity_past == 0
          and sensitivity_chain_errors == 0
          and all("sequential_cost" in row for row in rows) and row_errors <= cfg.numeric_tolerance)
    audit.add(f"FINAL-{name}-SETTLEMENT-SEQUENTIAL", "PASS" if ok else "FAIL", "critical", name,
              {"version_source": str(path), "version_scan": scan,
               "formal_chain": {"rows": len(formal), "expected_rows": 334 * 252,
                                "expected_per_decision": expected_formal_by_hour,
                                "decision_count_errors": formal_decision_count_errors,
                                "past_interval_rewrites": int(formal_past),
                                "commitment_chain_errors": formal_chain_errors,
                                "final_dispatch_mismatches": formal_final_mismatches},
               "sensitivity_chain": {"rows": len(sensitivity), "expected_rows": expected_sensitivity_count,
                                      "expected_per_decision": expected_by_hour,
                                      "decision_count_errors": sensitivity_decision_count_errors,
                                      "past_interval_rewrites": int(sensitivity_past),
                                      "commitment_chain_errors": sensitivity_chain_errors},
               "future_history_references": scan.get("future_history_references", 0), "recomputed_total_yuan": total,
               "stored_row_cost_present": all("sequential_cost" in row for row in rows),
               "row_max_error_yuan": row_errors},
              "Formal ledger: 252 versions/day (144 at 00:00, then 36 next-block changes at 06/12/18). Sensitivity ledger: 360 same-day versions/day (144/108/72/36), independently recomputing initial pB plus every transition and emergency 5pQ; no past or next-day commitment.",
              str(path), "The required sensitivity total depends on the entire commitment chain.")


def audit_unadjusted_cost(audit: Audit, name: str, rows: Sequence[dict[str, Any]], cfg: AuditConfig) -> None:
    maxima = defaultdict(float)
    totals = defaultdict(float)
    complete = all(all(field in row for field in ("plan_cost", "emergency_cost", "final_cost")) for row in rows)
    for row in rows:
        plan = row["price"] * row["plan"]
        emergency = 5.0 * row["price"] * row["emergency"]
        total = plan + emergency
        totals["plan_yuan"] += plan; totals["emergency_yuan"] += emergency; totals["total_yuan"] += total
        if complete:
            maxima["plan"] = max(maxima["plan"], abs(row["plan_cost"] - plan))
            maxima["emergency"] = max(maxima["emergency"], abs(row["emergency_cost"] - emergency))
            maxima["total"] = max(maxima["total"], abs(row["final_cost"] - total))
    ok = complete and max(maxima.values(), default=0.0) <= cfg.numeric_tolerance
    audit.add(f"FINAL-{name}-COST", "PASS" if ok else "FAIL", "critical", name,
              {"stored_components_complete": complete, "row_max_errors_yuan": dict(maxima), "totals": dict(totals)},
              "Every row independently reproduces plan pB, emergency 5pQ and their total from full precision.",
              "dispatch detail", "Q2/Q4-2 reported costs must include all realized settlement terms.")


def audit_plan_sheet(audit: Audit, name: str, path: Path, template: Path) -> None:
    wb = load_workbook(path, data_only=True, read_only=True)
    twb = load_workbook(template, data_only=True, read_only=True)
    sheets = ["计划购电量"] + (["调整购电量"] if "调整购电量" in twb.sheetnames else [])
    expected_dates = date_range(MAIN_START, MAIN_END)
    for sheet in sheets:
        ws = wb[sheet]
        tws = twb[sheet]
        header = tuple(next(ws.iter_rows(values_only=True)))
        expected_header = tuple(next(tws.iter_rows(values_only=True)))
        if name == "result1.xlsx":
            rows = list(ws.iter_rows(min_row=2, values_only=True))
            labels = [row[0] for row in rows]
            expected_labels = [row[0] for row in tws.iter_rows(min_row=2, values_only=True)]
            _, numeric = scan_required_numbers((f"{sheet}!B{i}", row[1]) for i, row in enumerate(rows, 2))
            ok = header == expected_header and labels == expected_labels and len(set(labels)) == 144 and numeric["error_count"] == 0
            actual = {"header_exact": header == expected_header, "rows": len(rows), "unique_labels": len(set(labels)),
                      "label_order_exact": labels == expected_labels, "numeric_scan": numeric}
        else:
            rows = list(ws.iter_rows(min_row=2, values_only=True))
            dates: list[date] = []
            date_errors: list[str] = []
            for idx, row in enumerate(rows, 2):
                try:
                    dates.append(norm_date(row[0]))
                except ValueError as exc:
                    date_errors.append(f"row {idx}: {exc}")
            _, numeric = scan_required_numbers(
                (f"{sheet}!R{r}C{c}", value)
                for r, row in enumerate(rows, 2) for c, value in enumerate(row[1:147], 2)
            )
            interval_header = header[1:145]
            ok = (header == expected_header and dates == expected_dates and len(set(dates)) == 334
                  and len(interval_header) == 144 and len(set(interval_header)) == 144
                  and not date_errors and numeric["error_count"] == 0)
            actual = {"header_exact": header == expected_header, "days": len(dates), "unique_dates": len(set(dates)),
                      "date_order_exact": dates == expected_dates, "date_errors": date_errors[:20],
                      "intervals": len(interval_header), "unique_interval_labels": len(set(interval_header)),
                      "numeric_scan": numeric}
        audit.add(f"FINAL-{name}-{sheet}-COVERAGE", "PASS" if ok else "FAIL", "critical", f"{name}/{sheet}",
                  actual, "Exact template header and label order; exact date population; all required result cells finite numeric.",
                  f"{path} vs {template}", "Official-table gaps or schema drift invalidate the submission.")
    wb.close()
    twb.close()


def audit_plan_values(audit: Audit, name: str, path: Path, rows: Sequence[dict[str, Any]], cfg: AuditConfig) -> None:
    """Reconcile all official 10-minute cells, daily energy and daily cost."""
    by_date: dict[date, list[dict[str, Any]]] = defaultdict(list)
    for row in rows:
        by_date[row["date"]].append(row)
    wb = load_workbook(path, data_only=True, read_only=True)
    targets = [("计划购电量", "plan")]
    if name in {"result3.xlsx", "result4-3.xlsx"}:
        targets.append(("调整购电量", "adjusted"))
    for sheet, field in targets:
        ws = wb[sheet]
        cell_error = 0.0
        energy_error = 0.0
        cost_error = 0.0
        errors: list[str] = []
        for excel_row, values in enumerate(ws.iter_rows(min_row=2, values_only=True), 2):
            try:
                day = norm_date(values[0])
            except ValueError as exc:
                errors.append(f"row {excel_row}: {exc}")
                continue
            detail_rows = by_date.get(day, [])
            if len(detail_rows) != 144:
                errors.append(f"row {excel_row}: {day} detail rows={len(detail_rows)}")
                continue
            try:
                displayed = [required_number(value, f"{sheet}!R{excel_row}C{col}") for col, value in enumerate(values[1:145], 2)]
                daily_energy = required_number(values[145], f"{sheet}!R{excel_row}C146")
                daily_cost = required_number(values[146], f"{sheet}!R{excel_row}C147")
            except ValueError as exc:
                errors.append(str(exc))
                continue
            expected_cells = [float(display_round(row[field], cfg.display_decimals)) for row in detail_rows]
            cell_error = max(cell_error, max(abs(a - b) for a, b in zip(displayed, expected_cells)))
            energy_expected = float(decimal_sum(row[field] for row in detail_rows).quantize(
                Decimal(1).scaleb(-cfg.display_decimals), rounding=ROUND_HALF_UP))
            energy_error = max(energy_error, abs(daily_energy - energy_expected))
            if field == "adjusted":
                cost_expected = math.fsum(
                    row["price"] * min(row["plan"], row["adjusted"])
                    + 0.5 * row["price"] * max(row["plan"] - row["adjusted"], 0.0)
                    + 1.5 * row["price"] * max(row["adjusted"] - row["plan"], 0.0)
                    + 5.0 * row["price"] * row["emergency"] for row in detail_rows
                )
            else:
                # The official plan sheet labels this as planned purchase cost;
                # Q2/Q4-2 have no adjustment sheet, so their daily total also
                # carries emergency settlement.  Q3/Q4-3 report it on the
                # adjusted sheet and keep the initial-plan cost separate.
                if name in {"result2.xlsx", "result4-2.xlsx"}:
                    cost_expected = math.fsum(row["price"] * row["plan"] + 5.0 * row["price"] * row["emergency"] for row in detail_rows)
                else:
                    cost_expected = math.fsum(row["price"] * row["plan"] for row in detail_rows)
            cost_error = max(cost_error, abs(daily_cost - float(display_round(cost_expected, cfg.display_decimals))))
        limit = 0.5 * 10 ** (-cfg.display_decimals) + 1e-12
        ok = not errors and cell_error <= limit and energy_error <= limit and cost_error <= limit
        audit.add(f"FINAL-{name}-{sheet}-VALUES", "PASS" if ok else "FAIL", "critical", f"{name}/{sheet}",
                  {"detail_field": field, "cell_max_error": cell_error, "daily_energy_max_error": energy_error,
                   "daily_cost_max_error": cost_error, "errors": errors[:30]},
                  f"All 10-minute cells and each daily energy/cost total equal the {cfg.display_decimals}-decimal half-up rendering of full-precision detail.",
                  f"{path}:{sheet}", "Official cells, aggregates and paper totals must share one frozen result source.")
    wb.close()


def audit_q1_values(audit: Audit, path: Path, rows: Sequence[dict[str, Any]], cfg: AuditConfig) -> None:
    wb = load_workbook(path, data_only=True, read_only=True)
    ws = wb["计划购电量"]
    values = list(ws.iter_rows(min_row=2, values_only=True))
    errors: list[str] = []
    maximum = 0.0
    if len(values) != 144 or len(rows) != 144:
        errors.append(f"official rows={len(values)}, detail rows={len(rows)}")
    else:
        for idx, (official, detail) in enumerate(zip(values, rows), 2):
            try:
                actual = required_number(official[1], f"计划购电量!B{idx}")
            except ValueError as exc:
                errors.append(str(exc))
                continue
            maximum = max(maximum, abs(actual - float(display_round(detail["plan"], cfg.display_decimals))))
    limit = 0.5 * 10 ** (-cfg.display_decimals) + 1e-12
    audit.add("FINAL-result1.xlsx-计划购电量-VALUES", "PASS" if not errors and maximum <= limit else "FAIL", "critical",
              "result1.xlsx/计划购电量", {"cell_max_error": maximum, "errors": errors[:30]},
              "All 144 official quantities equal the four-decimal rendering of full-precision detail.",
              f"{path}:计划购电量", "Q1 official cells must trace to the frozen LP result.")
    wb.close()


def audit_four_hour_sheet(audit: Audit, name: str, path: Path, rows: Sequence[dict[str, Any]], cfg: AuditConfig) -> None:
    """Validate every supplied four-hour row and all required date blocks."""
    wb = load_workbook(path, data_only=True, read_only=True)
    ws = wb["充放电量"]
    header = tuple(next(ws.iter_rows(values_only=True)))
    expected_header = ("时间段", "充电量", "放电量", "时刻", "储电量") if name == "result1.xlsx" else ("日期", "时间段", "充电量", "放电量", "时刻", "储电量")
    detail_by_date: dict[date, list[dict[str, Any]]] = defaultdict(list)
    for row in rows:
        detail_by_date[row["date"]].append(row)
    current: date | None = MAIN_START if name == "result1.xlsx" else None
    block_labels: dict[date, list[str]] = defaultdict(list)
    maximum = {"charge": 0.0, "discharge": 0.0}
    errors: list[str] = []
    observed_dates: list[date] = []
    for row_num, raw in enumerate(ws.iter_rows(min_row=2, values_only=True), 2):
        if raw[0] == "⁝" or (name != "result1.xlsx" and raw[1] == "⁝"):
            continue
        if name == "result1.xlsx":
            label, c_raw, d_raw = raw[0], raw[1], raw[2]
        else:
            if raw[0] not in (None, ""):
                try:
                    current = norm_date(raw[0])
                    if not observed_dates or observed_dates[-1] != current:
                        observed_dates.append(current)
                except ValueError as exc:
                    errors.append(f"row {row_num}: {exc}")
                    current = None
            label, c_raw, d_raw = raw[1], raw[2], raw[3]
        if current is None:
            errors.append(f"row {row_num}: no date")
            continue
        if label not in FOUR_HOUR_LABELS:
            errors.append(f"row {row_num}: invalid four-hour label {label!r}")
            continue
        block_labels[current].append(label)
        try:
            actual_c = required_number(c_raw, f"充放电量 row {row_num} charge")
            actual_d = required_number(d_raw, f"充放电量 row {row_num} discharge")
        except ValueError as exc:
            errors.append(str(exc))
            continue
        day_rows = detail_by_date.get(current, [])
        if len(day_rows) != 144:
            errors.append(f"row {row_num}: detail rows for {current}={len(day_rows)}")
            continue
        group = FOUR_HOUR_LABELS.index(label)
        expected_c = float(decimal_sum(r["charge"] for r in day_rows[group * 24:(group + 1) * 24]).quantize(
            Decimal(1).scaleb(-cfg.display_decimals), rounding=ROUND_HALF_UP))
        expected_d = float(decimal_sum(r["discharge"] for r in day_rows[group * 24:(group + 1) * 24]).quantize(
            Decimal(1).scaleb(-cfg.display_decimals), rounding=ROUND_HALF_UP))
        maximum["charge"] = max(maximum["charge"], abs(actual_c - expected_c))
        maximum["discharge"] = max(maximum["discharge"], abs(actual_d - expected_d))
    bad_blocks = {str(day): labels for day, labels in block_labels.items() if labels != list(FOUR_HOUR_LABELS)}
    required_dates = {MAIN_START} if name == "result1.xlsx" else {MAIN_START, MAIN_START + timedelta(days=1), MAIN_END}
    if name in {"result3.xlsx", "result4-3.xlsx"}:
        required_dates.add(date(2025, 3, 20))
    missing_required = sorted(str(day) for day in required_dates - set(block_labels))
    limit = 0.5 * 10 ** (-cfg.display_decimals) + 1e-12
    ok = header == expected_header and not errors and not bad_blocks and not missing_required and max(maximum.values()) <= limit
    audit.add(f"FINAL-{name}-4H", "PASS" if ok else "FAIL", "high", f"{name}/充放电量",
              {"header_exact": header == expected_header, "date_blocks": len(block_labels), "observed_dates": [str(x) for x in observed_dates],
               "missing_required_dates": missing_required, "bad_blocks": dict(list(bad_blocks.items())[:30]),
               "maximum_errors": maximum, "errors": errors[:30]},
              "Every included date has six ordered unique four-hour groups; required dates are present; charge/discharge equal full-precision sums rendered to four decimals.",
              f"{path}:充放电量", "Four-hour summaries are required outputs and must reconcile to the same detail.")
    wb.close()


def legacy_snapshot(audit: Audit, legacy_dir: Path, out_dir: Path, source_root: Path, project_root: Path, cfg: AuditConfig) -> None:
    sources = ("audit_summary.json", "rolling_audit_summary.json")
    payload: dict[str, Any] = {"note": "Immutable snapshot of legacy statuses; final results do not overwrite or clear these findings.", "sources": []}
    missing = []
    status_counts: Counter[str] = Counter()
    nonpass: list[str] = []
    for name in sources:
        path = legacy_dir / name
        if not path.is_file():
            missing.append(name)
            continue
        source = json.loads(path.read_text(encoding="utf-8"))
        checks = source.get("checks", [])
        status_counts.update(check.get("status", "UNKNOWN") for check in checks)
        nonpass.extend(check.get("id", "UNKNOWN") for check in checks if check.get("status") != "PASS")
        payload["sources"].append({"path": str(path), "sha256": sha256(path), "status_counts": source.get("status_counts", {}), "checks": checks})
    payload["status_counts"] = dict(status_counts)
    payload["nonpass_check_ids"] = nonpass
    payload["missing_sources"] = missing
    # The v1 audit compared emergency totals only.  Preserve the stricter
    # retrospective findings separately so a new PASS cannot conceal them.
    supplemental = Audit()
    for filename in ("result3.xlsx", "result4-3.xlsx"):
        workbook_path = source_root / filename
        if not workbook_path.is_file():
            continue
        detail = load_xlsx_detail(workbook_path, True)
        if detail is None:
            continue
        rows, scan = parse_detail(detail, True)
        if scan["error_count"] == 0:
            for row in rows:
                row["_source"] = str(detail.source)
            audit_emergency(supplemental, f"legacy-{filename}", workbook_path, rows, cfg, out_dir)
    payload["supplemental_exact_emergency_checks"] = [asdict(check) for check in supplemental.checks]
    safe_payload = sanitize_output(payload, project_root, source_root)
    (out_dir / "legacy_audit_snapshot.json").write_text(json.dumps(safe_payload, ensure_ascii=False, indent=2), encoding="utf-8")
    audit.add("LEGACY-AUDIT-PRESERVED", "PASS" if not missing else "FAIL", "high", "outputs/c_audit_v1",
              {"source_files": len(payload["sources"]), "missing": missing, "status_counts": dict(status_counts),
               "nonpass_count": len(nonpass)},
              "Legacy checks and all non-PASS statuses are copied verbatim with source hashes.",
              str(out_dir / "legacy_audit_snapshot.json"), "New passes must not erase historical failures or unverifiable claims.")


def find_workbook(results_dir: Path, name: str) -> Path | None:
    direct = results_dir / name
    if direct.is_file():
        return direct
    matches = [path for path in results_dir.rglob(name) if "audit" not in path.parts] if results_dir.exists() else []
    return sorted(matches, key=lambda p: len(str(p)))[0] if matches else None


def audit_results(audit: Audit, results_dir: Path, template_dir: Path, input_dir: Path, cfg: AuditConfig, out_dir: Path) -> None:
    for name in RESULT_NAMES:
        path = find_workbook(results_dir, name)
        if path is None:
            audit.add(f"FINAL-{name}", "PENDING", "critical", name, {"exists": False},
                      "Formal result workbook exists; rerun the same audit after generation.", str(results_dir),
                      "Stage report only; final delivery gate is not yet evaluated.")
            continue
        template = template_dir / name
        audit_schema(audit, path, template, f"FINAL-{name}")
        formula_errors = workbook_formula_errors(path)
        audit.add(f"FINAL-{name}-FORMULA-ERRORS", "PASS" if formula_errors["error_count"] == 0 else "FAIL", "critical", name,
                  formula_errors, "No formula-error cells in formula or cached-value views.", str(path),
                  "Formula errors can be hidden by displayed totals.")
        audit_plan_sheet(audit, name, path, template)
        if name == "result1.xlsx":
            detail = locate_detail(results_dir, path, False)
            if detail is None:
                audit.add("FINAL-result1.xlsx-DETAIL", "FAIL", "critical", name, {"found": False},
                          "Full-precision Q1 dispatch detail exists.", str(results_dir),
                          "Q1 feasibility and official values cannot be independently traced.")
                continue
            source_ok = detail.source_kind == "full_precision_csv"
            audit.add("FINAL-result1.xlsx-DETAIL-SOURCE", "PASS" if source_ok else "FAIL", "critical", name,
                      {"source": str(detail.source), "source_kind": detail.source_kind},
                      "Independent full-precision dispatch CSV.", str(detail.source),
                      "Rounded workbook cells cannot prove LP feasibility at full precision.")
            rows, scan = parse_detail(detail, False)
            positions = [int(row["position"]) for row in rows]
            coverage_ok = scan["error_count"] == 0 and len(rows) == 144 and positions == list(range(1, 145))
            audit.add("FINAL-result1.xlsx-DETAIL-COVERAGE", "PASS" if coverage_ok else "FAIL", "critical", name,
                      {"source": str(detail.source), "scan": scan, "rows": len(rows),
                       "unique_positions": len(set(positions)), "ordered_positions": positions == list(range(1, 145))},
                      "144 valid rows with ordered unique positions 1..144.", str(detail.source),
                      "Q1 gaps invalidate feasibility and cost.")
            if coverage_ok:
                for row in rows:
                    row["date"] = MAIN_START
                audit_physics(audit, name, rows, cfg, False)
                audit_source_mapping(audit, name, rows, input_dir, cfg)
                audit_q1_values(audit, path, rows, cfg)
                audit_four_hour_sheet(audit, name, path, rows, cfg)
                audit_unadjusted_cost(audit, name, rows, cfg)
            continue
        adjusted = name in {"result3.xlsx", "result4-3.xlsx"}
        detail = locate_detail(results_dir, path, adjusted)
        if detail is None:
            audit.add(f"FINAL-{name}-DETAIL", "FAIL", "critical", name, {"found": False},
                      "Full-precision dispatch detail exists with the required unified fields.", str(results_dir),
                      "Cannot independently recompute feasibility, costs or aggregates.")
            continue
        source_ok = detail.source_kind == "full_precision_csv"
        audit.add(f"FINAL-{name}-DETAIL-SOURCE", "PASS" if source_ok else "FAIL", "critical", name,
                  {"source": str(detail.source), "source_kind": detail.source_kind},
                  "Independent full-precision dispatch CSV, not a rounded workbook-detail fallback.",
                  str(detail.source), "Rounded cells cannot authenticate full-precision interval grouping or costs.")
        rows, scan = parse_detail(detail, adjusted)
        for row in rows:
            row["_source"] = str(detail.source)
        twb = load_workbook(template, data_only=True, read_only=True)
        official_labels = [str(value) for value in list(next(twb["计划购电量"].iter_rows(values_only=True)))[1:145]]
        twb.close()
        if audit_detail_coverage(audit, name, rows, scan, detail, official_labels):
            audit_dispatch_causality(audit, name, rows)
            audit_physics(audit, name, rows, cfg, adjusted)
            audit_source_mapping(audit, name, rows, input_dir, cfg)
            audit_plan_values(audit, name, path, rows, cfg)
            audit_four_hour_sheet(audit, name, path, rows, cfg)
            audit_emergency(audit, name, path, rows, cfg, out_dir)
            if adjusted:
                audit_settlement(audit, name, rows, results_dir, input_dir, cfg)
            else:
                audit_unadjusted_cost(audit, name, rows, cfg)


def write_reports(audit: Audit, out_dir: Path, config_path: Path, cfg: AuditConfig, raw_config: dict[str, str], config_parser: str,
                  source_root: Path, results_dir: Path) -> int:
    project_root = Path(__file__).resolve().parents[2]
    counts = Counter(check.status for check in audit.checks)
    final_checks = [check for check in audit.checks if check.id.startswith("FINAL-")]
    final_fail = [check.id for check in audit.checks if check.status == "FAIL"]
    final_pending = [check.id for check in final_checks if check.status == "PENDING"]
    gate = "PASS" if not final_fail and not final_pending else ("PENDING" if not final_fail else "FAIL")
    safe_checks = [sanitize_output(asdict(check), project_root, source_root) for check in audit.checks]
    payload = {
        "generated_at": datetime.now().astimezone().isoformat(),
        "audit_version": "c_final_v1-audit-1",
        "source_root": "<source_root>",
        "results_dir": sanitize_output(str(results_dir), project_root, source_root),
        "config_path": sanitize_output(str(config_path), project_root, source_root),
        "config_exists": config_path.is_file(),
        "config_parser": config_parser,
        "config_explicit_keys": sorted(raw_config),
        "effective_config": asdict(cfg),
        "emergency_display_rule": {
            "display_decimals": cfg.display_decimals,
            "threshold_kwh": cfg.emergency_display_threshold_kwh,
            "rule": "A ten-minute record is omitted only when ROUND_HALF_UP(quantity, display_decimals) equals zero; grouping occurs after this filter.",
        },
        "check_count": len(audit.checks),
        "status_counts": dict(counts),
        "formal_delivery_gate": gate,
        "formal_fail_check_ids": final_fail,
        "formal_pending_check_ids": final_pending,
        "checks": safe_checks,
    }
    (out_dir / "audit_summary.json").write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    with (out_dir / "audit_checks.csv").open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(asdict(audit.checks[0])))
        writer.writeheader()
        writer.writerows(safe_checks)
    safe_config_path = sanitize_output(str(config_path), project_root, source_root)
    safe_results_dir = sanitize_output(str(results_dir), project_root, source_root)
    safe_out_dir = sanitize_output(str(out_dir), project_root, source_root)
    lines = [
        "# C题最终独立审计报告", "", f"- 正式交付门：**{gate}**", f"- 检查数：{len(audit.checks)}",
        f"- 状态计数：`{dict(counts)}`", f"- 配置：`{safe_config_path}`（{'存在' if config_path.is_file() else '不存在，使用显式默认值'}；解析器 `{config_parser}`）",
        f"- 紧急购电显示阈值：`{cfg.emergency_display_threshold_kwh}` kWh；四位小数 `ROUND_HALF_UP` 后为 0 才省略。",
        "- 审计策略：任何必填空值、非数值、非有限值或公式错误先记 FAIL，不进入数值计算；绝不静默补零。", "",
        "## 正式结果门", "",
    ]
    for check in final_checks:
        lines.append(f"- `{check.status}` `{check.id}`：{check.scope}")
    lines.extend(["", "## 全部非 PASS 项", ""])
    nonpass = [check for check in audit.checks if check.status != "PASS"]
    if nonpass:
        for check in nonpass:
            lines.append(f"- `{check.status}` `{check.id}`（{check.severity}）：{check.impact}")
    else:
        lines.append("- 无。")
    lines.extend(["", "## 旧成果状态", "",
                  "旧审计结果逐项保存在 `legacy_audit_snapshot.json`。新版正式结果通过不会删除、覆盖或改写旧 FAIL/WARN/NOT_VERIFIABLE。该文件还保存用新版逐段规则回放旧 result3/result4-3 的补充检查；旧表的 0.0009 kWh 漏项和区间拆分继续保留为失败证据。", "",
                  "## 复跑命令", "", "```bash",
                  "python3 -m src.audit.audit_final --config config/final.yaml --results-dir outputs/c_final_v1 --output-dir outputs/c_final_v1/audit",
                  "```", ""])
    (out_dir / "audit_report.md").write_text("\n".join(lines), encoding="utf-8")
    return 0 if gate in {"PASS", "PENDING"} else 2


def parse_args(argv: Sequence[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    project = Path(__file__).resolve().parents[2]
    parser.add_argument("--source-root", type=Path, default=None,
                        help="Raw material directory; defaults to source_root in config or CUMCM_SOURCE_ROOT.")
    parser.add_argument("--results-dir", type=Path, default=project / "outputs" / "c_final_v1")
    parser.add_argument("--output-dir", type=Path, default=project / "outputs" / "c_final_v1" / "audit")
    parser.add_argument("--config", type=Path, default=project / "config" / "final.yaml")
    parser.add_argument("--legacy-dir", type=Path, default=project / "outputs" / "c_audit_v1")
    return parser.parse_args(argv)


def main(argv: Sequence[str] | None = None) -> int:
    args = parse_args(argv)
    args.output_dir.mkdir(parents=True, exist_ok=True)
    cfg, raw_config, config_parser = load_config(args.config)
    project_root = Path(__file__).resolve().parents[2]
    raw_source_root = args.source_root or raw_config.get("source_root") or os.environ.get("CUMCM_SOURCE_ROOT")
    if not raw_source_root:
        raise ValueError("未指定 source_root；请写入配置、传 --source-root 或设置 CUMCM_SOURCE_ROOT")
    source_root = Path(raw_source_root)
    if not source_root.is_absolute():
        source_root = project_root / source_root
    audit = Audit()
    derived_threshold = 0.5 * 10 ** (-cfg.display_decimals)
    threshold_ok = abs(cfg.emergency_display_threshold_kwh - derived_threshold) <= max(1e-15, derived_threshold * 1e-12)
    audit.add("CONFIG-EMERGENCY-DISPLAY-THRESHOLD", "PASS" if threshold_ok else "FAIL", "critical", "config/final.yaml",
              {"configured_kwh": cfg.emergency_display_threshold_kwh, "derived_kwh": derived_threshold,
               "display_decimals": cfg.display_decimals, "config_exists": args.config.is_file()},
              "Threshold equals half one unit in the configured display precision.", str(args.config),
              "A larger threshold may omit a visible record; a smaller threshold changes declared grouping semantics.")
    input_dir = source_root / "C题" / "附件"
    template_dir = input_dir / "附件5"
    audit_attachment_inputs(audit, input_dir)
    audit_official_templates(audit, template_dir)
    legacy_snapshot(audit, args.legacy_dir, args.output_dir, source_root, project_root, cfg)
    audit_results(audit, args.results_dir, template_dir, input_dir, cfg, args.output_dir)
    code = write_reports(audit, args.output_dir, args.config, cfg, raw_config, config_parser, source_root, args.results_dir)
    print(json.dumps({"status_counts": dict(Counter(check.status for check in audit.checks)),
                      "formal_delivery_gate": "FAIL" if code else ("PENDING" if any(check.status == "PENDING" for check in audit.checks if check.id.startswith("FINAL-")) else "PASS"),
                      "output_dir": str(args.output_dir),
                      "emergency_display_threshold_kwh": cfg.emergency_display_threshold_kwh}, ensure_ascii=False))
    return code


if __name__ == "__main__":
    raise SystemExit(main())
