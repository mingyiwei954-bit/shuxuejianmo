# C题因果滚动模型

本目录是从官方附件独立重建的模型核心，不读取 `outputs/c_audit_v1`。

## 运行

```bash
PYTHONPATH="work/python_deps:." \
  /path/to/python scripts/run_model.py --config config/final.yaml --scope official
```

也可设置 `CUMCM_SOURCE_ROOT` 覆盖配置中的相对原始资料路径。正式单一入口为：

```bash
CUMCM_SOURCE_ROOT=/path/to/CUMCM2026Problems \
  bash run_pipeline.sh --config config/final.yaml
```

流水线先用 `--scope official` 生成五份正式调度明细，再用
`--scope pre-parallel` 并行完成六组消融、S0–S3、月度统计和 7 天移动块区间，
最后用 `--scope stability` 并行完成 36 组求解器/并列破除复算。
稳定性汇总分别检查主结算和逐次交易敏感性结算的 S3-S2 方向与分币一致性；
冻结主结论采用前者，后者作为证据保留。
`--scope all --skip-stability` 只保留用于开发检查，不属于正式完整运行。

## 决策语义

- 每个附件时间戳按右端点解释，官方模板标签原样保存在 `official_label`。
- 负载与波动价格仅使用决策日前最近四个同星期日；实际量只进入执行后结算。
- 0/6/12/18 时优化未来24小时。场景模型仅执行到下一决策点；后续场景递补不形成承诺。
- 0:00 场景模型决定首个可执行块，确定性因果解补全当天正式基础计划。
- 光伏点预测和残差场景均截断在非负值与“过去60天对应小时全部10分钟实测值”的99.5%分位数之间。
- LP 解中的等效同时充放电会转换为保持 SOC 变化和能量平衡的单向流，多出的效率损耗转为未用能量；其中光伏弃电与非光伏未用能量分别保存，冻结结果不含同时充放电。
- 日内主结算相对0:00基础计划。逐次结算是敏感性口径：在每个校正点，用同一校正后点预测的确定性解更新当天剩余假设承诺，再相对上一版本逐笔计费；随机模型仅决定下一个执行块，任何随机场景分支都不冒充未来正式承诺。两种口径并行保存在 `final_relative_cost_yuan` 和 `sequential_cost_yuan`。
- 2月1日从6000 kWh开始，12月31日强制回到6000 kWh。终端方案和软目标系数只用1月验证。

## 冻结接口

`outputs/c_final_v1/frozen/` 包含五个 `*_dispatch.csv`、分题和合并的
`decision_versions.csv`、`time_index.csv`、汇总、解析后的配置和 SHA-256 清单。
完整跨日预览另存 `target_date` 与 `preview_grid_kwh`，四个承诺字段保持为空；
因此预览能够影响当前储能决策，但不会被误记为次日正式承诺。
正式工作簿、图和论文应只读取这些冻结文件。
