from __future__ import annotations

import argparse
import json
from pathlib import Path

from .config import load_config
from .data import load_data
from .experiments import run_and_write_all, run_and_write_official, run_stability_parallel, run_pre_stability_parallel


def main() -> int:
    ap=argparse.ArgumentParser(description="Rebuild the C-problem causal rolling model from official attachments")
    ap.add_argument("--config",default="config/final.yaml")
    ap.add_argument("--skip-stability",action="store_true",help="skip the 36 full-year solver/tiebreak sensitivity runs")
    ap.add_argument("--scope",choices=("official","all","pre-parallel","stability"),default="all")
    args=ap.parse_args()
    cfg=load_config(args.config); data=load_data(cfg)
    if args.scope=="official": summary=run_and_write_official(data,cfg)
    elif args.scope=="pre-parallel":
        pre=run_pre_stability_parallel(data,cfg); summary={"results":pre["experiments"],"stability":[]}
    elif args.scope=="stability":
        stability=run_stability_parallel(data,cfg); summary={"results":[],"stability":stability}
    else: summary=run_and_write_all(data,cfg,include_stability=not args.skip_stability)
    print(json.dumps({"status":"ok","scope":args.scope,"output_root":cfg["_output_root"],"results":len(summary["results"]),"stability_runs":len(summary.get("stability",[]))},ensure_ascii=False))
    return 0


if __name__=="__main__": raise SystemExit(main())
