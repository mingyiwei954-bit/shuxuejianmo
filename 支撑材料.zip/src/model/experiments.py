from __future__ import annotations

import csv
from concurrent.futures import ProcessPoolExecutor, as_completed
from dataclasses import asdict
from datetime import date, timedelta
import hashlib
import json
from pathlib import Path
import platform
import sys
from typing import Any, Iterable

import numpy as np
import scipy

from .data import DataBundle
from .forecast import profile_horizon
from .lp import solve_deterministic
from .rolling import RunSpec, simulate, _solve


def _write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True,exist_ok=True)
    if not rows: raise ValueError(f"refusing to write empty CSV {path}")
    with path.open("w",newline="",encoding="utf-8-sig") as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)


def _sha256(path: Path) -> str:
    h=hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda:f.read(1<<20),b""): h.update(block)
    return h.hexdigest()


def solve_q1(data: DataBundle, cfg: dict[str, Any]) -> list[dict[str, Any]]:
    dt=float(cfg["storage"]["interval_minutes"])/60; soc0=float(cfg["study"]["initial_soc_kwh"])
    sol=solve_deterministic(data.q1_load_kw*dt,data.q1_pv_kw*dt,data.fixed_price,soc0,np.full(144,np.nan),
                            "force_target",float(cfg["study"]["terminal_soc_kwh"]),0.0,cfg)
    starts=np.r_[soc0,sol.soc_end[:-1]]; rows=[]
    for j in range(144):
        cost=data.fixed_price[j]*sol.grid[j]
        curtail_pv=min(float(sol.curtail[j]),float(data.q1_pv_kw[j]*dt)); planned_unused_nonpv=max(float(sol.curtail[j])-float(data.q1_pv_kw[j]*dt),0.0)
        rows.append({
            "date":"2025-01-01","position":j+1,"source_timestamp":data.source_timestamps[j],
            "physical_interval":f"{j*10//60:02d}:{j*10%60:02d}-{(j+1)*10//60:02d}:{(j+1)*10%60:02d}","official_label":data.official_labels[j],
            "plan_00_grid_kwh":float(sol.grid[j]),"final_adjusted_grid_kwh":float(sol.grid[j]),"adjustment_kwh":0.0,
            "charge_kwh":float(sol.charge[j]),"discharge_kwh":float(sol.discharge[j]),"soc_start_kwh":float(starts[j]),
            "soc_end_kwh":float(sol.soc_end[j]),"curtail_pv_kwh":curtail_pv,"planned_unused_nonpv_kwh":planned_unused_nonpv,
            "forecast_load_kwh":float(data.q1_load_kw[j]*dt),"forecast_pv_kwh":float(data.q1_pv_kw[j]*dt),
            "actual_load_kwh":float(data.q1_load_kw[j]*dt),"actual_pv_kwh":float(data.q1_pv_kw[j]*dt),
            "forecast_price":float(data.fixed_price[j]),"settlement_price":float(data.fixed_price[j]),
            "emergency_kwh":0.0,"unused_surplus_kwh":0.0,"plan_cost_yuan":float(cost),"adjustment_cost_yuan":0.0,
            "emergency_cost_yuan":0.0,"final_relative_cost_yuan":float(cost),"sequential_cost_yuan":float(cost),
            "decision_hour":0,"history_cutoff_date":"","model_arm":"deterministic_q1","scenario":"Q1",
        })
    return rows


def perfect_information_controls(data:DataBundle,cfg:dict[str,Any]) -> list[dict[str,Any]]:
    """Fair Feb-Dec lower bounds with the same 6000 -> 6000 endpoints."""
    start=date.fromisoformat(cfg["study"]["official_start"]); i0=data.date_index[start]
    dt=float(cfg["storage"]["interval_minutes"])/60; n=(len(data.dates)-i0)*144
    load=data.load_kw[i0:].reshape(-1)*dt; pv=data.pv_kw[i0:].reshape(-1)*dt
    fixed=np.tile(data.fixed_price,len(data.dates)-i0); rt=data.realtime_price[i0:].reshape(-1)
    out=[]
    for mode,price in (("q2",fixed),("q4_2",rt)):
        sol=solve_deterministic(load,pv,price,float(cfg["study"]["initial_soc_kwh"]),np.full(n,np.nan),
                                "force_target",float(cfg["study"]["terminal_soc_kwh"]),0.0,cfg)
        out.append({"mode":mode,"information":"perfect_information_lower_bound","days":len(data.dates)-i0,
                    "initial_soc_kwh":float(cfg["study"]["initial_soc_kwh"]),"terminal_soc_kwh":float(sol.soc_end[-1]),
                    "purchase_cost_yuan":float(np.dot(price,sol.grid)),"grid_kwh":float(sol.grid.sum()),
                    "solver_seconds":sol.elapsed_seconds,"max_balance_residual_kwh":sol.max_balance_residual,
                    "max_soc_residual_kwh":sol.max_soc_residual})
    return out


def simulate_day_ahead(data: DataBundle,cfg: dict[str,Any],mode:str,method:str="highs",tiebreak:float|None=None) -> dict[str,Any]:
    if mode not in {"q2","q4_2"}: raise ValueError(mode)
    start=date.fromisoformat(cfg["study"]["official_start"]); end=date.fromisoformat(cfg["study"]["official_end"])
    dt=float(cfg["storage"]["interval_minutes"])/60; eta=float(cfg["storage"]["charge_efficiency"])
    soc=float(cfg["study"]["initial_soc_kwh"]); target=float(cfg["study"]["terminal_soc_kwh"]); count=int(cfg["forecast"]["same_weekday_profiles"])
    rows=[]; daily=[]; stats=[]
    for day in [d for d in data.dates if start<=d<=end]:
        di=data.date_index[day]; gi=di*144; soc0=soc
        load,hload=profile_horizon(data,gi,144,day,"load",count); pv,hpv=profile_horizon(data,gi,144,day,"pv",count)
        if mode=="q4_2": price,hprice=profile_horizon(data,gi,144,day,"price",count); actual_price=data.realtime_price[di]
        else: price=data.fixed_price; hprice=[]; actual_price=data.fixed_price
        terminal="force_target" if day==end else str(cfg["rolling"]["selected_terminal_rule"])
        penalty=float(np.median(price))*float(cfg["rolling"]["selected_soft_penalty_multiplier"])
        sol=solve_deterministic(load*dt,pv*dt,price,soc,np.full(144,np.nan),terminal,target,penalty,cfg,method,tiebreak)
        starts=np.r_[soc,sol.soc_end[:-1]]; soc=float(sol.soc_end[-1])
        actual_load=data.load_kw[di]*dt; actual_pv=data.pv_kw[di]*dt
        net=sol.grid+actual_pv+sol.discharge-actual_load-sol.charge
        emergency=np.maximum(-net,0); unused=np.maximum(net,0)
        plan_cost=actual_price*sol.grid; emergency_cost=float(cfg["cost"]["emergency_multiplier"])*actual_price*emergency; total=plan_cost+emergency_cost
        hist_dates=sorted(set(hload+hpv+hprice)); hist="|".join(x.isoformat() for x in hist_dates)
        for j in range(144):
            curtail_pv=min(float(sol.curtail[j]),float(pv[j]*dt)); planned_unused_nonpv=max(float(sol.curtail[j])-float(pv[j]*dt),0.0)
            rows.append({
                "date":day.isoformat(),"position":j+1,"source_timestamp":data.source_timestamps[j],
                "physical_interval":f"{j*10//60:02d}:{j*10%60:02d}-{(j+1)*10//60:02d}:{(j+1)*10%60:02d}","official_label":data.official_labels[j],
                "plan_00_grid_kwh":float(sol.grid[j]),"final_adjusted_grid_kwh":float(sol.grid[j]),"adjustment_kwh":0.0,
                "charge_kwh":float(sol.charge[j]),"discharge_kwh":float(sol.discharge[j]),"soc_start_kwh":float(starts[j]),"soc_end_kwh":float(sol.soc_end[j]),
                "curtail_pv_kwh":curtail_pv,"planned_unused_nonpv_kwh":planned_unused_nonpv,"forecast_load_kwh":float(load[j]*dt),"forecast_pv_kwh":float(pv[j]*dt),
                "actual_load_kwh":float(actual_load[j]),"actual_pv_kwh":float(actual_pv[j]),"forecast_price":float(price[j]),"settlement_price":float(actual_price[j]),
                "emergency_kwh":float(emergency[j]),"unused_surplus_kwh":float(unused[j]),"plan_cost_yuan":float(plan_cost[j]),
                "adjustment_cost_yuan":0.0,"emergency_cost_yuan":float(emergency_cost[j]),"final_relative_cost_yuan":float(total[j]),
                "sequential_cost_yuan":float(total[j]),"decision_hour":0,"history_cutoff_date":(day-timedelta(days=1)).isoformat(),
                "model_arm":"causal_day_ahead","scenario":mode.upper(),
            })
        daily.append({"date":day.isoformat(),"mode":mode,"start_soc_kwh":soc0,"end_soc_kwh":soc,
                      "plan_cost_yuan":float(plan_cost.sum()),"emergency_cost_yuan":float(emergency_cost.sum()),
                      "final_relative_cost_yuan":float(total.sum()),"sequential_cost_yuan":float(total.sum()),
                      "emergency_kwh":float(emergency.sum()),"unused_surplus_kwh":float(unused.sum())})
        stats.append(sol)
    return {"dispatch":rows,"daily":daily,"summary":{
        "mode":mode,"scenario":mode.upper(),"model_arm":"causal_day_ahead","days":len(daily),
        "initial_soc_kwh":daily[0]["start_soc_kwh"],"terminal_soc_kwh":daily[-1]["end_soc_kwh"],
        "plan_cost_yuan":sum(x["plan_cost_yuan"] for x in daily),"adjustment_cost_yuan":0.0,
        "emergency_cost_yuan":sum(x["emergency_cost_yuan"] for x in daily),"final_relative_cost_yuan":sum(x["final_relative_cost_yuan"] for x in daily),
        "sequential_cost_yuan":sum(x["sequential_cost_yuan"] for x in daily),"emergency_kwh":sum(x["emergency_kwh"] for x in daily),
        "unused_surplus_kwh":sum(x["unused_surplus_kwh"] for x in daily),"solver_seconds":sum(x.elapsed_seconds for x in stats),"solver_runs":len(stats),
        "max_balance_residual_kwh":max(x.max_balance_residual for x in stats),"max_soc_residual_kwh":max(x.max_soc_residual for x in stats),
        "constraint_violation_count":int(sum(x.max_balance_residual>float(cfg["audit"]["feasibility_tolerance"]) or x.max_soc_residual>float(cfg["audit"]["feasibility_tolerance"]) for x in stats))}}


def select_terminal_rule(data:DataBundle,cfg:dict[str,Any]) -> list[dict[str,Any]]:
    original_rule=cfg["rolling"]["selected_terminal_rule"]; original_mult=cfg["rolling"]["selected_soft_penalty_multiplier"]
    rows=[]; start=date(2025,1,8); end=date(2025,1,31)
    try:
        for rule in cfg["rolling"]["terminal_candidates"]:
            multipliers=cfg["rolling"]["soft_penalty_multipliers"] if rule=="soft_target" else [None]
            for mult in multipliers:
                cfg["rolling"]["selected_terminal_rule"]=rule
                if mult is not None: cfg["rolling"]["selected_soft_penalty_multiplier"]=mult
                arm="raw_baseline" if rule=="daily_closed" else "crossday_only"
                cost=0.0; emergency=0.0
                for mode in ("q3","q4_3"):
                    r=simulate(data,cfg,RunSpec(mode,"S3",arm,start_date=start,end_date=end))
                    cost+=r["summary"]["final_relative_cost_yuan"]; emergency+=r["summary"]["emergency_kwh"]
                rows.append({"terminal_rule":rule,"soft_penalty_multiplier":"" if mult is None else mult,
                             "validation_start":start.isoformat(),"validation_end":end.isoformat(),"combined_cost_yuan":cost,"combined_emergency_kwh":emergency})
    finally:
        cfg["rolling"]["selected_terminal_rule"]=original_rule; cfg["rolling"]["selected_soft_penalty_multiplier"]=original_mult
    return rows


def moving_block_ci(differences:np.ndarray,block:int,reps:int,seed:int) -> tuple[float,float]:
    x=np.asarray(differences,float); n=len(x); rng=np.random.default_rng(seed)
    starts=np.arange(max(1,n-block+1)); vals=np.empty(reps)
    for r in range(reps):
        sample=[]
        while len(sample)<n:
            s=int(rng.choice(starts)); sample.extend(x[s:min(s+block,n)])
        vals[r]=np.mean(sample[:n])*n
    return float(np.quantile(vals,.025)),float(np.quantile(vals,.975))


def run_and_write_all(data:DataBundle,cfg:dict[str,Any],include_stability:bool=True) -> dict[str,Any]:
    root=Path(cfg["_output_root"]); frozen=root/"frozen"; evidence=root/"evidence"; frozen.mkdir(parents=True,exist_ok=True); evidence.mkdir(parents=True,exist_ok=True)
    _write_csv(frozen/"time_index.csv",data.time_rows())
    q1=solve_q1(data,cfg); _write_csv(frozen/"q1_dispatch.csv",q1)
    validation=select_terminal_rule(data,cfg); _write_csv(evidence/"terminal_validation.csv",validation)
    selected=min(validation,key=lambda x:x["combined_cost_yuan"])
    cfg["rolling"]["selected_terminal_rule"]=selected["terminal_rule"]
    if selected["soft_penalty_multiplier"]!="": cfg["rolling"]["selected_soft_penalty_multiplier"]=float(selected["soft_penalty_multiplier"])
    resolved={k:v for k,v in cfg.items() if not k.startswith("_")}
    (frozen/"resolved_config.json").write_text(json.dumps(resolved,ensure_ascii=False,indent=2),encoding="utf-8")
    perfect=perfect_information_controls(data,cfg); _write_csv(frozen/"perfect_information_summary.csv",perfect)
    q2=simulate_day_ahead(data,cfg,"q2"); q42=simulate_day_ahead(data,cfg,"q4_2")
    _write_csv(frozen/"q2_dispatch.csv",q2["dispatch"]); _write_csv(frozen/"q4_2_dispatch.csv",q42["dispatch"])
    exp=[]; daily_by:dict[tuple[str,str],list[dict[str,Any]]]={}; exp_results:dict[tuple[str,str],dict[str,Any]]={}
    for mode in ("q3","q4_3"):
        for arm in cfg["experiments"]["arms"]:
            detail=arm==cfg["experiments"]["official_arm"]
            result=simulate(data,cfg,RunSpec(mode,"S3",arm,collect_detail=detail)); exp.append(result["summary"]); daily_by[(mode,arm)]=result["daily"]; exp_results[(mode,arm)]=result
            print(json.dumps({"stage":"ablation","mode":mode,"arm":arm,"cost":result["summary"]["final_relative_cost_yuan"]},ensure_ascii=False),flush=True)
    official={}
    for mode in ("q3","q4_3"):
        for scenario in cfg["experiments"]["schedules"]:
            if scenario==cfg["experiments"]["official_scenario"]:
                result=exp_results[(mode,cfg["experiments"]["official_arm"])]
            else:
                result=simulate(data,cfg,RunSpec(mode,scenario,cfg["experiments"]["official_arm"],collect_detail=False))
            official[(mode,scenario)]=result
            print(json.dumps({"stage":"schedule","mode":mode,"scenario":scenario,"cost":result["summary"]["final_relative_cost_yuan"]},ensure_ascii=False),flush=True)
        key=(mode,cfg["experiments"]["official_scenario"]); path="q3_dispatch.csv" if mode=="q3" else "q4_3_dispatch.csv"
        _write_csv(frozen/path,official[key]["dispatch"])
    q3_versions=official[("q3",cfg["experiments"]["official_scenario"])]["decision_versions"]
    q43_versions=official[("q4_3",cfg["experiments"]["official_scenario"])]["decision_versions"]
    _write_csv(frozen/"q3_decision_versions.csv",q3_versions); _write_csv(frozen/"q4_3_decision_versions.csv",q43_versions)
    _write_csv(frozen/"decision_versions.csv",q3_versions+q43_versions)
    experiment_rows=exp+[official[k]["summary"] for k in official if k[1]!=cfg["experiments"]["official_scenario"]]
    _write_csv(frozen/"experiment_summary.csv",experiment_rows)
    monthly=[]
    for mode in ("q3","q4_3"):
        base={x["date"]:x for x in daily_by[(mode,"raw_baseline")]}; combo=official[(mode,"S3")]["daily"]
        for month in range(2,13):
            br=[base[x["date"]] for x in combo if int(x["date"][5:7])==month]; cr=[x for x in combo if int(x["date"][5:7])==month]
            dif=np.asarray([c["final_relative_cost_yuan"]-b["final_relative_cost_yuan"] for b,c in zip(br,cr)])
            lo,hi=moving_block_ci(dif,int(cfg["experiments"]["moving_block_days"]),int(cfg["experiments"]["bootstrap_replicates"]),int(cfg["experiments"]["bootstrap_seed"])+month)
            monthly.append({"mode":mode,"month":month,"days":len(dif),"baseline_cost_yuan":sum(x["final_relative_cost_yuan"] for x in br),
                            "combination_cost_yuan":sum(x["final_relative_cost_yuan"] for x in cr),"difference_yuan":float(dif.sum()),"block_bootstrap_95_low_yuan":lo,"block_bootstrap_95_high_yuan":hi})
    _write_csv(frozen/"monthly_effects.csv",monthly)
    comparison=[]; monthly_schedules=[]
    for mode in ("q3","q4_3"):
        for scenario in cfg["experiments"]["schedules"]:
            schedule=official[(mode,scenario)]["daily"]
            for month in range(2,13):
                selected=[r for r in schedule if int(r["date"][5:7])==month]
                monthly_schedules.append({"mode":mode,"scenario":scenario,"month":month,"days":len(selected),
                                          "final_relative_cost_yuan":sum(r["final_relative_cost_yuan"] for r in selected),
                                          "sequential_cost_yuan":sum(r["sequential_cost_yuan"] for r in selected),
                                          "emergency_kwh":sum(r["emergency_kwh"] for r in selected),
                                          "unused_surplus_kwh":sum(r["unused_surplus_kwh"] for r in selected),
                                          "month_end_soc_kwh":selected[-1]["end_soc_kwh"]})
        s2=official[(mode,"S2")]["daily"]; s3=official[(mode,"S3")]["daily"]
        dif=np.asarray([b["final_relative_cost_yuan"]-a["final_relative_cost_yuan"] for a,b in zip(s2,s3)])
        lo,hi=moving_block_ci(dif,int(cfg["experiments"]["moving_block_days"]),int(cfg["experiments"]["bootstrap_replicates"]),int(cfg["experiments"]["bootstrap_seed"])+100)
        cents=0.005
        comparison.append({"mode":mode,"comparison":"S3_minus_S2_final_relative","days":len(dif),"point_difference_yuan":float(dif.sum()),
                           "block_ci_low_yuan":lo,"block_ci_high_yuan":hi,"positive_days":int(np.sum(dif>cents)),
                           "negative_days":int(np.sum(dif<-cents)),"zero_days":int(np.sum(np.abs(dif)<=cents))})
        ds=np.asarray([b["sequential_cost_yuan"]-a["sequential_cost_yuan"] for a,b in zip(s2,s3)])
        lo,hi=moving_block_ci(ds,int(cfg["experiments"]["moving_block_days"]),int(cfg["experiments"]["bootstrap_replicates"]),int(cfg["experiments"]["bootstrap_seed"])+101)
        comparison.append({"mode":mode,"comparison":"S3_minus_S2_sequential","days":len(ds),"point_difference_yuan":float(ds.sum()),
                           "block_ci_low_yuan":lo,"block_ci_high_yuan":hi,"positive_days":int(np.sum(ds>cents)),
                           "negative_days":int(np.sum(ds<-cents)),"zero_days":int(np.sum(np.abs(ds)<=cents))})
    _write_csv(frozen/"comparison_stats.csv",comparison); _write_csv(frozen/"monthly_schedules.csv",monthly_schedules)
    stability=[]
    if include_stability:
        for mode in ("q3","q4_3"):
            for scenario in ("S2","S3"):
                for method in cfg["experiments"]["solver_methods"]:
                    for tb in cfg["experiments"]["tiebreak_coefficients"]:
                        if method=="highs" and float(tb)==float(cfg["cost"]["throughput_tiebreak_yuan_per_kwh"]):
                            r=official[(mode,scenario)]
                        else:
                            r=simulate(data,cfg,RunSpec(mode,scenario,cfg["experiments"]["official_arm"],method,float(tb),collect_detail=False))
                        stability.append({**r["summary"],"solver_method":method,"tiebreak":tb})
                        print(json.dumps({"stage":"stability","mode":mode,"scenario":scenario,"method":method,"tiebreak":tb,"cost":r["summary"]["final_relative_cost_yuan"]},ensure_ascii=False),flush=True)
        _write_csv(frozen/"stability_summary.csv",stability)
        assessment=[]
        for mode in ("q3","q4_3"):
            by={(r["solver_method"],float(r["tiebreak"]),r["scenario"]):r for r in stability if r["mode"]==mode}
            for metric,settlement in (("final_relative_cost_yuan","final_relative_to_00_plan"),
                                      ("sequential_cost_yuan","sequential_sensitivity")):
                dif=[]
                for method in cfg["experiments"]["solver_methods"]:
                    for tb in cfg["experiments"]["tiebreak_coefficients"]:
                        dif.append(by[(method,float(tb),"S3")][metric]-by[(method,float(tb),"S2")][metric])
                signs={0 if abs(x)<.005 else (1 if x>0 else -1) for x in dif}; cents={round(x,2) for x in dif}
                stable=len(signs)==1 and 0 not in signs and len(cents)==1
                assessment.append({"mode":mode,"settlement":settlement,"comparison":"S3_minus_S2","replicates":len(dif),
                                   "difference_min_yuan":min(dif),"difference_max_yuan":max(dif),
                                   "rounded_cent_values":"|".join(str(x) for x in sorted(cents)),"direction_values":"|".join(str(x) for x in sorted(signs)),
                                   "conclusion":"stable" if stable else "numerically_indistinguishable"})
        _write_csv(frozen/"stability_assessment.csv",assessment)
    summaries=[q2["summary"],q42["summary"]]+experiment_rows
    summary={"generated_at":__import__("datetime").datetime.now().astimezone().isoformat(),"config":"config/final.yaml",
             "environment":{"python":sys.version,"platform":platform.platform(),"numpy":np.__version__,"scipy":scipy.__version__},
             "causality":"Every historical reference is strictly before the decision date; actual values enter only realized settlement.",
             "terminal_validation":validation,"selected_terminal":selected,"perfect_information_controls":perfect,"results":summaries,"stability":stability}
    (frozen/"model_run_summary.json").write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding="utf-8")
    files=sorted(p for p in frozen.iterdir() if p.is_file() and p.name!="frozen_manifest.json")
    manifest={"schema_version":cfg["schema_version"],"generated_at":summary["generated_at"],"source_root":cfg["source_root"],
              "command":"./run_pipeline.sh --config config/final.yaml","files":[{"path":p.name,"bytes":p.stat().st_size,"sha256":_sha256(p)} for p in files]}
    (frozen/"frozen_manifest.json").write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding="utf-8")
    return summary


def run_and_write_official(data:DataBundle,cfg:dict[str,Any]) -> dict[str,Any]:
    """Build only the five frozen dispatches and their shared decision ledger."""
    root=Path(cfg["_output_root"]); frozen=root/"frozen"; evidence=root/"evidence"; frozen.mkdir(parents=True,exist_ok=True); evidence.mkdir(parents=True,exist_ok=True)
    _write_csv(frozen/"time_index.csv",data.time_rows())
    _write_csv(frozen/"q1_dispatch.csv",solve_q1(data,cfg))
    validation=select_terminal_rule(data,cfg); _write_csv(evidence/"terminal_validation.csv",validation)
    selected=min(validation,key=lambda x:x["combined_cost_yuan"])
    cfg["rolling"]["selected_terminal_rule"]=selected["terminal_rule"]
    if selected["soft_penalty_multiplier"]!="": cfg["rolling"]["selected_soft_penalty_multiplier"]=float(selected["soft_penalty_multiplier"])
    resolved={k:v for k,v in cfg.items() if not k.startswith("_")}
    (frozen/"resolved_config.json").write_text(json.dumps(resolved,ensure_ascii=False,indent=2),encoding="utf-8")
    perfect=perfect_information_controls(data,cfg); _write_csv(frozen/"perfect_information_summary.csv",perfect)
    q2=simulate_day_ahead(data,cfg,"q2"); q42=simulate_day_ahead(data,cfg,"q4_2")
    q3=simulate(data,cfg,RunSpec("q3",cfg["experiments"]["official_scenario"],cfg["experiments"]["official_arm"]))
    q43=simulate(data,cfg,RunSpec("q4_3",cfg["experiments"]["official_scenario"],cfg["experiments"]["official_arm"]))
    _write_csv(frozen/"q2_dispatch.csv",q2["dispatch"]); _write_csv(frozen/"q4_2_dispatch.csv",q42["dispatch"])
    _write_csv(frozen/"q3_dispatch.csv",q3["dispatch"]); _write_csv(frozen/"q4_3_dispatch.csv",q43["dispatch"])
    _write_csv(frozen/"q3_decision_versions.csv",q3["decision_versions"]); _write_csv(frozen/"q4_3_decision_versions.csv",q43["decision_versions"])
    _write_csv(frozen/"decision_versions.csv",q3["decision_versions"]+q43["decision_versions"])
    summaries=[q2["summary"],q3["summary"],q42["summary"],q43["summary"]]
    _write_csv(frozen/"official_summary.csv",summaries)
    summary={"generated_at":__import__("datetime").datetime.now().astimezone().isoformat(),"config":"config/final.yaml",
             "environment":{"python":sys.version,"platform":platform.platform(),"numpy":np.__version__,"scipy":scipy.__version__},
             "causality":"Every historical reference is strictly before the decision date; actual values enter only realized settlement.",
             "terminal_validation":validation,"selected_terminal":selected,"perfect_information_controls":perfect,"results":summaries}
    (frozen/"model_run_summary.json").write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding="utf-8")
    schemas={
        "time_index":["date","position","global_position","source_timestamp","physical_interval","official_label"],
        "decision_version":["date","target_date","mode","scenario","model_arm","decision_time","forecast_issue_time","effective_start","effective_end","history_cutoff_date","position","physical_interval","official_label","old_commitment_kwh","new_commitment_kwh","sensitivity_old_commitment_kwh","sensitivity_new_commitment_kwh","preview_grid_kwh","decision_basis","soc_at_decision_kwh","load_history_dates","price_history_dates","pv_bias_history_dates","residual_scenario_dates","is_preview_next_day","is_preview_recourse"],
        "dispatch_detail":list(q3["dispatch"][0]),
    }
    (frozen/"schemas.json").write_text(json.dumps(schemas,ensure_ascii=False,indent=2),encoding="utf-8")
    files=sorted(p for p in frozen.iterdir() if p.is_file() and p.name!="frozen_manifest.json")
    manifest={"schema_version":cfg["schema_version"],"generated_at":summary["generated_at"],"source_root":cfg["source_root"],
              "command":"./run_pipeline.sh --config config/final.yaml","files":[{"path":p.name,"bytes":p.stat().st_size,"sha256":_sha256(p)} for p in files]}
    (frozen/"frozen_manifest.json").write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding="utf-8")
    return summary


def finalize_existing_official(data:DataBundle,cfg:dict[str,Any]) -> dict[str,Any]:
    """Refresh portable metadata and perfect-information controls without rerunning rolling LPs."""
    frozen=Path(cfg["_output_root"])/"frozen"
    summary_path=frozen/"model_run_summary.json"
    if not summary_path.is_file(): raise FileNotFoundError(summary_path)
    summary=json.loads(summary_path.read_text(encoding="utf-8"))
    summary["config"]="config/final.yaml"
    perfect=perfect_information_controls(data,cfg)
    _write_csv(frozen/"perfect_information_summary.csv",perfect)
    summary["perfect_information_controls"]=perfect
    tol=float(cfg["audit"]["feasibility_tolerance"])
    for row in summary.get("results",[]):
        row["constraint_violation_count"]=int(row.get("max_balance_residual_kwh",0)>tol or row.get("max_soc_residual_kwh",0)>tol)
    resolved={k:v for k,v in cfg.items() if not k.startswith("_")}
    (frozen/"resolved_config.json").write_text(json.dumps(resolved,ensure_ascii=False,indent=2),encoding="utf-8")
    summary_path.write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding="utf-8")
    _write_csv(frozen/"official_summary.csv",summary["results"])
    files=sorted(p for p in frozen.iterdir() if p.is_file() and p.name!="frozen_manifest.json")
    manifest={"schema_version":cfg["schema_version"],"generated_at":summary["generated_at"],"source_root":cfg["source_root"],
              "command":"./run_pipeline.sh --config config/final.yaml","files":[{"path":p.name,"bytes":p.stat().st_size,"sha256":_sha256(p)} for p in files]}
    (frozen/"frozen_manifest.json").write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding="utf-8")
    return summary


def migrate_existing_unused_split(cfg:dict[str,Any]) -> None:
    """Losslessly split legacy total planned unused into PV and non-PV fields."""
    frozen=Path(cfg["_output_root"])/"frozen"
    for name in ("q1","q2","q3","q4_2","q4_3"):
        path=frozen/f"{name}_dispatch.csv"; tmp=frozen/f".{name}_dispatch.migrate.csv"
        with path.open(encoding="utf-8-sig",newline="") as src:
            reader=csv.DictReader(src); fields=list(reader.fieldnames or [])
            if "planned_unused_nonpv_kwh" in fields: continue
            insert=fields.index("curtail_pv_kwh")+1; fields.insert(insert,"planned_unused_nonpv_kwh")
            with tmp.open("w",encoding="utf-8-sig",newline="") as dst:
                writer=csv.DictWriter(dst,fieldnames=fields); writer.writeheader()
                for row in reader:
                    total=float(row["curtail_pv_kwh"]); pv=float(row["forecast_pv_kwh"])
                    row["curtail_pv_kwh"]=repr(min(total,pv)); row["planned_unused_nonpv_kwh"]=repr(max(total-pv,0.0)); writer.writerow(row)
        tmp.replace(path)
    schemas_path=frozen/"schemas.json"; schemas=json.loads(schemas_path.read_text(encoding="utf-8"))
    with (frozen/"q3_dispatch.csv").open(encoding="utf-8-sig",newline="") as f: schemas["dispatch_detail"]=next(csv.reader(f))
    schemas_path.write_text(json.dumps(schemas,ensure_ascii=False,indent=2),encoding="utf-8")
    summary=json.loads((frozen/"model_run_summary.json").read_text(encoding="utf-8"))
    files=sorted(p for p in frozen.iterdir() if p.is_file() and p.name!="frozen_manifest.json")
    manifest={"schema_version":cfg["schema_version"],"generated_at":summary["generated_at"],"source_root":cfg["source_root"],
              "command":"./run_pipeline.sh --config config/final.yaml","files":[{"path":p.name,"bytes":p.stat().st_size,"sha256":_sha256(p)} for p in files]}
    (frozen/"frozen_manifest.json").write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding="utf-8")


def backfill_full_next_day_previews(data:DataBundle,cfg:dict[str,Any]) -> None:
    """Rebuild full non-binding next-day previews using deterministic point forecasts."""
    frozen=Path(cfg["_output_root"])/"frozen"; combined=[]
    for mode in ("q3","q4_3"):
        dispatch={}
        with (frozen/f"{mode}_dispatch.csv").open(encoding="utf-8-sig",newline="") as f:
            for r in csv.DictReader(f): dispatch[(r["date"],int(r["position"]))]=r
        path=frozen/f"{mode}_decision_versions.csv"
        with path.open(encoding="utf-8-sig",newline="") as f:
            rows=list(csv.DictReader(f)); old_fields=list(rows[0])
        rows=[r for r in rows if r.get("is_preview_next_day")!="1"]
        for r in rows:
            r.setdefault("target_date",r["date"]); r.setdefault("preview_grid_kwh","")
        dates=sorted({d for d,_ in dispatch})
        for ds in dates:
            day=date.fromisoformat(ds); di=data.date_index[day]
            if di==len(data.dates)-1: continue
            baseline=np.asarray([float(dispatch[(ds,j)]["plan_00_grid_kwh"]) for j in range(1,145)])
            for issue in (6,12,18):
                pos=issue*6; length=min(144,len(data.dates)*144-(di*144+pos)); cur_len=144-pos
                b=np.r_[baseline[pos:],np.full(length-cur_len,np.nan)]
                soc=float(dispatch[(ds,pos+1)]["soc_start_kwh"])
                terminal="force_target" if di*144+pos+length==len(data.dates)*144 else str(cfg["rolling"]["selected_terminal_rule"])
                sol,_=_solve(data,cfg,day,issue,length,soc,b,True,False,terminal,36,mode,"highs",None)
                for k in range(cur_len,length):
                    target=data.dates[(di*144+pos+k)//144]; tpos=(di*144+pos+k)%144
                    rows.append({
                        "date":ds,"target_date":target.isoformat(),"mode":mode,"scenario":"S3","model_arm":"all_three",
                        "decision_time":f"{ds} {issue:02d}:00","forecast_issue_time":f"{ds} {issue:02d}:00",
                        "effective_start":f"{ds} {issue:02d}:00","effective_end":f"{(day+timedelta(days=1)).isoformat()} {issue:02d}:00",
                        "history_cutoff_date":(day-timedelta(days=1)).isoformat(),"position":tpos+1,
                        "physical_interval":f"{tpos*10//60:02d}:{tpos*10%60:02d}-{(tpos+1)*10//60:02d}:{(tpos+1)*10%60:02d}",
                        "official_label":data.official_labels[tpos],"old_commitment_kwh":"","new_commitment_kwh":"",
                        "sensitivity_old_commitment_kwh":"","sensitivity_new_commitment_kwh":"","preview_grid_kwh":float(sol.grid[k]),
                        "decision_basis":"next_day_preview","soc_at_decision_kwh":soc,"load_history_dates":"","price_history_dates":"",
                        "pv_bias_history_dates":"","residual_scenario_dates":"","is_preview_next_day":1,"is_preview_recourse":1,
                    })
        desired=["date","target_date","mode","scenario","model_arm","decision_time","forecast_issue_time","effective_start","effective_end","history_cutoff_date","position","physical_interval","official_label","old_commitment_kwh","new_commitment_kwh","sensitivity_old_commitment_kwh","sensitivity_new_commitment_kwh","preview_grid_kwh","decision_basis","soc_at_decision_kwh","load_history_dates","price_history_dates","pv_bias_history_dates","residual_scenario_dates","is_preview_next_day","is_preview_recourse"]
        rows.sort(key=lambda r:(r["date"],r["decision_time"],r["target_date"],int(r["position"])))
        with path.open("w",encoding="utf-8-sig",newline="") as f:
            w=csv.DictWriter(f,fieldnames=desired); w.writeheader(); w.writerows(rows)
        combined.extend(rows)
    _write_csv(frozen/"decision_versions.csv",combined)
    schemas_path=frozen/"schemas.json"; schemas=json.loads(schemas_path.read_text(encoding="utf-8")); schemas["decision_version"]=list(combined[0])
    schemas_path.write_text(json.dumps(schemas,ensure_ascii=False,indent=2),encoding="utf-8")
    summary=json.loads((frozen/"model_run_summary.json").read_text(encoding="utf-8"))
    files=sorted(p for p in frozen.iterdir() if p.is_file() and p.name!="frozen_manifest.json")
    manifest={"schema_version":cfg["schema_version"],"generated_at":summary["generated_at"],"source_root":cfg["source_root"],
              "command":"./run_pipeline.sh --config config/final.yaml","files":[{"path":p.name,"bytes":p.stat().st_size,"sha256":_sha256(p)} for p in files]}
    (frozen/"frozen_manifest.json").write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding="utf-8")


_WORKER_DATA:DataBundle|None=None
_WORKER_CFG:dict[str,Any]|None=None


def _init_stability_worker(data:DataBundle,cfg:dict[str,Any])->None:
    global _WORKER_DATA,_WORKER_CFG
    _WORKER_DATA=data; _WORKER_CFG=cfg


def _stability_worker(task:tuple[str,str,str,float])->dict[str,Any]:
    if _WORKER_DATA is None or _WORKER_CFG is None: raise RuntimeError("stability worker not initialized")
    mode,scenario,method,tb=task
    r=simulate(_WORKER_DATA,_WORKER_CFG,RunSpec(mode,scenario,_WORKER_CFG["experiments"]["official_arm"],method,tb,collect_detail=False))
    return {**r["summary"],"solver_method":method,"tiebreak":tb}


def run_stability_parallel(data:DataBundle,cfg:dict[str,Any])->list[dict[str,Any]]:
    """Run all 36 full-year solver/tiebreak checks in isolated worker processes."""
    tasks=[(mode,scenario,method,float(tb)) for mode in ("q3","q4_3") for scenario in ("S2","S3")
           for method in cfg["experiments"]["solver_methods"] for tb in cfg["experiments"]["tiebreak_coefficients"]]
    results=[]; workers=int(cfg["experiments"].get("stability_workers",4))
    with ProcessPoolExecutor(max_workers=workers,initializer=_init_stability_worker,initargs=(data,cfg)) as pool:
        future_map={pool.submit(_stability_worker,t):t for t in tasks}
        try:
            for fut in as_completed(future_map):
                row=fut.result(); results.append(row)
                print(json.dumps({"stage":"stability_parallel","completed":len(results),"total":len(tasks),"mode":row["mode"],
                                  "scenario":row["scenario"],"method":row["solver_method"],"tiebreak":row["tiebreak"],
                                  "cost":row["final_relative_cost_yuan"]},ensure_ascii=False),flush=True)
        except BaseException:
            for fut in future_map: fut.cancel()
            raise
    order={"q3":0,"q4_3":1}; sc={"S2":0,"S3":1}; meth={m:i for i,m in enumerate(cfg["experiments"]["solver_methods"])}
    results.sort(key=lambda r:(order[r["mode"]],sc[r["scenario"]],meth[r["solver_method"]],float(r["tiebreak"])))
    frozen=Path(cfg["_output_root"])/"frozen"; _write_csv(frozen/"stability_summary.csv",results)
    assessment=[]
    for mode in ("q3","q4_3"):
        by={(r["solver_method"],float(r["tiebreak"]),r["scenario"]):r for r in results if r["mode"]==mode}
        for metric,settlement in (("final_relative_cost_yuan","final_relative_to_00_plan"),
                                  ("sequential_cost_yuan","sequential_sensitivity")):
            dif=[]
            for method in cfg["experiments"]["solver_methods"]:
                for tb in cfg["experiments"]["tiebreak_coefficients"]:
                    dif.append(by[(method,float(tb),"S3")][metric]-by[(method,float(tb),"S2")][metric])
            signs={0 if abs(x)<.005 else (1 if x>0 else -1) for x in dif}; cents={round(x,2) for x in dif}; stable=len(signs)==1 and 0 not in signs and len(cents)==1
            assessment.append({"mode":mode,"settlement":settlement,"comparison":"S3_minus_S2","replicates":len(dif),
                               "difference_min_yuan":min(dif),"difference_max_yuan":max(dif),
                               "rounded_cent_values":"|".join(str(x) for x in sorted(cents)),"direction_values":"|".join(str(x) for x in sorted(signs)),
                               "conclusion":"stable" if stable else "numerically_indistinguishable"})
    _write_csv(frozen/"stability_assessment.csv",assessment)
    summary_path=frozen/"model_run_summary.json"; summary=json.loads(summary_path.read_text(encoding="utf-8"))
    summary["stability"]=results; summary["stability_assessment"]=assessment
    summary_path.write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding="utf-8")
    files=sorted(p for p in frozen.iterdir() if p.is_file() and p.name!="frozen_manifest.json")
    manifest={"schema_version":cfg["schema_version"],"generated_at":summary["generated_at"],"source_root":cfg["source_root"],
              "command":"./run_pipeline.sh --config config/final.yaml","files":[{"path":p.name,"bytes":p.stat().st_size,"sha256":_sha256(p)} for p in files]}
    (frozen/"frozen_manifest.json").write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding="utf-8")
    return results


def _pre_worker(task:tuple[str,str,str])->dict[str,Any]:
    if _WORKER_DATA is None or _WORKER_CFG is None: raise RuntimeError("pre worker not initialized")
    kind,mode,label=task
    spec=RunSpec(mode,"S3",label,collect_detail=False) if kind=="arm" else RunSpec(mode,label,_WORKER_CFG["experiments"]["official_arm"],collect_detail=False)
    r=simulate(_WORKER_DATA,_WORKER_CFG,spec)
    return {"kind":kind,"mode":mode,"label":label,"summary":r["summary"],"daily":r["daily"]}


def _official_s3_from_frozen(cfg:dict[str,Any],mode:str)->dict[str,Any]:
    frozen=Path(cfg["_output_root"])/"frozen"; grouped:dict[str,list[dict[str,str]]]={}
    with (frozen/f"{mode}_dispatch.csv").open(encoding="utf-8-sig",newline="") as f:
        for row in csv.DictReader(f): grouped.setdefault(row["date"],[]).append(row)
    daily=[]
    for day,rows in sorted(grouped.items()):
        daily.append({"date":day,"mode":mode,"scenario":"S3","model_arm":"all_three",
                      "start_soc_kwh":float(rows[0]["soc_start_kwh"]),"end_soc_kwh":float(rows[-1]["soc_end_kwh"]),
                      "plan_grid_kwh":sum(float(r["plan_00_grid_kwh"]) for r in rows),"final_grid_kwh":sum(float(r["final_adjusted_grid_kwh"]) for r in rows),
                      "emergency_kwh":sum(float(r["emergency_kwh"]) for r in rows),"unused_surplus_kwh":sum(float(r["unused_surplus_kwh"]) for r in rows),
                      "plan_cost_yuan":sum(float(r["plan_cost_yuan"]) for r in rows),"adjustment_cost_yuan":sum(float(r["adjustment_cost_yuan"]) for r in rows),
                      "emergency_cost_yuan":sum(float(r["emergency_cost_yuan"]) for r in rows),"final_relative_cost_yuan":sum(float(r["final_relative_cost_yuan"]) for r in rows),
                      "sequential_cost_yuan":sum(float(r["sequential_cost_yuan"]) for r in rows)})
    model=json.loads((frozen/"model_run_summary.json").read_text(encoding="utf-8"))
    summary=next(r for r in model["results"] if r["mode"]==mode)
    return {"summary":summary,"daily":daily}


def run_pre_stability_parallel(data:DataBundle,cfg:dict[str,Any])->dict[str,Any]:
    """Parallelize all non-official ablations and S0-S2; workers never write files."""
    official_arm=cfg["experiments"]["official_arm"]
    tasks=[("arm",mode,arm) for mode in ("q3","q4_3") for arm in cfg["experiments"]["arms"] if arm!=official_arm]
    tasks += [("schedule",mode,s) for mode in ("q3","q4_3") for s in ("S0","S1","S2")]
    got=[]; workers=int(cfg["experiments"].get("stability_workers",4))
    with ProcessPoolExecutor(max_workers=workers,initializer=_init_stability_worker,initargs=(data,cfg)) as pool:
        future_map={pool.submit(_pre_worker,t):t for t in tasks}
        try:
            for fut in as_completed(future_map):
                row=fut.result(); got.append(row)
                print(json.dumps({"stage":"pre_parallel","completed":len(got),"total":len(tasks),"kind":row["kind"],"mode":row["mode"],
                                  "label":row["label"],"cost":row["summary"]["final_relative_cost_yuan"]},ensure_ascii=False),flush=True)
        except BaseException:
            for fut in future_map: fut.cancel()
            raise
    arms={(r["mode"],r["label"]):r for r in got if r["kind"]=="arm"}
    schedules={(r["mode"],r["label"]):r for r in got if r["kind"]=="schedule"}
    for mode in ("q3","q4_3"):
        official=_official_s3_from_frozen(cfg,mode)
        arms[(mode,official_arm)]={"kind":"arm","mode":mode,"label":official_arm,**official}
        schedules[(mode,"S3")]={"kind":"schedule","mode":mode,"label":"S3",**official}
    frozen=Path(cfg["_output_root"])/"frozen"
    exp_rows=[arms[(m,a)]["summary"] for m in ("q3","q4_3") for a in cfg["experiments"]["arms"]]
    exp_rows += [schedules[(m,s)]["summary"] for m in ("q3","q4_3") for s in ("S0","S1","S2")]
    _write_csv(frozen/"experiment_summary.csv",exp_rows)
    monthly=[]
    for mode in ("q3","q4_3"):
        base={x["date"]:x for x in arms[(mode,"raw_baseline")]["daily"]}; combo=schedules[(mode,"S3")]["daily"]
        for month in range(2,13):
            cr=[x for x in combo if int(x["date"][5:7])==month]; br=[base[x["date"]] for x in cr]
            dif=np.asarray([c["final_relative_cost_yuan"]-b["final_relative_cost_yuan"] for b,c in zip(br,cr)])
            lo,hi=moving_block_ci(dif,int(cfg["experiments"]["moving_block_days"]),int(cfg["experiments"]["bootstrap_replicates"]),int(cfg["experiments"]["bootstrap_seed"])+month)
            monthly.append({"mode":mode,"month":month,"days":len(dif),"baseline_cost_yuan":sum(x["final_relative_cost_yuan"] for x in br),
                            "combination_cost_yuan":sum(x["final_relative_cost_yuan"] for x in cr),"difference_yuan":float(dif.sum()),
                            "block_bootstrap_95_low_yuan":lo,"block_bootstrap_95_high_yuan":hi})
    _write_csv(frozen/"monthly_effects.csv",monthly)
    comparison=[]; monthly_schedules=[]
    for mode in ("q3","q4_3"):
        for scenario in ("S0","S1","S2","S3"):
            schedule=schedules[(mode,scenario)]["daily"]
            for month in range(2,13):
                selected=[r for r in schedule if int(r["date"][5:7])==month]
                monthly_schedules.append({"mode":mode,"scenario":scenario,"month":month,"days":len(selected),
                                          "final_relative_cost_yuan":sum(r["final_relative_cost_yuan"] for r in selected),
                                          "sequential_cost_yuan":sum(r["sequential_cost_yuan"] for r in selected),"emergency_kwh":sum(r["emergency_kwh"] for r in selected),
                                          "unused_surplus_kwh":sum(r["unused_surplus_kwh"] for r in selected),"month_end_soc_kwh":selected[-1]["end_soc_kwh"]})
        s2=schedules[(mode,"S2")]["daily"]; s3=schedules[(mode,"S3")]["daily"]
        for metric,label,seedoff in (("final_relative_cost_yuan","S3_minus_S2_final_relative",100),("sequential_cost_yuan","S3_minus_S2_sequential",101)):
            dif=np.asarray([b[metric]-a[metric] for a,b in zip(s2,s3)]); lo,hi=moving_block_ci(dif,int(cfg["experiments"]["moving_block_days"]),int(cfg["experiments"]["bootstrap_replicates"]),int(cfg["experiments"]["bootstrap_seed"])+seedoff)
            comparison.append({"mode":mode,"comparison":label,"days":len(dif),"point_difference_yuan":float(dif.sum()),"block_ci_low_yuan":lo,"block_ci_high_yuan":hi,
                               "positive_days":int(np.sum(dif>.005)),"negative_days":int(np.sum(dif<-.005)),"zero_days":int(np.sum(np.abs(dif)<=.005))})
    _write_csv(frozen/"comparison_stats.csv",comparison); _write_csv(frozen/"monthly_schedules.csv",monthly_schedules)
    summary_path=frozen/"model_run_summary.json"; summary=json.loads(summary_path.read_text(encoding="utf-8")); summary["experiments"]=exp_rows
    summary_path.write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding="utf-8")
    files=sorted(p for p in frozen.iterdir() if p.is_file() and p.name!="frozen_manifest.json")
    manifest={"schema_version":cfg["schema_version"],"generated_at":summary["generated_at"],"source_root":cfg["source_root"],
              "command":"./run_pipeline.sh --config config/final.yaml","files":[{"path":p.name,"bytes":p.stat().st_size,"sha256":_sha256(p)} for p in files]}
    (frozen/"frozen_manifest.json").write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding="utf-8")
    return {"experiments":exp_rows,"comparison":comparison}
