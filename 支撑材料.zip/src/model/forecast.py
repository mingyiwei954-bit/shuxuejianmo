from __future__ import annotations

from datetime import date
from typing import Any

import numpy as np

from .data import DataBundle


def history_days(data: DataBundle, target_day: date, cutoff_day: date, count: int = 4) -> list[int]:
    """Indices of the most recent same-weekday actual profiles, strictly before cutoff."""
    candidates = [i for i, d in enumerate(data.dates) if d < cutoff_day and d.weekday() == target_day.weekday()]
    if not candidates:
        candidates = [i for i, d in enumerate(data.dates) if d < cutoff_day]
    if not candidates:
        raise ValueError(f"no causal history before {cutoff_day}")
    return candidates[-count:]


def profile_horizon(data: DataBundle, start_global: int, length: int, cutoff_day: date, kind: str, count: int) -> tuple[np.ndarray, list[date]]:
    if kind == "load": matrix = data.load_kw
    elif kind == "pv": matrix = data.pv_kw
    elif kind == "price": matrix = data.realtime_price
    else: raise ValueError(f"unknown profile kind {kind}")
    out = np.empty(length, dtype=float)
    used: set[int] = set()
    for k in range(length):
        gi = start_global + k
        di, pos = divmod(gi, 144)
        target = data.dates[di]
        hist = history_days(data, target, cutoff_day, count)
        used.update(hist)
        out[k] = float(np.mean(matrix[hist, pos]))
    return out, [data.dates[i] for i in sorted(used)]


def published_pv_horizon(data: DataBundle, day: date, issue_hour: int, length: int) -> np.ndarray:
    hourly = data.pv_forecast_kw[(day, issue_hour)]
    return np.repeat(hourly, 6)[:length].astype(float, copy=True)


def pv_cap_horizon(data:DataBundle,day:date,issue_hour:int,length:int,cfg:dict[str,Any]) -> np.ndarray:
    fcfg=cfg["forecast"]; cutoff=data.date_index[day]; hist0=max(0,cutoff-int(fcfg["cap_window_days"])); hist=data.pv_kw[hist0:cutoff]
    caps=np.full(24,np.inf)
    if len(hist):
        for lead in range(24):
            target_pos=((issue_hour+lead)%24)*6
            caps[lead]=float(np.quantile(hist[:,target_pos:target_pos+6].reshape(-1),float(fcfg["cap_quantile"])))
    return np.repeat(caps,6)[:length]


def _past_issue_residuals(data: DataBundle, day: date, issue_hour: int, max_days: int) -> tuple[np.ndarray, list[date]]:
    idx = data.date_index
    candidates = [d for d in data.dates if d < day and (d, issue_hour) in data.pv_forecast_kw]
    candidates = candidates[-max_days:]
    rows: list[np.ndarray] = []
    kept: list[date] = []
    for old in candidates:
        start = idx[old] * 144 + issue_hour * 6
        if start + 144 > data.pv_kw.size:
            continue
        actual_hourly = data.pv_kw.reshape(-1)[start:start+144].reshape(24, 6).mean(axis=1)
        rows.append(actual_hourly - data.pv_forecast_kw[(old, issue_hour)])
        kept.append(old)
    return (np.vstack(rows) if rows else np.empty((0, 24))), kept


def corrected_pv_horizon(data: DataBundle, day: date, issue_hour: int, length: int, cfg: dict[str, Any]) -> tuple[np.ndarray, list[date]]:
    fcfg = cfg["forecast"]
    base = data.pv_forecast_kw[(day, issue_hour)].astype(float)
    residuals, dates = _past_issue_residuals(data, day, issue_hour, int(fcfg["bias_window_days"]))
    bias = residuals.mean(axis=0) if len(residuals) else np.zeros(24)
    corrected = np.maximum(base + bias, 0.0)
    expanded=np.repeat(corrected,6)[:length]
    return np.minimum(expanded,pv_cap_horizon(data,day,issue_hour,length,cfg)), dates


def residual_scenarios(data: DataBundle, day: date, issue_hour: int, base: np.ndarray, cfg: dict[str, Any], centered: bool = False) -> tuple[np.ndarray, list[date]]:
    fcfg = cfg["forecast"]
    residuals, dates = _past_issue_residuals(data, day, issue_hour, int(fcfg["scenario_history_days"]))
    n = min(int(fcfg["scenario_count"]), len(residuals))
    if n == 0:
        return np.minimum(base[None,:],pv_cap_horizon(data,day,issue_hour,len(base),cfg)[None,:]), []
    residuals = residuals[-n:]
    if centered:
        residuals = residuals - residuals.mean(axis=0, keepdims=True)
    dates = dates[-n:]
    expanded = np.repeat(residuals, 6, axis=1)[:, :len(base)]
    scenarios=np.maximum(base[None, :] + expanded, 0.0)
    caps=pv_cap_horizon(data,day,issue_hour,len(base),cfg)
    return np.minimum(scenarios,caps[None,:]), dates
