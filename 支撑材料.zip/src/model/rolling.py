from __future__ import annotations

from dataclasses import dataclass
from datetime import date, timedelta
from typing import Any

import numpy as np

from .data import DataBundle
from .forecast import corrected_pv_horizon, profile_horizon, published_pv_horizon, residual_scenarios
from .lp import DispatchSolution, solve_deterministic, solve_stochastic


@dataclass(frozen=True)
class RunSpec:
    mode: str                 # q3 or q4_3
    scenario: str             # S0..S3
    arm: str
    method: str = "highs"
    tiebreak: float | None = None
    start_date: date | None = None
    end_date: date | None = None
    collect_detail: bool = True


def _arm_flags(arm: str) -> tuple[bool, bool, bool]:
    mapping = {
        "raw_baseline": (False, False, False),
        "crossday_only": (True, False, False),
        "bias_only": (False, True, False),
        "bias_crossday": (True, True, False),
        "scenario_crossday": (True, False, True),
        "all_three": (True, True, True),
    }
    if arm not in mapping: raise ValueError(f"unknown experiment arm {arm}")
    return mapping[arm]


def _interval(pos: int) -> str:
    a=pos*10; b=(pos+1)*10
    return f"{a//60:02d}:{a%60:02d}-{b//60:02d}:{b%60:02d}"


def _solve(
    data: DataBundle, cfg: dict[str, Any], day: date, issue: int, length: int,
    initial_soc: float, baseline: np.ndarray, use_bias: bool, use_scenarios: bool,
    terminal_rule: str, execute_intervals: int, mode: str, method: str, tiebreak: float | None,
) -> tuple[DispatchSolution, dict[str, Any]]:
    di=data.date_index[day]; start=di*144+issue*6
    count=int(cfg["forecast"]["same_weekday_profiles"])
    load_kw, load_hist=profile_horizon(data,start,length,day,"load",count)
    if mode=="q4_3": price, price_hist=profile_horizon(data,start,length,day,"price",count)
    else:
        price=np.resize(data.fixed_price[issue*6:],length) if length <= 144-issue*6 else np.resize(np.r_[data.fixed_price[issue*6:],data.fixed_price],length)
        price_hist=[]
    if use_bias:
        pv_kw,bias_hist=corrected_pv_horizon(data,day,issue,length,cfg)
    else:
        pv_kw=published_pv_horizon(data,day,issue,length); bias_hist=[]
    dt=float(cfg["storage"]["interval_minutes"])/60
    target=float(cfg["study"]["terminal_soc_kwh"])
    penalty=float(np.median(price))*float(cfg["rolling"]["selected_soft_penalty_multiplier"])
    if use_scenarios:
        pv_scen,scenario_dates=residual_scenarios(data,day,issue,pv_kw,cfg,centered=use_bias)
        sol=solve_stochastic(load_kw*dt,pv_scen*dt,price,initial_soc,baseline,execute_intervals,
                             terminal_rule,target,penalty,cfg,method,tiebreak)
    else:
        scenario_dates=[]
        sol=solve_deterministic(load_kw*dt,pv_kw*dt,price,initial_soc,baseline,terminal_rule,
                                target,penalty,cfg,method,tiebreak)
    meta={
        "forecast_load_kwh":load_kw*dt,"forecast_pv_kwh":pv_kw*dt,"forecast_price":price,
        "load_history_dates":"|".join(d.isoformat() for d in load_hist),
        "price_history_dates":"|".join(d.isoformat() for d in price_hist),
        "pv_bias_history_dates":"|".join(d.isoformat() for d in bias_hist),
        "residual_scenario_dates":"|".join(d.isoformat() for d in scenario_dates),
    }
    return sol,meta


def simulate(data: DataBundle, cfg: dict[str, Any], spec: RunSpec) -> dict[str, Any]:
    crossday,use_bias,use_scenarios=_arm_flags(spec.arm)
    study=cfg["study"]
    start=spec.start_date or date.fromisoformat(study["official_start"])
    end=spec.end_date or date.fromisoformat(study["official_end"])
    days=[d for d in data.dates if start<=d<=end]
    if not days: raise ValueError("empty simulation period")
    allowed=list(cfg["experiments"]["schedules"][spec.scenario])
    eta=float(cfg["storage"]["charge_efficiency"]); dt=float(cfg["storage"]["interval_minutes"])/60
    final_target=float(study["terminal_soc_kwh"]); total_intervals=len(data.dates)*144
    soc=float(study["initial_soc_kwh"]); first_initial=soc
    dispatch_rows:list[dict[str,Any]]=[]; version_rows:list[dict[str,Any]]=[]; daily_rows:list[dict[str,Any]]=[]
    solve_stats:list[dict[str,Any]]=[]; physical_violation_count=0
    for day in days:
        di=data.date_index[day]
        baseline=np.full(144,np.nan); current_grid=np.full(144,np.nan); current_c=np.zeros(144); current_d=np.zeros(144); current_u=np.zeros(144)
        f_load=np.zeros(144); f_pv=np.zeros(144); f_price=np.zeros(144); decision_owner=np.zeros(144,dtype=int)
        sequential_delta=np.zeros(144); sensitivity_grid=np.full(144,np.nan)
        day_soc_start=soc
        for ai,issue in enumerate(allowed):
            pos=issue*6; global_start=di*144+pos
            if crossday:
                length=min(int(cfg["rolling"]["horizon_hours"])*6,total_intervals-global_start)
            else:
                length=144-pos
            next_issue=allowed[ai+1] if ai+1<len(allowed) else 24
            execute=(next_issue-issue)*6
            b=np.full(length,np.nan)
            if issue>0: b[:144-pos]=baseline[pos:]
            if global_start+length==total_intervals:
                terminal="force_target"
            elif crossday:
                terminal=str(cfg["rolling"]["selected_terminal_rule"])
            else:
                terminal="daily_closed"
            old=current_grid[pos:].copy() if issue>0 else np.full(144-pos,np.nan)
            backup=None
            if use_scenarios:
                # The extensive form governs the executable first block. A causal
                # deterministic point-forecast solve supplies the 00:00 plan and
                # the explicitly hypothetical sequential-settlement path. No
                # random scenario branch is ever recorded as a future commitment.
                backup,_=_solve(data,cfg,day,issue,length,soc,b,use_bias,False,terminal,execute,
                                spec.mode,spec.method,spec.tiebreak)
            sol,meta=_solve(data,cfg,day,issue,length,soc,b,use_bias,use_scenarios,terminal,execute,
                            spec.mode,spec.method,spec.tiebreak)
            solve_stats.append({"date":day.isoformat(),"issue_hour":issue,"elapsed_seconds":sol.elapsed_seconds,
                                "iterations":sol.iterations,"max_balance_residual_kwh":sol.max_balance_residual,
                                "max_soc_residual_kwh":sol.max_soc_residual,"scenario_count":len(meta["residual_scenario_dates"].split("|")) if meta["residual_scenario_dates"] else 1})
            cur_len=144-pos
            if issue==0:
                if backup is None:
                    baseline[:]=sol.grid[:144]
                    current_grid[:]=sol.grid[:144]; current_c[:]=sol.charge[:144]; current_d[:]=sol.discharge[:144]; current_u[:]=sol.curtail[:144]
                else:
                    baseline[:]=backup.grid[:144]
                    first=min(execute,144)
                    baseline[:first]=sol.grid[:first]
                    current_grid[:]=baseline
                    current_c[:]=backup.charge[:144]; current_d[:]=backup.discharge[:144]; current_u[:]=backup.curtail[:144]
                    current_c[:first]=sol.charge[:first]; current_d[:first]=sol.discharge[:first]; current_u[:first]=sol.curtail[:first]
                sensitivity_grid[:]=baseline
            else:
                price_actual=data.realtime_price[di] if spec.mode=="q4_3" else data.fixed_price
                apply_len=min(cur_len,execute) if use_scenarios else cur_len
                old_sensitivity=sensitivity_grid[pos:].copy()
                sensitivity_proposal=backup.grid[:cur_len] if backup is not None else sol.grid[:cur_len]
                down_s=np.maximum(old_sensitivity-sensitivity_proposal,0); up_s=np.maximum(sensitivity_proposal-old_sensitivity,0)
                sequential_delta[pos:] += -float(cfg["cost"]["down_adjustment_multiplier"])*price_actual[pos:]*down_s + float(cfg["cost"]["up_adjustment_multiplier"])*price_actual[pos:]*up_s
                sensitivity_grid[pos:]=sensitivity_proposal
                sl=slice(pos,pos+apply_len)
                current_grid[sl]=sol.grid[:apply_len]; current_c[sl]=sol.charge[:apply_len]; current_d[sl]=sol.discharge[:apply_len]; current_u[sl]=sol.curtail[:apply_len]
            forecast_apply=min(cur_len,execute) if use_scenarios else cur_len
            sl=slice(pos,pos+forecast_apply)
            f_load[sl]=meta["forecast_load_kwh"][:forecast_apply]; f_pv[sl]=meta["forecast_pv_kwh"][:forecast_apply]; f_price[sl]=meta["forecast_price"][:forecast_apply]; decision_owner[sl]=issue
            old_commit = baseline[pos:] if issue==0 else old
            sensitivity_old=np.full(cur_len,np.nan) if issue==0 else old_sensitivity
            sensitivity_new=baseline[pos:] if issue==0 else sensitivity_proposal
            for k in range(length):
                gi=global_start+k; tdi,tpos=divmod(gi,144); target_day=data.dates[tdi]
                is_preview=target_day!=day
                preview_recourse=bool(is_preview or (use_scenarios and issue>0 and k>=execute))
                formal=bool(not is_preview and (issue==0 or not use_scenarios or k<execute))
                preview_grid=(backup.grid[k] if backup is not None else sol.grid[k]) if is_preview else ""
                if not spec.collect_detail:
                    continue
                version_rows.append({
                    "date":day.isoformat(),"target_date":target_day.isoformat(),"mode":spec.mode,"scenario":spec.scenario,"model_arm":spec.arm,
                    "decision_time":f"{day.isoformat()} {issue:02d}:00","forecast_issue_time":f"{day.isoformat()} {issue:02d}:00",
                    "effective_start":f"{day.isoformat()} {issue:02d}:00","effective_end":f"{(day+timedelta(days=1)).isoformat()} {issue:02d}:00",
                    "history_cutoff_date":(day-timedelta(days=1)).isoformat(),"position":tpos+1,
                    "physical_interval":_interval(tpos),"official_label":data.official_labels[tpos],
                    "old_commitment_kwh":"" if not formal or issue==0 else float(old_commit[k]),
                    "new_commitment_kwh":float(baseline[k]) if formal and issue==0 else (float(sol.grid[k]) if formal else ""),
                    "sensitivity_old_commitment_kwh":"" if is_preview or issue==0 else float(sensitivity_old[k]),
                    "sensitivity_new_commitment_kwh":"" if is_preview else float(sensitivity_new[k]),
                    "preview_grid_kwh":float(preview_grid) if preview_grid!="" else "",
                    "decision_basis":"next_block_stochastic" if formal and use_scenarios and k<execute else ("deterministic_day_ahead_backup" if formal and issue==0 else ("deterministic_point_forecast_sensitivity" if not is_preview else "next_day_preview")),
                    "soc_at_decision_kwh":float(soc),
                    "load_history_dates":meta["load_history_dates"] if k==0 else "","price_history_dates":meta["price_history_dates"] if k==0 else "",
                    "pv_bias_history_dates":meta["pv_bias_history_dates"] if k==0 else "","residual_scenario_dates":meta["residual_scenario_dates"] if k==0 else "",
                    "is_preview_next_day":int(is_preview),"is_preview_recourse":int(preview_recourse),
                })
            # Execute only until the next enabled decision (or midnight).
            ex=min(execute,144-pos)
            if ex:
                soc=float(sol.soc_end[ex-1])
        actual_load=data.load_kw[di]*dt; actual_pv=data.pv_kw[di]*dt
        price_actual=data.realtime_price[di] if spec.mode=="q4_3" else data.fixed_price
        soc_end=np.empty(144); s=day_soc_start
        for j in range(144):
            s=s+eta*current_c[j]-current_d[j]/eta; soc_end[j]=s
        soc_start=np.r_[day_soc_start,soc_end[:-1]]; soc=float(soc_end[-1])
        physical_violation_count+=int(np.sum((soc_end<float(cfg["storage"]["soc_min_kwh"])-float(cfg["audit"]["feasibility_tolerance"]))|(soc_end>float(cfg["storage"]["soc_max_kwh"])+float(cfg["audit"]["feasibility_tolerance"]))))
        net=current_grid+actual_pv+current_d-actual_load-current_c
        emergency=np.maximum(-net,0); unused=np.maximum(net,0)
        down=np.maximum(baseline-current_grid,0); up=np.maximum(current_grid-baseline,0)
        plan_cost=price_actual*baseline
        adj_cost=-float(cfg["cost"]["down_adjustment_multiplier"])*price_actual*down+float(cfg["cost"]["up_adjustment_multiplier"])*price_actual*up
        emergency_cost=float(cfg["cost"]["emergency_multiplier"])*price_actual*emergency
        total=plan_cost+adj_cost+emergency_cost
        sequential=plan_cost+sequential_delta+emergency_cost
        for j in range(144):
            if not spec.collect_detail:
                continue
            curtail_pv=min(float(current_u[j]),float(f_pv[j])); planned_unused_nonpv=max(float(current_u[j])-float(f_pv[j]),0.0)
            dispatch_rows.append({
                "date":day.isoformat(),"position":j+1,"source_timestamp":data.source_timestamps[j],
                "physical_interval":_interval(j),"official_label":data.official_labels[j],
                "plan_00_grid_kwh":float(baseline[j]),"final_adjusted_grid_kwh":float(current_grid[j]),
                "adjustment_kwh":float(current_grid[j]-baseline[j]),"charge_kwh":float(current_c[j]),
                "discharge_kwh":float(current_d[j]),"soc_start_kwh":float(soc_start[j]),"soc_end_kwh":float(soc_end[j]),
                "curtail_pv_kwh":curtail_pv,"planned_unused_nonpv_kwh":planned_unused_nonpv,"forecast_load_kwh":float(f_load[j]),"forecast_pv_kwh":float(f_pv[j]),
                "actual_load_kwh":float(actual_load[j]),"actual_pv_kwh":float(actual_pv[j]),"forecast_price":float(f_price[j]),
                "settlement_price":float(price_actual[j]),"emergency_kwh":float(emergency[j]),"unused_surplus_kwh":float(unused[j]),
                "plan_cost_yuan":float(plan_cost[j]),"adjustment_cost_yuan":float(adj_cost[j]),"emergency_cost_yuan":float(emergency_cost[j]),
                "final_relative_cost_yuan":float(total[j]),"sequential_cost_yuan":float(sequential[j]),"decision_hour":int(decision_owner[j]),
                "history_cutoff_date":(day-timedelta(days=1)).isoformat(),"model_arm":spec.arm,"scenario":spec.scenario,
            })
        daily_rows.append({
            "date":day.isoformat(),"mode":spec.mode,"scenario":spec.scenario,"model_arm":spec.arm,
            "start_soc_kwh":float(day_soc_start),"end_soc_kwh":float(soc),"plan_grid_kwh":float(np.sum(baseline)),
            "final_grid_kwh":float(np.sum(current_grid)),"emergency_kwh":float(np.sum(emergency)),
            "unused_surplus_kwh":float(np.sum(unused)),"plan_cost_yuan":float(np.sum(plan_cost)),
            "adjustment_cost_yuan":float(np.sum(adj_cost)),"emergency_cost_yuan":float(np.sum(emergency_cost)),
            "final_relative_cost_yuan":float(np.sum(total)),"sequential_cost_yuan":float(np.sum(sequential)),
        })
    tol=float(cfg["audit"]["numeric_tolerance"])
    if abs(first_initial-float(study["initial_soc_kwh"]))>tol:
        raise AssertionError("first day SOC differs from contract")
    if end==date.fromisoformat(study["official_end"]) and abs(soc-final_target)>tol:
        raise AssertionError(f"terminal SOC {soc} differs from {final_target}")
    tol=float(cfg["audit"]["feasibility_tolerance"]); st=cfg["storage"]
    violation_count=sum(int(x["max_balance_residual_kwh"]>tol or x["max_soc_residual_kwh"]>tol) for x in solve_stats)
    violation_count+=physical_violation_count
    return {"spec":spec,"dispatch":dispatch_rows,"decision_versions":version_rows,"daily":daily_rows,"solve_stats":solve_stats,
            "summary":{
                "mode":spec.mode,"scenario":spec.scenario,"model_arm":spec.arm,"days":len(days),
                "initial_soc_kwh":float(daily_rows[0]["start_soc_kwh"]),"terminal_soc_kwh":float(daily_rows[-1]["end_soc_kwh"]),
                "plan_cost_yuan":float(sum(x["plan_cost_yuan"] for x in daily_rows)),
                "adjustment_cost_yuan":float(sum(x["adjustment_cost_yuan"] for x in daily_rows)),
                "emergency_cost_yuan":float(sum(x["emergency_cost_yuan"] for x in daily_rows)),
                "final_relative_cost_yuan":float(sum(x["final_relative_cost_yuan"] for x in daily_rows)),
                "sequential_cost_yuan":float(sum(x["sequential_cost_yuan"] for x in daily_rows)),
                "emergency_kwh":float(sum(x["emergency_kwh"] for x in daily_rows)),
                "unused_surplus_kwh":float(sum(x["unused_surplus_kwh"] for x in daily_rows)),
                "solver_seconds":float(sum(x["elapsed_seconds"] for x in solve_stats)),"solver_runs":len(solve_stats),
                "max_balance_residual_kwh":float(max(x["max_balance_residual_kwh"] for x in solve_stats)),
                "max_soc_residual_kwh":float(max(x["max_soc_residual_kwh"] for x in solve_stats)),
                "constraint_violation_count":int(violation_count),
            }}
